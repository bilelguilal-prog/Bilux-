#!/usr/bin/env python3
"""BILUX V6.2 Nuclear Command: prepare changes off-repository, preserving WidgetKit/signing."""
from pathlib import Path
import sys
import plistlib
if len(sys.argv)!=3: raise SystemExit('Usage: APPLIQUER_V6_2.py ROOT STAGING')
root, stage = [Path(x).resolve() for x in sys.argv[1:]]

def abort(note): raise SystemExit('❌ ' + note + ' : projet non modifié.')
def read(rel):
    f=root/rel
    if not f.is_file(): abort(f'Fichier introuvable {rel}')
    return f.read_text(encoding='utf8')
def exactly(s,old,new,label):
    n=s.count(old)
    if n!=1: abort(f'Base incompatible: {label} ({n} marqueurs, attendu 1)')
    return s.replace(old,new,1)
def write(rel,s):
    target=stage/rel;target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(s,encoding='utf8');print(f'✅ Préparé : {rel} ({len(s.splitlines())} lignes)')
for rel in ('BiluxIOS/Info.plist','BiluxWatch/Info.plist','BiluxWatchWidget/Info.plist'):
    try: ver=str(plistlib.loads((root/rel).read_bytes())['CFBundleVersion'])
    except Exception: abort(f'Info.plist invalide {rel}')
    if ver!='21': abort(f'{rel} : build 21 requis, reçu {ver}')
if not (root/'BiluxWatchWidget/NuclearLiveWidget.swift').is_file(): abort('WidgetKit V6.1.1 absent')

# Existing workouts / exports: add ONE optional summary; default nil for earlier records.
rel='BiluxIOS/Models.swift';s=read(rel)
if 'struct NuclearLiveReport' in s:abort('Un modèle de rapport existe déjà')
s=exactly(s, '''    var exercises: [WorkoutExercise]
    var volume: Double {''', '''    var exercises: [WorkoutExercise]
    // Optionnel : les JSON historiques restent décodables, sans migration d'XP.
    var liveReport: NuclearLiveReport? = nil
    var volume: Double {''','modèle de séance')
s=exactly(s,'struct ManualMeal: Codable, Identifiable {','''// BILUX V6.2 : observations de Nuclear Live, pas une mesure médicale ni une récompense RPG.
struct NuclearLiveReport: Codable, Equatable {
    var averageBPM: Int?
    var peakBPM: Int?
    var activeKcal: Double?
    var zoneSeconds: [Int]
    var referenceMaxBPM: Int
    var sampleCount: Int
}

struct ManualMeal: Codable, Identifiable {''','rapport de séance')
write(rel,s)

# The Watch keeps reading HealthKit from the existing HKLiveWorkoutBuilder.
rel='BiluxWatch/WatchRootView.swift';s=read(rel)
if 'private final class V61NuclearLive' not in s or 'V61LiveWorkoutView' not in s: abort('Watch Nuclear Live V6.1 absent')
if 'V62CardiacZone' in s:abort('Zones V6.2 déjà présentes')
s=exactly(s,'import HealthKit\nimport Combine','''import HealthKit
import Combine
import WatchKit

// Zones visuelles indicatives calculées en % de FC max choisie sur la montre.
// Ne prescrivent ni seuil médical ni intensité d'entraînement.
private enum V62CardiacZone {
    static func index(_ bpm: Double, maxBPM: Int) -> Int {
        let fraction = bpm / Double(max(120, min(220, maxBPM)))
        switch fraction {
        case ..<0.60: return 1
        case ..<0.70: return 2
        case ..<0.80: return 3
        case ..<0.90: return 4
        default: return 5
        }
    }
}
''', 'en-tête Watch')
s=exactly(s,'''    @Published private(set) var activityName = "Musculation"
    @Published private(set) var message: String?
''','''    @Published private(set) var activityName = "Musculation"
    @Published private(set) var message: String?
    @Published private(set) var cardiacZone: Int?
    @Published private(set) var zoneSeconds: [Int] = [0, 0, 0, 0, 0]
    @Published private(set) var averageBPM: Int?
    @Published private(set) var peakBPM: Int?
    @Published private(set) var maxReferenceBPM = 190
    private var sumBPM: Double = 0
    private var heartSamples = 0
    private var lastHeartAt: Date?
    private var lastZone: Int?
    private var hapticEnabled = false
    private var lastHapticAt: Date?
''','état observé HealthKit')
s=exactly(s,'''    func start(mode: V61LiveMode, bridge: WatchBridge) async {
''','''    func start(mode: V61LiveMode, bridge: WatchBridge,
               referenceMaxBPM: Int, enableHaptics: Bool) async {
''','fonction start')
s=exactly(s,'''            activityName = mode.rawValue
            bpm = nil
            activeKcal = nil
''','''            activityName = mode.rawValue
            bpm = nil
            activeKcal = nil
            maxReferenceBPM = max(120, min(220, referenceMaxBPM))
            hapticEnabled = enableHaptics
            cardiacZone = nil
            zoneSeconds = [0, 0, 0, 0, 0]
            sumBPM = 0
            heartSamples = 0
            averageBPM = nil
            peakBPM = nil
            lastHeartAt = nil
            lastZone = nil
            lastHapticAt = nil
''','réinitialisation mesures')
s=exactly(s, '''        case .running:
            pausedAt = Date()
            session?.pause()
''','''        case .running:
            pausedAt = Date()
            lastHeartAt = nil // Ne jamais comptabiliser de durée dans les zones pendant la pause.
            session?.pause()
''', 'gestion pause')
s=exactly(s,'''            pausedAt = nil
            session?.resume()
''','''            pausedAt = nil
            lastHeartAt = nil
            session?.resume()
''','gestion reprise')
s=exactly(s,'''                        activity: self.activityName, workoutID: workout.uuid,
                        activeKcal: self.activeKcal
''','''                        activity: self.activityName, workoutID: workout.uuid,
                        activeKcal: self.activeKcal,
                        averageBPM: self.averageBPM, peakBPM: self.peakBPM,
                        zoneSeconds: self.zoneSeconds,
                        referenceMaxBPM: self.maxReferenceBPM,
                        sampleCount: self.heartSamples
''','résumé HealthKit vers iPhone')
old='''    private func updateMetrics() {
        guard let builder else { return }
        if let heartType = HKObjectType.quantityType(forIdentifier: .heartRate),
           let quantity = builder.statistics(for: heartType)?.mostRecentQuantity() {
            let rate = quantity.doubleValue(for: HKUnit.count().unitDivided(by: .minute()))
            if rate.isFinite && rate > 0 { bpm = rate }
        }
        if let energyType = HKObjectType.quantityType(forIdentifier: .activeEnergyBurned),
           let quantity = builder.statistics(for: energyType)?.sumQuantity() {
            let energy = quantity.doubleValue(for: .kilocalorie())
            if energy.isFinite && energy >= 0 { activeKcal = energy }
        }
    }
'''
new='''    private func updateMetrics(heartUpdated: Bool) {
        guard let builder else { return }
        if heartUpdated,
           let heartType = HKObjectType.quantityType(forIdentifier: .heartRate),
           let quantity = builder.statistics(for: heartType)?.mostRecentQuantity() {
            let rate = quantity.doubleValue(for: HKUnit.count().unitDivided(by: .minute()))
            if rate.isFinite && (35...240).contains(rate), phase == .running {
                let now = Date()
                let nextZone = V62CardiacZone.index(rate, maxBPM: maxReferenceBPM)
                if let lastHeartAt, let lastZone, (1...5).contains(lastZone) {
                    let gap = now.timeIntervalSince(lastHeartAt)
                    // Ne pas inventer des durées pendant les trous de capteur (>15 s).
                    if gap > 0 && gap <= 15 { zoneSeconds[lastZone - 1] += Int(gap.rounded()) }
                }
                let old = cardiacZone
                cardiacZone = nextZone
                if hapticEnabled, let old, old != nextZone,
                   now.timeIntervalSince(lastHapticAt ?? .distantPast) >= 30 {
                    WKInterfaceDevice.current().play(.click)
                    lastHapticAt = now
                }
                lastHeartAt = now
                lastZone = nextZone
                bpm = rate
                heartSamples += 1
                sumBPM += rate
                averageBPM = Int((sumBPM / Double(heartSamples)).rounded())
                peakBPM = max(peakBPM ?? 0, Int(rate.rounded()))
            }
        }
        if let energyType = HKObjectType.quantityType(forIdentifier: .activeEnergyBurned),
           let quantity = builder.statistics(for: energyType)?.sumQuantity() {
            let energy = quantity.doubleValue(for: .kilocalorie())
            if energy.isFinite && energy >= 0 { activeKcal = energy }
        }
    }
'''
s=exactly(s,old,new,'traitement des capteurs')
s=exactly(s,'''        Task { @MainActor in self.updateMetrics() }
''','''        // Les calories peuvent changer sans nouvel échantillon cardiaque : ne pas
        // compter de durée en zone si seul le flux énergétique a été actualisé.
        let heartUpdated = collectedTypes.contains { sample in
            sample.identifier == HKQuantityTypeIdentifier.heartRate.rawValue
        }
        Task { @MainActor in self.updateMetrics(heartUpdated: heartUpdated) }
''','délégué HealthKit')
s=exactly(s,'''    @State private var selectedMode: V61LiveMode = .strength
    @State private var confirmCancel = false
''','''    @State private var selectedMode: V61LiveMode = .strength
    @State private var confirmCancel = false
    @AppStorage("bilux.watch.live.maxReferenceBPM") private var maxReferenceBPM = 190
    @AppStorage("bilux.watch.live.zoneHaptics") private var zoneHaptics = false
''','préférences watch')
s=exactly(s, 'V54ReactorTitle(text: "NUCLEAR LIVE · V6.1", symbol: "heart.fill")',
          'V54ReactorTitle(text: "NUCLEAR COMMAND · V6.2", symbol: "heart.fill")', 'titre live')
s=exactly(s,'''                    ForEach(V61LiveMode.allCases) { mode in
''','''                    V54ReactorCard(accent: V54ReactorTheme.purple) {
                        Stepper(value: $maxReferenceBPM, in: 120...220, step: 5) {
                            Text("FC max de référence : \\(maxReferenceBPM) bpm")
                                .font(.system(size: 10, weight: .semibold))
                                .foregroundStyle(V54ReactorTheme.paleGold)
                        }
                        Toggle("Vibration au changement de zone", isOn: $zoneHaptics)
                            .font(.system(size: 10))
                        Text("Zones indicatives selon ce repère, sans prescription d'intensité.")
                            .font(.system(size: 9)).foregroundStyle(V54ReactorTheme.secondary)
                    }
                    ForEach(V61LiveMode.allCases) { mode in
''','configuration de FC')
s=exactly(s,'''                        Task { await live.start(mode: selectedMode, bridge: bridge) }
''','''                        Task {
                            await live.start(mode: selectedMode, bridge: bridge,
                                             referenceMaxBPM: maxReferenceBPM,
                                             enableHaptics: zoneHaptics)
                        }
''','start UI')
s=exactly(s,'''                    if live.phase == .paused {
''','''                    V54ReactorCard(accent: V54ReactorTheme.purple) {
                        HStack {
                            Label("ZONES CARDIAQUES", systemImage: "waveform.path.ecg")
                                .font(.system(size: 10, weight: .heavy))
                                .foregroundStyle(V54ReactorTheme.paleGold)
                            Spacer(minLength: 1)
                            Text(live.cardiacZone.map { "Z\\($0)" } ?? "—")
                                .font(.system(size: 15, weight: .black))
                                .foregroundStyle(V54ReactorTheme.gold)
                        }
                        HStack(spacing: 3) {
                            ForEach(1...5, id: \\.self) { z in
                                RoundedRectangle(cornerRadius: 3)
                                    .fill(live.cardiacZone == z ? V54ReactorTheme.gold : V54ReactorTheme.purple.opacity(0.25))
                                    .frame(height: live.cardiacZone == z ? 12 : 6)
                            }
                        }
                        Text("Basées sur \\(live.maxReferenceBPM) bpm · repères indicatifs")
                            .font(.system(size: 9)).foregroundStyle(V54ReactorTheme.secondary)
                    }
                    if live.phase == .paused {
''','jauge 5 zones')
write(rel,s)

# WatchConnectivity: keep stable HealthKit UUID and send modest per-session data.
rel='BiluxWatch/WatchBridge.swift';s=read(rel)
s=exactly(s,'''                           workoutID: UUID, activeKcal: Double?) {
''','''                           workoutID: UUID, activeKcal: Double?,
                           averageBPM: Int?, peakBPM: Int?,
                           zoneSeconds: [Int], referenceMaxBPM: Int,
                           sampleCount: Int) {
''','signature WatchConnectivity')
s=exactly(s,'''        if let activeKcal, activeKcal.isFinite {
            event["activeKcal"] = max(0, activeKcal)
        }
''','''        if let activeKcal, activeKcal.isFinite {
            event["activeKcal"] = max(0, activeKcal)
        }
        if let averageBPM { event["averageBPM"] = averageBPM }
        if let peakBPM { event["peakBPM"] = peakBPM }
        event["zoneSeconds"] = zoneSeconds
        event["referenceMaxBPM"] = referenceMaxBPM
        event["sampleCount"] = sampleCount
''','résumé WCSession')
write(rel,s)

# Receiving phone remains idempotent, validates numerical ranges, persists summary as optional metadata.
rel='BiluxIOS/WatchPhoneBridge.swift';s=read(rel)
s=exactly(s,'''        journal.add(WorkoutSession(
            id: id, date: Date(timeIntervalSince1970: startedAt),
            activity: activity, durationMinutes: duration,
            notes: note, exercises: []
        ))
''','''        var entry = WorkoutSession(
            id: id, date: Date(timeIntervalSince1970: startedAt),
            activity: activity, durationMinutes: duration,
            notes: note, exercises: []
        )
        if isLive {
            let count = max(0, min(25_000, message["sampleCount"] as? Int ?? 0))
            let mean = (message["averageBPM"] as? Int).flatMap { (35...240).contains($0) ? $0 : nil }
            let peak = (message["peakBPM"] as? Int).flatMap { (35...240).contains($0) ? $0 : nil }
            let calorie = (message["activeKcal"] as? Double).flatMap { $0.isFinite && (0...20_000).contains($0) ? $0 : nil }
            let raw = message["zoneSeconds"] as? [Int] ?? []
            let zones = raw.count == 5 && raw.allSatisfy({ (0...(duration * 60)).contains($0) }) && raw.reduce(0, +) <= duration * 60 + 60 ? raw : [0, 0, 0, 0, 0]
            let ref = max(120, min(220, message["referenceMaxBPM"] as? Int ?? 190))
            entry.liveReport = NuclearLiveReport(averageBPM: mean, peakBPM: peak,
                                                  activeKcal: calorie, zoneSeconds: zones,
                                                  referenceMaxBPM: ref, sampleCount: count)
        }
        journal.add(entry)
''','réception résumé iPhone')
write(rel,s)

# Preserve existing reports when the user edits activity or sets in La Forge.
rel='BiluxIOS/BiluxStore.swift';s=read(rel)
s=exactly(s,'''        data.workouts[index] = session
        for exercise in session.exercises { registerExerciseName(exercise.name, saveImmediately: false) }
''','''        var updated = session
        if updated.liveReport == nil {
            updated.liveReport = data.workouts[index].liveReport
        }
        data.workouts[index] = updated
        for exercise in session.exercises { registerExerciseName(exercise.name, saveImmediately: false) }
''','préservation du rapport en édition')
write(rel,s)

# iPhone UX: tap to open retrospective after any completed Nuclear Live workout.
rel='BiluxIOS/BiluxScreens.swift';s=read(rel)
if 'private struct V62NuclearDebrief' in s:abort('Débrief déjà présent')
s=exactly(s,'''    @State private var editingWorkout: WorkoutSession?
    var body: some View {
''','''    @State private var editingWorkout: WorkoutSession?
    @State private var selectedLiveWorkout: WorkoutSession?
    var body: some View {
''','état feuille de débrief')
s=exactly(s,'''                            if !workout.notes.isEmpty { Text(workout.notes).font(.caption) }
                            HStack(spacing: 16) {
''','''                            if !workout.notes.isEmpty { Text(workout.notes).font(.caption) }
                            if workout.liveReport != nil {
                                Button { selectedLiveWorkout = workout } label: {
                                    Label("DÉBRIEF NUCLEAR LIVE", systemImage: "chart.bar.fill")
                                        .font(.caption.bold()).frame(maxWidth: .infinity)
                                }
                                .buttonStyle(.borderedProminent)
                                .tint(Nuclear.purple)
                            }
                            HStack(spacing: 16) {
''','bouton débrief historique')
s=exactly(s,'''            .sheet(item: $editingWorkout) { workout in NewWorkoutScreen(session: workout) }
''','''            .sheet(item: $editingWorkout) { workout in NewWorkoutScreen(session: workout) }
            .sheet(item: $selectedLiveWorkout) { workout in
                V62NuclearDebrief(workout: workout)
            }
''','feuille débrief')
s += '''
// MARK: - BILUX V6.2 — NUCLEAR COMMAND · Débrief post-entraînement
private struct V62NuclearDebrief: View {
    let workout: WorkoutSession
    @Environment(\\.dismiss) private var dismiss
    private var report: NuclearLiveReport? { workout.liveReport }
    private let captions = ["Récupération", "Endurance douce", "Soutenu", "Intense", "Très intense"]

    private func metric(_ label: String, _ value: String, symbol: String) -> some View {
        VStack(spacing: 6) {
            Image(systemName: symbol).foregroundStyle(Nuclear.gold)
            Text(value).font(.system(size: 18, weight: .black, design: .rounded))
                .foregroundStyle(.white).minimumScaleFactor(0.65).lineLimit(1)
            Text(label).font(.system(size: 10)).foregroundStyle(Nuclear.muted)
        }
        .frame(maxWidth: .infinity)
        .padding(10)
        .background(Nuclear.panel, in: RoundedRectangle(cornerRadius: 13))
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 15) {
                    NuclearCard {
                        Text("NUCLEAR COMMAND · RAPPORT DE COMBAT")
                            .font(.caption.bold()).foregroundStyle(Nuclear.gold).tracking(1)
                        Text(workout.activity.uppercased())
                            .font(.system(size: 24, weight: .black, design: .rounded))
                        Text(workout.date.formatted(date: .abbreviated, time: .shortened))
                            .font(.caption).foregroundStyle(Nuclear.muted)
                        HStack(spacing: 6) {
                            metric("Durée", "\\(workout.durationMinutes) min", symbol: "timer")
                            metric("Kcal actives", report?.activeKcal.map { "\\(Int($0.rounded()))" } ?? "—", symbol: "flame.fill")
                        }
                        HStack(spacing: 6) {
                            metric("FC moyenne*", report?.averageBPM.map { String($0) } ?? "—", symbol: "heart.fill")
                            metric("Pic observé*", report?.peakBPM.map { String($0) } ?? "—", symbol: "waveform.path.ecg")
                        }
                    }
                    SectionCaption(title: "Répartition des 5 zones")
                    NuclearCard {
                        if let report {
                            let totals = report.zoneSeconds.count == 5 ? report.zoneSeconds : [0, 0, 0, 0, 0]
                            let maxSeconds = max(1, totals.max() ?? 0)
                            ForEach(0..<5, id: \\.self) { index in
                                HStack(spacing: 8) {
                                    Text("Z\\(index + 1)")
                                        .font(.caption.bold()).foregroundStyle(Nuclear.gold)
                                        .frame(width: 27, alignment: .leading)
                                    GeometryReader { geometry in
                                        ZStack(alignment: .leading) {
                                            Capsule().fill(Nuclear.purple.opacity(0.15))
                                            Capsule()
                                                .fill(index >= 3 ? Nuclear.gold : Nuclear.purple)
                                                .frame(width: max(2, geometry.size.width * CGFloat(totals[index]) / CGFloat(maxSeconds)))
                                        }
                                    }
                                    .frame(height: 9)
                                    Text("\\(totals[index]) s")
                                        .font(.caption.monospacedDigit()).foregroundStyle(Nuclear.paleGold)
                                        .frame(width: 45, alignment: .trailing)
                                }
                                Text(captions[index]).font(.system(size: 10)).foregroundStyle(Nuclear.muted)
                            }
                            Text("FC max de référence : \\(report.referenceMaxBPM) bpm · \\(report.sampleCount) échantillons observés")
                                .font(.caption2).foregroundStyle(Nuclear.muted)
                        }
                    }
                    Text("* Moyenne et pic des lectures observées pendant Nuclear Live, non une mesure diagnostique. Les durées en zone sont approximatives : pauses et trous de capteur ne sont pas estimés. Repères indicatifs uniquement.")
                        .font(.caption2).foregroundStyle(Nuclear.muted)
                    Text("Aucun XP supplémentaire : cette séance compte déjà une seule fois dans ton journal.")
                        .font(.caption2).foregroundStyle(Nuclear.paleGold)
                }
                .padding(16)
            }
            .background(Nuclear.background.ignoresSafeArea())
            .navigationTitle("Débrief Nuclear Live")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Fermer") { dismiss() }
                }
            }
        }
    }
}
'''
write(rel,s)
print('✅ Aucun changement au widget, à Codemagic, à HealthKit permissions ou au moteur XP.')
