# ☢️ BILUX V6.2 — NUCLEAR COMMAND

**Base stable exigée** : branche `bilux-v6.1.2-widget-signing`, **build 21** (widget Apple Watch déjà publié / fonctionnel).  
**Nouvelle branche créée** : `bilux-v6.2-nuclear-command`.  
**Prochain build TestFlight** : **22**, uniquement après les deux compilations sans signature vertes.

## Nouveautés

### Apple Watch — Nuclear Live

- Affichage **Z1 à Z5** de la fréquence cardiaque, calculée sur un **maximum de référence réglable entre 120 et 220 BPM** (190 par défaut : repère arbitraire, **pas** un FC max personnel mesuré ni une cible médicale).
- Barres de zones, moyenne et pic calculés à partir des mesures cardiaques **observées** par BILUX pendant la séance.
- Estimation des secondes passées par zone, sans compter les **pauses** ni les intervalles de capteur supérieurs à **15 secondes**. Une absence de signal n'est pas transformée en mesure.
- Vibrations facultatives lors d'un changement de zone, espacées d'au moins 30 secondes (désactivées par défaut).
- Musculation / Marche / Cardio / Mobilité, le chronomètre et la sauvegarde HealthKit V6.1 sont conservés.

### iPhone — La Forge

- Pour les **nouvelles** séances Nuclear Live V6.2 uniquement : bouton **DÉBRIEF NUCLEAR LIVE** dans l'historique de Sport.
- Écran de compte-rendu avec durée, kcal actives, FC moyenne et pic **observés**, répartition Z1–Z5, nombre de lectures et FC max de référence.
- Une séance HealthKit reste associée à **un seul UUID** dans La Forge. Les retransmissions WatchConnectivity n'ajoutent pas de doublon.
- Nouveau champ `liveReport` **facultatif** dans le journal, conservé lors des modifications des séances ; les anciens JSON V3/V4/V5/V6 et anciens entraînements restent lisibles.
- **Aucun changement** de l'attribution des XP, du niveau 100, des missions, du Codex, des bosses, des titres, des auras, du widget ou de la signature Codemagic.

## 0. Sauvegarde privée

Sur l'iPhone, dans BILUX → Ascension, **exporter une sauvegarde JSON** vers Fichiers/iCloud privé. **Ne jamais envoyer cette sauvegarde à GitHub.** Elle pourra désormais contenir des statistiques cardiaques.

## 1. GitHub (depuis ton iPhone)

Ouvre `https://github.com/bilelguilal-prog/Bilux-`.

1. Sélectionne **`bilux-v6.1.2-widget-signing`** (build 21, widget déjà fonctionnel).
2. **Add file → Upload files** : choisis `BILUX_V6_2_NUCLEAR_COMMAND.zip`.
3. Valide avec **Commit changes** sur **cette branche**, puis ouvre Codespaces.

## 2. Codespaces

Dans le terminal, **à la racine du dépôt** :

```bash
git switch bilux-v6.1.2-widget-signing && git pull --ff-only origin bilux-v6.1.2-widget-signing && unzip -o BILUX_V6_2_NUCLEAR_COMMAND.zip -d /tmp/bilux-v62 && bash /tmp/bilux-v62/INSTALLER_V6_2.sh
```

Le script refuse les modifications locales suivies non enregistrées, prépare les six fichiers dans un dossier temporaire, vérifie syntaxe et marqueurs connus, crée `bilux-v6.2-nuclear-command` et pousse sur GitHub. Les fichiers du widget, le projet Xcode et `codemagic.yaml` ne sont **pas** modifiés par cet installateur.

## 3. Codemagic : validation de compilation

Sur la branche `bilux-v6.2-nuclear-command`, lance les deux workflows de **vérification sans signature** :

1. **BILUX — Vérifier le projet iOS**
2. **BILUX V4.1 — Vérifier Apple Watch**

Les sources Swift ont passé une analyse syntaxique locale Linux, et le code JSON facultatif a été testé en lecture/écriture. Cela n'est **pas** une compilation iPhone/watchOS : si Codemagic échoue, envoyer le **premier message `error:`** du journal.

## 4. Préparer le build 22 seulement si les deux tests sont verts

Codespaces (même terminal, même dossier) :

```bash
bash /tmp/bilux-v62/PREPARER_BUILD_22.sh
```

Cette commande fait **21 → 22 pour iPhone, Watch et WidgetKit**, met à jour les deux paramètres de version de la cible widget du projet Xcode, commite puis pousse la branche. Une seconde exécution échoue volontairement pour éviter un numéro incohérent.

## 5. TestFlight

Dans Codemagic, sur `bilux-v6.2-nuclear-command` : **BILUX — Publier sur TestFlight**. La publication doit continuer d'utiliser tes **trois profils App Store déjà configurés**, et le script de signature widget de V6.1.3 toujours présent.

Version attendue : `1.0 (22)` sur App Store Connect, puis installer depuis TestFlight sur iPhone et Apple Watch.

## 6. Vérification sur appareils

1. Ouvre la complication **⚡ LIVE** sur le cadran : la page Nuclear Live doit encore s'ouvrir (le widget ne change pas).
2. Sur la montre, vérifie que **FC max de référence** et **Vibration au changement de zone** sont configurables avant le démarrage.
3. Démarre une courte séance **Musculation** ou **Marche** ; observe la jauge **Z1–Z5** lorsque le pouls est disponible. La vibration est facultative.
4. Teste **Pause → Reprendre** : la durée effective et les zones ne doivent pas inclure les pauses.
5. Termine après **au moins une minute effective**. Vérifie l'entraînement **une fois** dans Apple Santé, et **une fois** dans BILUX → Sport.
6. Dans l'historique Sport, appuie sur **DÉBRIEF NUCLEAR LIVE** pour afficher les observations. Les barres de zones peuvent être à zéro si le capteur n'a pas fourni suffisamment de données ; elles ne sont pas artificiellement complétées.
7. Ferme et rouvre BILUX : le rapport doit rester présent. Ne pas s'attendre à un débrief pour les séances effectuées **avant** V6.2, car leurs statistiques n'ont pas été conservées par les versions précédentes.

### Sécurité et sens des zones

Ces zones sont une **visualisation indicative** du pouls en fonction du seuil que tu saisis, et non des consignes de sport ou un avis médical. Le chiffre **190 BPM** est seulement la valeur initiale du curseur, **pas** une estimation validée de ta FC maximale. Choisis un repère cohérent avec tes propres données et recommandations médicales si nécessaire. La montre peut aussi manquer des mesures : le débrief distingue donc lectures observées et durées estimées.

### Retour arrière

Ne pas supprimer la version `bilux-v6.1.2-widget-signing` / build 21, ni le profil `bilux_widget_appstore`. Tu pourras revenir à ce build TestFlight si une régression apparaît.
