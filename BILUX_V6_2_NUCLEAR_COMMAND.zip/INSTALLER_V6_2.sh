#!/usr/bin/env bash
set -euo pipefail
BASE='bilux-v6.1.2-widget-signing'
DEST='bilux-v6.2-nuclear-command'
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail() { printf '❌ %s\n' "$*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Place-toi à la racine du dépôt BILUX.'
[[ "$(git branch --show-current)" == "$BASE" ]] || fail "Branche attendue : $BASE."
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications locales suivies non sauvegardées.'
git diff --cached --quiet || fail 'Index Git non vide.'
! git show-ref --verify --quiet "refs/heads/$DEST" || fail "La branche $DEST existe déjà."
command -v python3 >/dev/null || fail 'Python3 introuvable.'
git var GIT_AUTHOR_IDENT >/dev/null 2>&1 || fail 'Identité Git absente.'
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
python3 "$HERE/APPLIQUER_V6_2.py" "$PWD" "$TMP" || fail 'Base incompatible. Aucun fichier du projet modifié.'
FILES=(BiluxIOS/Models.swift BiluxIOS/BiluxStore.swift BiluxIOS/BiluxScreens.swift BiluxIOS/WatchPhoneBridge.swift BiluxWatch/WatchRootView.swift BiluxWatch/WatchBridge.swift)
for f in "${FILES[@]}"; do [[ -s "$TMP/$f" ]] || fail "Fichier préparé absent: $f"; done
if command -v swiftc >/dev/null 2>&1; then
  for f in "${FILES[@]}"; do swiftc -frontend -parse "$TMP/$f" || fail "Erreur de syntaxe Swift: $f"; done
  echo '✅ Analyse syntaxique Swift réussie (compilation Xcode encore nécessaire).'
fi
# The watched WidgetKit bundle, profile and codemagic.yaml are left untouched.
git switch -c "$DEST"
for f in "${FILES[@]}"; do cp "$TMP/$f" "$f"; done
git add -- "${FILES[@]}"
git diff --cached --check || fail 'Diff Git invalide.'
git commit -m 'BILUX V6.2 - Nuclear Command zones and workout debrief'
if [[ "${BILUX_TEST_NO_PUSH:-0}" == '1' ]]; then
  echo '🧪 Test local: push désactivé.'
else
  git push -u origin "$DEST" || fail "Commit local conservé; relance git push -u origin $DEST"
fi
echo "✅ BILUX V6.2 créée sur $DEST. Vérifier iPhone et Watch sur Codemagic."
