#!/usr/bin/env bash
set -euo pipefail
BRANCH='bilux-v6.2-nuclear-command'
fail() { printf '❌ %s\n' "$*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Place-toi à la racine du dépôt.'
[[ "$(git branch --show-current)" == "$BRANCH" ]] || fail "Branche $BRANCH attendue."
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications suivies non sauvegardées.'
git diff --cached --quiet || fail 'Index Git non vide.'
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
python3 - "$TMP" <<'PY'
from pathlib import Path
import plistlib,sys
root=Path.cwd(); out=Path(sys.argv[1])
for f in ['BiluxIOS/Info.plist','BiluxWatch/Info.plist','BiluxWatchWidget/Info.plist']:
    p=root/f
    d=plistlib.loads(p.read_bytes())
    if str(d.get('CFBundleVersion')) != '21':
        raise SystemExit(f'❌ Build 21 requis dans {f}. Aucun fichier modifié.')
    d['CFBundleVersion']='22'
    q=out/f;q.parent.mkdir(parents=True,exist_ok=True)
    q.write_bytes(plistlib.dumps(d,sort_keys=False))
p=root/'BiluxIOS.xcodeproj/project.pbxproj'
s=p.read_text(encoding='utf8')
needle='CURRENT_PROJECT_VERSION = 21;'
if s.count(needle) != 2 or 'BiluxWatchWidget' not in s:
    raise SystemExit('❌ Cible WidgetKit ou ses 2 numéros CURRENT_PROJECT_VERSION introuvables. Aucun fichier modifié.')
q=out/'BiluxIOS.xcodeproj/project.pbxproj';q.parent.mkdir(parents=True,exist_ok=True)
q.write_text(s.replace(needle,'CURRENT_PROJECT_VERSION = 22;'),encoding='utf8')
print('✅ iPhone, Watch et widget prêts pour build 22 (zone temporaire).')
PY
if command -v plutil >/dev/null 2>&1; then plutil -lint "$TMP/BiluxIOS.xcodeproj/project.pbxproj" || fail 'Projet Xcode invalide.'; fi
FILES=(BiluxIOS/Info.plist BiluxWatch/Info.plist BiluxWatchWidget/Info.plist BiluxIOS.xcodeproj/project.pbxproj)
for f in "${FILES[@]}"; do cp "$TMP/$f" "$f"; done
git add -- "${FILES[@]}";git diff --cached --check || fail 'Diff Git invalide.'
git commit -m 'BILUX V6.2 - Build 22 iPhone Watch Widget'
if [[ "${BILUX_TEST_NO_PUSH:-0}" == '1' ]]; then echo '🧪 Test local : push désactivé.'; else git push origin "$BRANCH" || fail 'Commit effectué localement; relance git push.'; fi
echo '✅ Build 22 préparé. Lancer le workflow de publication TestFlight sur cette branche.'
