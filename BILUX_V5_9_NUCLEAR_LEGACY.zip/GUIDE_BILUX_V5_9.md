# BILUX V5.9 — NUCLEAR LEGACY

**Base attendue :** V5.8.3, branche `bilux-v5.8.3-codex-touch-fix`, build 17.  
**Nouvelle branche :** `bilux-v5.9-nuclear-legacy`.  
**Prochain build TestFlight :** 18.

## Fonctionnalités

- Profil RPG ouvert depuis l'Accueil ou l'onglet Ascension.
- Titres équipables : titre de départ + 12 titres adossés aux trophées V5.8.
- Six auras (de l'étincelle à la lumière éternelle) liées aux rangs, victoires ou niveau 100.
- Cinq emblèmes (insigne de départ, vétéran, Gardien, Souverain, Ascension).
- Cartes reliques des deux boss avec nombre de victoires reconnu depuis V5.5.
- Titre, emblème et aura affichés sur le portrait existant, sans modifier ses proportions.
- Selections sauvegardées dans `BiluxData.legacyLoadout`, champ **optionnel** pour les anciennes sauvegardes.
- Si un export BILUX V5.9 est restauré sur un journal vide, le choix de titre/aura/emblème est aussi restauré.
- Aucun effet sur les XP, les quêtes, les boss, la synchronisation Watch ni les données HealthKit.

## Installation iPhone → GitHub → Codespaces

1. Depuis BILUX, exporte une sauvegarde JSON **privée** et conserve-la hors du dépôt GitHub.
2. Sur GitHub, choisis `bilux-v5.8.3-codex-touch-fix`, puis **Add file → Upload files** et dépose `BILUX_V5_9_NUCLEAR_LEGACY.zip` ; valide avec **Commit changes**.
3. Dans le terminal Codespaces, depuis la racine du dépôt :

```bash
git switch bilux-v5.8.3-codex-touch-fix && git pull --ff-only origin bilux-v5.8.3-codex-touch-fix && unzip -o BILUX_V5_9_NUCLEAR_LEGACY.zip -d /tmp/bilux-v59 && bash /tmp/bilux-v59/INSTALLER_V5_9.sh
```

L'installateur fusionne en **zone temporaire**, s'arrête si un conflit existe et contrôle la syntaxe Swift quand `swiftc` est disponible. Il ne remplace pas les fichiers sur la branche stable.

## Deux vérifications obligatoires sur Codemagic

Sur `bilux-v5.9-nuclear-legacy` :

1. **BILUX — Vérifier le projet iOS (sans Apple Developer)**
2. **BILUX V4.1 — Vérifier Apple Watch (sans signature)**

**Seulement si les deux réussissent**, reviens dans Codespaces :

```bash
bash /tmp/bilux-v59/PREPARER_BUILD_18.sh
```

Ce script exige les deux bundles au build 17 et les passe ensemble au build **18** (sans lancer deux fois la même préparation).

Ensuite Codemagic → `BILUX — Publier sur TestFlight` sur la branche V5.9, puis App Store Connect et installation sur iPhone/Watch.

## Tests manuels après TestFlight

- Sur Accueil → **NUCLEAR LEGACY**, sélectionner un titre disponible et revenir à l'Accueil : le badge affiche le titre.
- Choisir l'aura de départ et une aura déverrouillée, vérifier que le portrait n'est ni déformé ni tronqué.
- Vérifier les emblèmes et les reliques scellées, aucune récompense XP au simple appui.
- Ouvrir les deux dossiers de combat du Codex : les deux boutons fonctionnent comme en V5.8.3.
- Vérifier que la progression XP, le nombre de séances et Watch 2.0 sont inchangés.
- Exporter une sauvegarde V5.9 privée : l'objet `legacyLoadout` doit contenir `titleID`, `auraID`, `crestID` après équipement.

**Limite :** Les tests locaux contrôlent la syntaxe et l'installation. Seule la compilation Codemagic valide le projet iOS/watchOS, et seul TestFlight confirme les interactions tactiles réelles.
