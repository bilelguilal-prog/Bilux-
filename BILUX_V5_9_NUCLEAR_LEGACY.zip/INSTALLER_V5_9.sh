#!/usr/bin/env bash
set -euo pipefail
BASE='bilux-v5.8.3-codex-touch-fix'
DEST='bilux-v5.9-nuclear-legacy'
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail(){ echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Lance depuis la racine du dépôt BILUX.'
[[ "$(git branch --show-current)" == "$BASE" ]] || fail "Branche attendue : $BASE."
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications locales détectées : annulation.'
git diff --cached --quiet || fail 'Modifications indexées détectées.'
! git show-ref --quiet --verify "refs/heads/$DEST" || fail "La branche $DEST existe déjà."
command -v diff3 >/dev/null || fail 'Outil diff3 absent du Codespace.'
command -v python3 >/dev/null || fail 'Python 3 absent du Codespace.'
git var GIT_AUTHOR_IDENT >/dev/null 2>&1 || fail 'Identité Git non configurée.'
[[ -f "$HERE/APPLIQUER_V5_9.py" ]] || fail 'Archive ZIP incomplète.'
TEMP="$(mktemp -d)"
trap 'rm -rf "$TEMP"' EXIT
python3 "$HERE/APPLIQUER_V5_9.py" "$(pwd)" "$TEMP/staged" || fail 'Base incompatible : aucun fichier source modifié.'
if command -v swiftc >/dev/null 2>&1; then
  swiftc -frontend -parse "$TEMP/staged/BiluxIOS/BiluxScreens.swift" "$TEMP/staged/BiluxIOS/Models.swift" "$TEMP/staged/BiluxIOS/BiluxStore.swift" || fail 'Erreur de syntaxe Swift : aucun fichier modifié.'
  echo '✅ Contrôle de syntaxe Swift validé.'
else
  echo 'ℹ️ Pas de swiftc dans le Codespace ; compilations réelles à faire dans Codemagic.'
fi
git switch -c "$DEST"
cp "$TEMP/staged/BiluxIOS/BiluxScreens.swift" BiluxIOS/BiluxScreens.swift
cp "$TEMP/staged/BiluxIOS/Models.swift" BiluxIOS/Models.swift
cp "$TEMP/staged/BiluxIOS/BiluxStore.swift" BiluxIOS/BiluxStore.swift
git add -- BiluxIOS/BiluxScreens.swift BiluxIOS/Models.swift BiluxIOS/BiluxStore.swift
git diff --cached --check || fail 'Contrôle Git du correctif échoué.'
git commit -m 'BILUX V5.9 - Nuclear Legacy profile and cosmetic rewards'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != 1 ]]; then
  git push -u origin "$DEST" || fail "Push échoué : git push -u origin $DEST"
else
  echo '🧪 Test local : push désactivé.'
fi
echo "✅ BILUX V5.9 installée sur $DEST."
echo '➡️ Lance les deux vérifications iOS + Watch dans Codemagic ; build 18 après double validation.'
