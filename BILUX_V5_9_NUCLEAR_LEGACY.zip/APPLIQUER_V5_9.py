#!/usr/bin/env python3
"""Fusion non-destructive de BILUX V5.9 depuis une base V5.8.3.
Écrit uniquement dans le répertoire temporaire fourni par l'installateur.
"""
from pathlib import Path
import subprocess,sys

if len(sys.argv) != 3:
    raise SystemExit('Usage: APPLIQUER_V5_9.py DOSSIER_DEPOT DOSSIER_TEMP')
repo = Path(sys.argv[1]).resolve()
dest = Path(sys.argv[2]).resolve()
root = Path(__file__).resolve().parent
names = ['BiluxScreens.swift','Models.swift','BiluxStore.swift']

markers = {
    'BiluxScreens.swift': ['// MARK: - BILUX V5.9 · NUCLEAR LEGACY'] ,
    'Models.swift': ['struct BILUXV59Loadout: Codable'],
    'BiluxStore.swift': ['func equipLegacyTitle(_ id: String)']
}

for filename in names:
    existing = repo / 'BiluxIOS' / filename
    base = root / 'BASE' / filename
    new = root / 'NEW' / filename
    if not (existing.is_file() and base.is_file() and new.is_file()):
        raise SystemExit(f'❌ Fichier manquant : {filename}. Aucun fichier du projet modifié.')
    current_text = existing.read_text(encoding='utf-8')
    if filename == 'BiluxScreens.swift' and ('V5.8.3 : portraits hors hit testing' not in current_text or 'private struct BILUXV58Codex' not in current_text):
        raise SystemExit('❌ V5.8.3 tactile attendue, fichier incompatible. Aucun fichier modifié.')
    if filename == 'Models.swift' and 'longAscensionAnchor: LongAscensionAnchor?' not in current_text:
        raise SystemExit('❌ Modèle V5.5 absent. Aucun fichier modifié.')
    if filename == 'BiluxStore.swift' and 'func exportJSON()' not in current_text:
        raise SystemExit('❌ Sauvegarde JSON absente. Aucun fichier modifié.')
    if any(marker in current_text for marker in markers[filename]):
        raise SystemExit(f'❌ V5.9 déjà appliquée dans {filename}. Aucun fichier modifié.')

    # Fusion à trois voies : la copie locale peut avoir des changements indépendants.
    # En cas de conflit, aucun fichier source n'est modifié.
    proc = subprocess.run(['diff3','-m',str(existing),str(base),str(new)], capture_output=True)
    if proc.returncode == 0 and b'<<<<<<<' not in proc.stdout and b'>>>>>>>' not in proc.stdout:
        merged = proc.stdout.decode('utf-8')
    elif current_text.startswith(base.read_text(encoding='utf-8')):
        # Cas simple : seul un commentaire indépendant a été ajouté en fin
        # de fichier. Préserver cet ajout sans tenter de forcer un conflit.
        extra = current_text[len(base.read_text(encoding='utf-8')):]
        merged = new.read_text(encoding='utf-8') + extra
    else:
        raise SystemExit(f'❌ Fusion impossible dans {filename}. Aucun fichier du projet modifié ; demande un correctif ciblé.')
    if not all(marker in merged for marker in markers[filename]):
        raise SystemExit(f'❌ Vérification post-fusion impossible pour {filename}. Aucun fichier modifié.')
    target = dest / 'BiluxIOS' / filename
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(merged,encoding='utf-8')
    print(f'✅ {filename} : fusion préparée et vérifiée (projet non modifié).')
print('✅ BILUX V5.9 préparée en zone temporaire.')
