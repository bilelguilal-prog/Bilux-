#!/usr/bin/env python3
"""Stage strict BILUX V6.4 lightning engine on the validated V6.3 build 23."""
from pathlib import Path
import plistlib
import sys

if len(sys.argv) != 3:
    raise SystemExit('Usage: APPLIQUER_V6_4.py RACINE_DEPOT DOSSIER_TEMPORAIRE')
repo, temp = [Path(p).resolve() for p in sys.argv[1:]]
here = Path(__file__).resolve().parent

def stop(msg):
    raise SystemExit('❌ ' + msg + ' — aucune source modifiée')

def one(source, original, revised, label):
    found = source.count(original)
    if found != 1:
        stop(f'{label} : 1 occurrence attendue, {found} trouvées')
    return source.replace(original, revised, 1)

for relative in ('BiluxIOS/Info.plist', 'BiluxWatch/Info.plist', 'BiluxWatchWidget/Info.plist'):
    try:
        value = plistlib.loads((repo/relative).read_bytes()).get('CFBundleVersion')
    except Exception as e:
        stop(f'Impossible de lire {relative} : {e}')
    if str(value) != '23':
        stop(f'Build 23 attendu dans {relative}, reçu {value}')
if not (repo/'BiluxWatchWidget/NuclearLiveWidget.swift').is_file():
    stop('WidgetKit V6.1.3 absent')
if not (repo/'scripts/assign_widget_signing.py').is_file():
    stop('Correctif de signature widget absent')

model_path = repo/'BiluxIOS/Models.swift'
if not model_path.is_file():
    stop('Models.swift absent')
model = model_path.read_text(encoding='utf-8')
if 'struct V63MasterySnapshot {' not in model or 'struct NuclearLiveReport:' not in model:
    stop('Modèles V6.3 ou Nuclear Live non reconnus')

source_path = repo/'BiluxIOS/BiluxScreens.swift'
if not source_path.is_file():
    stop('BiluxScreens.swift absent')
s = source_path.read_text(encoding='utf-8')
if 'V64StormLightning' in s:
    stop('V6.4 déjà appliquée')
if s.count('private struct V63NuclearMasteryView: View') != 1:
    stop('Écran de maîtrise V6.3 manquant')

storm = (here/'STORM_ENGINE_V64.swift.txt').read_text(encoding='utf-8')
s = one(s, 'private struct NuclearHeroAura: View {', storm + '\nprivate struct NuclearHeroAura: View {', 'Injection moteur orage')
s = one(s,
'''    let minimumStage: Int
    @Environment(\\.accessibilityReduceMotion) private var reduceMotion''',
'''    let minimumStage: Int
    let masteryCount: Int
    let dominantPath: String
    @State private var stormIsVisible = false
    @AppStorage("bilux.v64.stormIntensity") private var stormIntensity = "epic"
    @Environment(\\.accessibilityReduceMotion) private var reduceMotion''',
'Entrées effectif de maîtrise et intensité')
s = one(s,
'''    init(level: Int, effectsEnabled: Bool, stageOverride: NuclearStage? = nil, minimumStage: Int = 0) {
        self.level = level
        self.effectsEnabled = effectsEnabled
        self.stageOverride = stageOverride
        self.minimumStage = minimumStage
    }''',
'''    init(level: Int, effectsEnabled: Bool, stageOverride: NuclearStage? = nil, minimumStage: Int = 0,
         masteryCount: Int = 0, dominantPath: String = "core") {
        self.level = level
        self.effectsEnabled = effectsEnabled
        self.stageOverride = stageOverride
        self.minimumStage = minimumStage
        self.masteryCount = masteryCount
        self.dominantPath = dominantPath
    }''', 'Initialiseur des transformations')
s = one(s,
'''                    .opacity(lockedPreview ? 0.32 : 0.75)
                    .blendMode(.screen)
                    .allowsHitTesting(false)

                VStack {''',
'''                    .opacity(lockedPreview ? 0.32 : 0.75)
                    .blendMode(.screen)
                    .allowsHitTesting(false)

                // V6.4 : éclairs vectoriels réellement mouvants, sans bouger ni recadrer l'avatar.
                // Contrôlés par le toggle existant + Réduire les animations d'iOS.
                if animate && stormIsVisible {
                    V64StormLightning(stage: stage.id, masteryCount: masteryCount,
                                     dominantPath: dominantPath,
                                     epic: stormIntensity != "balanced")
                        .blendMode(.screen)
                        .allowsHitTesting(false)
                }

                VStack {''', 'Overlay orage autour du portrait')

s = one(s,
'''NuclearHeroAura(level: journal.heroLevel, effectsEnabled: effectsEnabled, stageOverride: homeStage, minimumStage: journal.unlockedStageIndex)''',
'''NuclearHeroAura(level: journal.heroLevel, effectsEnabled: effectsEnabled,
                                stageOverride: homeStage, minimumStage: journal.unlockedStageIndex,
                                masteryCount: V63MasterySnapshot.evaluate(journal.data).unlockedTotal,
                                dominantPath: V64StormMastery.dominantPath(journal.data))''',
'Avatar du tableau de bord')
s = one(s,
'''NuclearHeroAura(level: journal.heroLevel, effectsEnabled: effectsEnabled, stageOverride: NuclearStage.all[selectedStage], minimumStage: journal.unlockedStageIndex)''',
'''NuclearHeroAura(level: journal.heroLevel, effectsEnabled: effectsEnabled,
                                        stageOverride: NuclearStage.all[selectedStage],
                                        minimumStage: journal.unlockedStageIndex,
                                        masteryCount: V63MasterySnapshot.evaluate(journal.data).unlockedTotal,
                                        dominantPath: V64StormMastery.dominantPath(journal.data))''',
'Avatar de l’écran Ascension')

s = one(s,
'''struct AscensionScreen: View {
    @EnvironmentObject private var journal: BiluxStore
    @State private var showingImporter = false''',
'''struct AscensionScreen: View {
    @EnvironmentObject private var journal: BiluxStore
    @AppStorage("bilux.v64.stormIntensity") private var stormIntensity = "epic"
    @State private var showingImporter = false''', 'Réglage permanent intensité')
s = one(s,
'''                        Toggle("Animations nucléaires", isOn: $effectsEnabled).tint(Nuclear.gold)
                        Text("Désactive les effets animés pour économiser la batterie. Le réglage de réduction des animations d'iOS est respecté.")''',
'''                        Toggle("Animations nucléaires", isOn: $effectsEnabled).tint(Nuclear.gold)
                        Text("TEMPÊTE ÉLECTRIQUE · V6.4")
                            .font(.caption.bold()).foregroundStyle(Nuclear.gold)
                        Picker("Intensité de l'orage", selection: $stormIntensity) {
                            Text("Équilibré").tag("balanced")
                            Text("Épique ⚡").tag("epic")
                        }
                        .pickerStyle(.segmented)
                        .disabled(!effectsEnabled)
                        Text("Arcs électriques mouvants, ramifications et étincelles : la voie de maîtrise dominante modifie leur couleur. Mode Épique activé par défaut. Aucun effet sur les XP.")
                            .font(.caption2).foregroundStyle(Nuclear.muted)
                        Text("Désactive les effets animés pour économiser la batterie. Le réglage de réduction des animations d'iOS est respecté.")''',
'Commande visuelle Équilibré/Épique')
# Cinematic reveal: the same storm now accompanies real rank transformations.
s = one(s,
'''                RadialGradient(colors: [stage.accent.opacity(phase >= 2 ? 0.37 : 0.10), .clear],
                               center: .center, startRadius: 25, endRadius: 340)
                    .blendMode(.screen)
                    .allowsHitTesting(false)

                VStack(spacing: 12)''',
'''                RadialGradient(colors: [stage.accent.opacity(phase >= 2 ? 0.37 : 0.10), .clear],
                               center: .center, startRadius: 25, endRadius: 340)
                    .blendMode(.screen)
                    .allowsHitTesting(false)
                if animated {
                    V64StormLightning(stage: stage.id, masteryCount: 0,
                                     dominantPath: "core", epic: true)
                        .blendMode(.screen)
                        .allowsHitTesting(false)
                }

                VStack(spacing: 12)''',
'Orage dans la cinématique')

# Free the rendering timeline while the tab or screen is not visible.
s = one(s,
        '.onAppear { energized = animate }',
        '.onAppear { energized = animate; stormIsVisible = true }',
        'Activation visible de la tempête')
s = one(s,
        '.onDisappear { fadeTask?.cancel() }',
        '.onDisappear { fadeTask?.cancel(); stormIsVisible = false }',
        'Arrêt du moteur hors écran')

out = temp/'BiluxIOS/BiluxScreens.swift'
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(s, encoding='utf-8')
print('✅ Orage procédural intégré au tableau de bord, à Ascension et aux cinématiques.')
print('✅ Réglage Équilibré/Épique installé sans changer la sauvegarde JSON.')
print('✅ Aucun changement de modèles, de HealthKit, de la Watch, du widget ni des XP.')
