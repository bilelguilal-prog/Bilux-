#!/usr/bin/env bash
set -euo pipefail
BASE='bilux-v6.3-nuclear-mastery'
NEW='bilux-v6.4-nuclear-evolution'
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail(){ echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Lance cette commande à la racine du dépôt BILUX.'
[[ "$(git branch --show-current)" == "$BASE" ]] || fail "Branche de départ attendue : $BASE"
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications locales suivies non commitées : arrêt de sécurité.'
git diff --cached --quiet || fail 'Index Git non vide.'
! git show-ref --quiet --verify "refs/heads/$NEW" || fail "La branche $NEW existe déjà."
command -v python3 >/dev/null || fail 'Python 3 introuvable.'
git var GIT_AUTHOR_IDENT >/dev/null 2>&1 || fail 'Identité Git non configurée.'
TEMP="$(mktemp -d)"; trap 'rm -rf "$TEMP"' EXIT
python3 "$HERE/APPLIQUER_V6_4.py" "$(pwd)" "$TEMP" || fail 'Source incompatible, aucun fichier modifié.'
[[ -s "$TEMP/BiluxIOS/BiluxScreens.swift" ]] || fail 'Écran Swift temporaire manquant.'
if command -v swiftc >/dev/null 2>&1; then
    swiftc -frontend -parse "$TEMP/BiluxIOS/BiluxScreens.swift" BiluxIOS/Models.swift || fail 'Erreur de syntaxe Swift.'
    swiftc -typecheck BiluxIOS/Models.swift || fail 'Modèles Swift invalides.'
    echo '✅ Syntaxe Swift et modèles validés. Xcode doit encore confirmer la compilation.'
else
    echo 'ℹ️ Swift absent dans Codespaces : vérification définitive sur Codemagic.'
fi
git switch -c "$NEW"
cp "$TEMP/BiluxIOS/BiluxScreens.swift" BiluxIOS/BiluxScreens.swift
git add -- BiluxIOS/BiluxScreens.swift
git diff --cached --check || fail 'Diff Git invalide.'
git commit -m 'BILUX V6.4 - Procedural thunderstorm transformation effects'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
    git push -u origin "$NEW" || fail "Push impossible : git push -u origin $NEW"
else
    echo '🧪 Simulation locale : aucun push.'
fi
echo "✅ V6.4 installée sur $NEW. Lancer les deux tests Codemagic avant le build 24."
