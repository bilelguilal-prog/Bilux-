# ☢️⚡ BILUX V6.4 — NUCLEAR EVOLUTION / TEMPÊTE ÉLECTRIQUE

**Base validée** : `bilux-v6.3-nuclear-mastery` — build **23** sur iPhone, Apple Watch et WidgetKit.  
**Nouvelle branche** : `bilux-v6.4-nuclear-evolution`.  
**Futur build TestFlight** : **24**, uniquement après les vérifications Codemagic.

## Ce que change vraiment la V6.4

- Les éclairs autour des portraits **se déplacent, changent de trajectoire et se ramifient**. Le moteur utilise `TimelineView` et `Canvas` de SwiftUI pour tracer des arcs vectoriels en temps réel, avec un cœur lumineux, une gaine colorée et des étincelles en mouvement.
- Le développement de l'orage suit le **rang visuel** et les **capacités réellement débloquées** dans les quatre voies de Nuclear Mastery. Il ne modifie aucune valeur de jeu. La voie dominante colore les arcs : Force (or), Endurance (orange), Régularité (violet), Maîtrise (bleu clair / or).
- Les effets sont visibles sur le **portrait de l'Accueil**, le **portrait d'Ascension**, et les **cinématiques de transformation**.
- Dans **Ascension → Effets visuels**, le sélecteur **Équilibré / Épique ⚡** permet de choisir l'intensité. **Épique** est sélectionné par défaut.
- Le réglage existant **Animations nucléaires** continue d'arrêter tous les effets ; **Réduire les animations** dans iOS est respecté. La temporàte cesse aussi d'être dessinée quand le portrait sort de l'écran. Pas de grands flashs blancs plein écran.
- **Le cadrage et la taille des portraits ne sont jamais animés**, pour éviter les distorsions de l'avatar qui avaient été corrigées dans V5.3.2.

**Inchangé** : moteur XP et niveau 1–100, arbre de maîtrise V6.3 et ses 12 capacités, données JSON, HealthKit, Nuclear Live, iPhone/Watch sync, zones cardiaques, complication WidgetKit et signatures Apple de Codemagic.

## 1 — Sauvegarde obligatoire

Avant d'installer, exporte le **JSON BILUX** depuis l'application et conserve-le **dans Fichiers / iCloud privé**. Ne le publie pas sur GitHub : il peut contenir des données de santé.

## 2 — Mettre le ZIP sur GitHub

1. Depuis l'iPhone, ouvre ton dépôt `https://github.com/bilelguilal-prog/Bilux-`.
2. Choisis la branche **`bilux-v6.3-nuclear-mastery`** (build 23 validé).
3. **Add file → Upload files**, ajoute `BILUX_V6_4_NUCLEAR_EVOLUTION.zip` à la racine, puis **Commit changes**.

## 3 — Installer avec Codespaces

Dans le terminal, à la racine du dépôt, colle cette commande **en une seule fois** :

```bash
git switch bilux-v6.3-nuclear-mastery && git pull --ff-only origin bilux-v6.3-nuclear-mastery && unzip -o BILUX_V6_4_NUCLEAR_EVOLUTION.zip -d /tmp/bilux-v64 && bash /tmp/bilux-v64/INSTALLER_V6_4.sh
```

L'installateur exige le build 23, le code de V6.3 et la signature WidgetKit, puis construit le correctif dans un dossier temporaire avant toute modification. Il crée et pousse la branche **`bilux-v6.4-nuclear-evolution`**. Il ne modifie que **`BiluxIOS/BiluxScreens.swift`**. Les fichiers du moteur, de la Watch et les images ne sont pas touchés.

## 4 — Tester Codemagic (sans signature)

Choisis la branche **`bilux-v6.4-nuclear-evolution`** et lance dans cet ordre :

1. **BILUX — Vérifier le projet iOS**.
2. **BILUX V4.1 — Vérifier Apple Watch**.

Si l'un échoue, **ne prépare pas le build 24** : envoie la première erreur `error:` et quelques lignes autour.

Ces deux tests sont indispensables : les contrôles Linux locaux analysent la syntaxe et les modèles Swift mais ne remplacent **pas** Xcode et les frameworks Apple.

## 5 — Préparer le build 24

**Uniquement lorsque les deux tests sont verts :**

```bash
bash /tmp/bilux-v64/PREPARER_BUILD_24.sh
```

Si tu as fermé le Codespace, décompresse d'abord le ZIP de nouveau avec `unzip -o BILUX_V6_4_NUCLEAR_EVOLUTION.zip -d /tmp/bilux-v64`.

Cette commande ajuste `CFBundleVersion` **23 → 24** dans les trois bundles (iPhone, Watch, WidgetKit) et `CURRENT_PROJECT_VERSION` **23 → 24** dans les deux configurations du widget, puis commit et push. Elle ne peut pas être appliquée deux fois.

Ensuite, dans Codemagic, lance **BILUX — Publier sur TestFlight** sur la branche `bilux-v6.4-nuclear-evolution`, puis installe **1.0 (24)** depuis TestFlight.

## 6 — Essais visuels à effectuer sur l'iPhone

1. **Accueil** : regarder le portrait 10 secondes. Les arcs doivent **changer de chemin**, créer de petites ramifications, former plusieurs halos et laisser de petites étincelles ; ce ne sont pas de simples images fixes qui clignotent.
2. **Ascension** : sur la forme déjà débloquée, voir les mêmes arcs. Les formes encore verrouillées restent en aperçu sans animation ; choisir une forme acquise pour le test.
3. **Ascension → Effets visuels** : comparer **Équilibré** et **Épique ⚡** (plus de branches et de particules, rafraîchissement plus rapide). Désactiver **Animations nucléaires** doit couper la tempête.
4. **Ascension → formes débloquées → REVOIR LA CINÉMATIQUE** : les décharges doivent entourer la transformation sans étirer l'illustration.
5. **Réglages iOS → Accessibilité → Animation → Réduire les animations** : si activé, les éclairs doivent s'arrêter.
6. **Profil RPG → Nuclear Mastery** : les 4 voies, 12 capacités et chiffres existants doivent rester inchangés. Vérifier également les XP, Nuclear Live et le widget.
7. Fermer puis rouvrir BILUX : le choix d'intensité doit être conservé localement.

## Limites

- La densité de l'orage dépend des capacités *effectivement* débloquées. La couleur de la voie dominante ne change pas à chaque mouvement ; elle évolue avec la progression RPG.
- Les dessins vectoriels sont recalculés en temps réel : le mode Épique utilise plus de batterie ; choisis **Équilibré** si l'iPhone chauffe ou si tu préfères économiser l'énergie.
- Pour des raisons de confort visuel, le moteur limite les impulsions lumineuses locales et n'utilise pas de flash blanc généralisé. Le bouton **Animations nucléaires** permet de tout désactiver.
- L'effet existe pour les portraits iPhone et la cinématique. **Le widget et la Watch ne sont pas modifiés** par cette version.
