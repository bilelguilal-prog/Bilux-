#!/usr/bin/env bash
set -euo pipefail
BRANCH='bilux-v6.4-nuclear-evolution'
fail(){ echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Place-toi à la racine du dépôt BILUX.'
[[ "$(git branch --show-current)" == "$BRANCH" ]] || fail "Branche $BRANCH attendue."
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Des modifications locales sont présentes.'
git diff --cached --quiet || fail 'Index Git non vide.'
grep -q 'private struct V64StormLightning: View' BiluxIOS/BiluxScreens.swift || fail 'Moteur orage V6.4 absent.'
grep -q 'private struct V63NuclearMasteryView: View' BiluxIOS/BiluxScreens.swift || fail 'Arbre V6.3 absent.'
[[ -f scripts/assign_widget_signing.py ]] || fail 'Signature widget absente.'
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
python3 - "$TMP" <<'PY'
from pathlib import Path
import plistlib,sys
repo=Path.cwd();tmp=Path(sys.argv[1])
paths=['BiluxIOS/Info.plist','BiluxWatch/Info.plist','BiluxWatchWidget/Info.plist']
for rel in paths:
    try: data=plistlib.loads((repo/rel).read_bytes())
    except Exception as exc: raise SystemExit(f'❌ Fichier {rel} invalide : {exc}')
    if str(data.get('CFBundleVersion')) != '23':
        raise SystemExit(f'❌ Build 23 attendu dans {rel}. Aucun fichier modifié.')
    data['CFBundleVersion']='24'
    out=tmp/rel;out.parent.mkdir(parents=True,exist_ok=True)
    out.write_bytes(plistlib.dumps(data,sort_keys=False))
project=repo/'BiluxIOS.xcodeproj/project.pbxproj'
s=project.read_text(encoding='utf-8')
if s.count('CURRENT_PROJECT_VERSION = 23;') != 2 or 'BiluxWatchWidget' not in s:
    raise SystemExit('❌ Configuration de version WidgetKit différente de la V6.3. Aucun fichier modifié.')
out=tmp/'BiluxIOS.xcodeproj/project.pbxproj';out.parent.mkdir(parents=True,exist_ok=True)
out.write_text(s.replace('CURRENT_PROJECT_VERSION = 23;', 'CURRENT_PROJECT_VERSION = 24;'), encoding='utf-8')
print('✅ Build 24 préparé pour iPhone, Watch et WidgetKit.')
PY
if command -v plutil >/dev/null 2>&1; then
    plutil -lint "$TMP/BiluxIOS.xcodeproj/project.pbxproj" || fail 'Projet Xcode invalide.'
fi
FILES=(BiluxIOS/Info.plist BiluxWatch/Info.plist BiluxWatchWidget/Info.plist BiluxIOS.xcodeproj/project.pbxproj)
for rel in "${FILES[@]}"; do cp "$TMP/$rel" "$rel"; done
git add -- "${FILES[@]}"
git diff --cached --check || fail 'Diff Git invalide.'
git commit -m 'BILUX V6.4 - Build 24 iPhone Watch Widget'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
    git push origin "$BRANCH" || fail 'Commit local créé : relancer git push.'
else
    echo '🧪 Simulation locale : aucun push.'
fi
echo '✅ Build 24 prêt. Publier sur TestFlight après deux compilations Codemagic vertes.'
