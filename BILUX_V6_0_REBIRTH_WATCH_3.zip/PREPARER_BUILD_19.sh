#!/usr/bin/env bash
set -euo pipefail
BRANCH='bilux-v6.0-rebirth-watch3'
fail(){ printf '❌ %s\n' "$*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Place-toi à la racine du dépôt BILUX.'
[[ "$(git branch --show-current)" == "$BRANCH" ]] || fail "Branche attendue : $BRANCH."
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications suivies détectées.'
git diff --cached --quiet || fail 'Modifications indexées détectées.'
grep -q -F 'REBIRTH · WATCH 3.0' BiluxWatch/WatchRootView.swift || fail 'Watch 3.0 non installée.'
grep -q -F 'BILUXV60WatchAppearance' BiluxIOS/BiluxScreens.swift || fail 'Fiche personnage V6.0 absente.'
python3 - <<'PY'
from pathlib import Path
import plistlib
names = ['BiluxIOS/Info.plist', 'BiluxWatch/Info.plist']
all_plists = {}
for name in names:
    pl = plistlib.loads(Path(name).read_bytes())
    actual = str(pl.get('CFBundleVersion'))
    if actual != '18':
        raise SystemExit(f'❌ {name} : build 18 requis, trouvé {actual}. Rien modifié.')
    all_plists[name] = pl
for name, pl in all_plists.items():
    pl['CFBundleVersion'] = '19'
    Path(name).write_bytes(plistlib.dumps(pl,fmt=plistlib.FMT_XML,sort_keys=False))
    print(f'✅ {name} : build 18 → 19')
PY
git add -- BiluxIOS/Info.plist BiluxWatch/Info.plist
git diff --cached --check || fail 'Diff invalide.'
git commit -m 'BILUX V6.0 - TestFlight build 19 for iPhone and Watch'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
    git push -u origin "$BRANCH" || fail 'Le commit est local, push GitHub à reprendre.'
else
    echo '🧪 Simulation locale : push désactivé.'
fi
echo '✅ Build 19 prêt pour TestFlight.'
