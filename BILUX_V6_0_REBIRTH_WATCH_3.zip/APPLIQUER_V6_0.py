#!/usr/bin/env python3
"""BILUX V6.0 - REBIRTH / Watch 3.0. Prepare all files in staging, never modify the repo directly."""
from pathlib import Path
import sys

if len(sys.argv) != 3:
    sys.exit('Usage: python3 APPLIQUER_V6_0.py SOURCE_REPO STAGING_DIR')
repo = Path(sys.argv[1]).resolve()
stage = Path(sys.argv[2]).resolve()

def read(name):
    p = repo / name
    if not p.is_file(): raise SystemExit(f'❌ Fichier absent: {name}')
    return p.read_text(encoding='utf-8')

def replace(text, old, new, label):
    matches = text.count(old)
    if label == 'watch title aura' and matches == 2:
        return new.join(text.rsplit(old, 1))
    if matches != 1:
        raise SystemExit(f'❌ Base incompatible ({label}) : {matches} marqueur(s), 1 attendu. Aucun fichier modifié.')
    return text.replace(old,new,1)

files = {}
name = 'BiluxShared/WatchSnapshot.swift'
s = read(name)
s = replace(s, '    var updatedAt: Date\n', '''    var updatedAt: Date
    // V6.0 : nouveaux champs facultatifs pour lire aussi les anciens snapshots Watch 2.0.
    // Aucun renseignement médical supplémentaire n'est synchronisé.
    var xpRemaining: Int? = nil
    var weeklyWorkouts: Int? = nil
    var monthlyWorkouts: Int? = nil
    var quarterWorkouts: Int? = nil
    var workoutCount: Int? = nil
    var lastWorkoutLabel: String? = nil
    var equippedTitle: String? = nil
    var equippedAura: String? = nil
''', 'WatchSnapshot nouveaux champs')
files[name]=s

name='BiluxIOS/WatchPhoneBridge.swift'
s=read(name)
s=replace(s, '        let didCheckin = questStatus.todayCheckin\n        snapshot = WatchSnapshot(', '''        let didCheckin = questStatus.todayCheckin
        let appearance = journal.map { BILUXV60WatchAppearance($0) }
        let latest = data.workouts.max(by: { $0.date < $1.date })
        let lastLabel = latest.map { "\\($0.activity) · \\($0.durationMinutes) min" }
        snapshot = WatchSnapshot(''', 'WatchPhoneBridge profile input')
s=replace(s, '            ], updatedAt: now\n', '''            ], updatedAt: now,
            xpRemaining: BILUXV55Progression.remainingXP(data),
            weeklyWorkouts: questStatus.weeklyWorkouts,
            monthlyWorkouts: questStatus.monthlyWorkouts,
            quarterWorkouts: questStatus.quarterWorkouts,
            workoutCount: data.workouts.count,
            lastWorkoutLabel: lastLabel,
            equippedTitle: appearance?.title,
            equippedAura: appearance?.aura
''', 'WatchPhoneBridge new snapshot params')
files[name]=s

name='BiluxIOS/BiluxScreens.swift'
s=read(name)
s=replace(s, '// La bordure ne redimensionne ni ne recadre jamais les portraits de V5.3.2.\n', '''// Accessible depuis WatchPhoneBridge, sans exposer les catalogues cosmétiques.
@MainActor
func BILUXV60WatchAppearance(_ journal: BiluxStore) -> (title: String, aura: String) {
    (BILUXV59Legacy.activeTitle(journal).title, BILUXV59Legacy.activeAura(journal).title)
}

// La bordure ne redimensionne ni ne recadre jamais les portraits de V5.3.2.
''', 'helper accès apparence')
s=replace(s, '''                    profileHeader
                    SectionCaption(title: "Titres de légende")
''','''                    profileHeader
                    rebirthCharacterSheet
                    SectionCaption(title: "Titres de légende")
''','fiche personnage dans héritage')
s=replace(s, '    private var profileHeader: some View {\n', '''    // REBIRTH : des statistiques calculées à partir du journal, jamais des XP bonus.
    private var rebirthCharacterSheet: some View {
        let progress = BILUXV55Progression.currentQuestProgress(journal.data)
        let minutes = journal.data.workouts.reduce(0) { $0 + max(0, $1.durationMinutes) }
        return VStack(alignment: .leading, spacing: 10) {
            SectionCaption(title: "Rebirth · Fiche du combattant")
            NuclearCard {
                HStack(spacing: 8) {
                    Image(systemName: "person.crop.circle.fill")
                        .font(.title2).foregroundStyle(Nuclear.gold)
                    VStack(alignment: .leading, spacing: 3) {
                        Text("HÉRITAGE DU NOYAU")
                            .font(.caption.bold()).tracking(1).foregroundStyle(Nuclear.paleGold)
                        Text("Ta puissance reflète les séances consignées, sans modifier tes XP.")
                            .font(.caption2).foregroundStyle(Nuclear.muted)
                    }
                }
                HStack(spacing: 8) {
                    statPill("HEURES", "\\(minutes / 60) h")
                    statPill("EXERCICES", "\\(NuclearProgress.uniqueExercises(journal.data))")
                    statPill("SEMAINE", "\\(progress.weeklyWorkouts) / 3")
                }
                Text("PROCHAINE TRANSFORMATION")
                    .font(.system(size: 10, weight: .heavy)).foregroundStyle(Nuclear.gold)
                let stage = journal.unlockedStageIndex
                if stage >= NuclearStage.all.count - 1 {
                    Text("ASCENSION · FORMES MAÎTRISÉES")
                        .font(.caption.bold()).foregroundStyle(Nuclear.paleGold)
                } else {
                    let next = NuclearStage.all[stage + 1]
                    Text("\\(next.name) · niveau \\(next.minLevel)")
                        .font(.caption.bold()).foregroundStyle(.white)
                    ProgressView(value: Double(journal.heroLevel), total: Double(next.minLevel))
                        .tint(Nuclear.purple)
                }
                Text("Les périodes de repos n'enlèvent ni titres ni niveaux.")
                    .font(.caption2).foregroundStyle(Nuclear.muted)
            }
        }
    }

    private var profileHeader: some View {
''','fiche RPG nouvel élément')
s=replace(s,'Text("NUCLEAR LEGACY · V5.9")','Text("REBIRTH · V6.0")','titre profil')
files[name]=s

name='BiluxWatch/WatchRootView.swift'
s=read(name)
s=replace(s, '''            questPage.tag(2)
            V54WatchWorkoutView().tag(3)
''','''            questPage.tag(2)
            ascensionPage.tag(3)
            V54WatchWorkoutView().tag(4)
''','5 pages Watch')
s=replace(s,'Text("NUCLEAR WATCH 2.0")','Text("REBIRTH · WATCH 3.0")','label Watch 3.0')
s=replace(s,'''                            Text("\\(bridge.snapshot.totalXP) XP")
                                .font(.system(size: 12, weight: .semibold))
                                .foregroundStyle(V54ReactorTheme.secondary)
''','''                            Text("\\(bridge.snapshot.totalXP) XP")
                                .font(.system(size: 12, weight: .semibold))
                                .foregroundStyle(V54ReactorTheme.secondary)
                            if let remaining = bridge.snapshot.xpRemaining {
                                Text("Encore \\(remaining) XP")
                                    .font(.system(size: 9, weight: .semibold))
                                    .foregroundStyle(V54ReactorTheme.secondary)
                            }
''','XP remaining')
s=replace(s, '''                if bridge.snapshot.updatedAt == .distantPast {
''','''                if let title = bridge.snapshot.equippedTitle, !title.isEmpty {
                    V54ReactorCard(accent: V54ReactorTheme.purple) {
                        Label(title, systemImage: "crown.fill")
                            .font(.system(size: 11, weight: .heavy))
                            .foregroundStyle(V54ReactorTheme.paleGold)
                            .lineLimit(2).minimumScaleFactor(0.7)
                        if let aura = bridge.snapshot.equippedAura {
                            Label(aura, systemImage: "sparkles")
                                .font(.system(size: 10, weight: .semibold))
                                .foregroundStyle(V54ReactorTheme.purple)
                        }
                    }
                }
                if bridge.snapshot.updatedAt == .distantPast {
''','watch title aura')
s=replace(s,'''                    selectedPage = 3
''','''                    selectedPage = 4
''','Watch Forge navigation')
s=replace(s, '''                Button {
                    bridge.refresh()
                } label: {
                    Label("Synchroniser", systemImage: "arrow.clockwise")
''','''                Button {
                    selectedPage = 3
                } label: {
                    Label("LES GARDIENS", systemImage: "shield.fill")
                        .font(.caption2.bold())
                }
                .buttonStyle(.bordered)
                .tint(V54ReactorTheme.purple)

                Button {
                    bridge.refresh()
                } label: {
                    Label("Synchroniser", systemImage: "arrow.clockwise")
''','watch boss quick access')
s=replace(s, '''    private func whole(_ value: Double?) -> String {
''', '''    // ASCENSION : données du même calcul de jours éligibles que l'iPhone.
    private var ascensionPage: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 9) {
                V54ReactorTitle(text: "L'ASCENSION", symbol: "crown.fill")
                V54ReactorCard(accent: V54ReactorTheme.gold) {
                    Text("LA FORGE HEBDOMADAIRE")
                        .font(.system(size: 10, weight: .heavy))
                        .foregroundStyle(V54ReactorTheme.paleGold)
                    if let days = bridge.snapshot.weeklyWorkouts {
                        HStack {
                            Text("\\(days) / 3 journées")
                                .font(.system(size: 14, weight: .heavy))
                            Spacer()
                            Text(days >= 3 ? "ACCOMPLI" : "EN COURS")
                                .font(.system(size: 9, weight: .heavy))
                                .foregroundStyle(V54ReactorTheme.gold)
                        }
                        ProgressView(value: Double(min(3, max(0, days))), total: 3)
                            .tint(V54ReactorTheme.gold)
                    } else {
                        Text("Synchronise l'iPhone pour voir tes missions.")
                            .font(.caption2).foregroundStyle(V54ReactorTheme.secondary)
                    }
                }
                guardianCard(name: "GARDIEN DU RÉACTEUR", icon: "shield.fill",
                             done: bridge.snapshot.monthlyWorkouts, goal: 12,
                             accent: V54ReactorTheme.purple, span: "Mensuel")
                guardianCard(name: "SOUVERAIN DU NÉANT", icon: "crown.fill",
                             done: bridge.snapshot.quarterWorkouts, goal: 30,
                             accent: V54ReactorTheme.gold, span: "Trimestriel")
                if let count = bridge.snapshot.workoutCount {
                    V54ReactorCard {
                        Label("\\(count) séances consignées", systemImage: "dumbbell.fill")
                            .font(.caption2.bold()).foregroundStyle(V54ReactorTheme.paleGold)
                        if let recent = bridge.snapshot.lastWorkoutLabel {
                            Text("Dernière : \\(recent)")
                                .font(.system(size: 10))
                                .foregroundStyle(V54ReactorTheme.secondary)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }
                }
                Text("Les PV changent avec tes séances éligibles : 1 jour par date, au plus 5 par semaine. Aucun malus de repos.")
                    .font(.system(size: 9))
                    .foregroundStyle(V54ReactorTheme.secondary)
            }
            .padding(.horizontal, 5)
            .padding(.bottom, 8)
        }
        .containerBackground(.clear, for: .tabView)
    }

    private func guardianCard(name: String, icon: String, done: Int?, goal: Int,
                              accent: Color, span: String) -> some View {
        V54ReactorCard(accent: accent) {
            Label(name, systemImage: icon)
                .font(.system(size: 11, weight: .heavy))
                .foregroundStyle(accent)
                .fixedSize(horizontal: false, vertical: true)
            if let done {
                let capped = min(goal, max(0, done))
                let hp = max(0, Int((100.0 * Double(goal - capped) / Double(goal)).rounded()))
                HStack {
                    Text("\\(capped) / \\(goal) jours")
                        .font(.system(size: 12, weight: .bold))
                    Spacer()
                    Text("\\(hp)% PV")
                        .font(.system(size: 11, weight: .heavy))
                }
                ProgressView(value: Double(capped), total: Double(goal)).tint(accent)
                Text(capped >= goal ? "VICTOIRE" : "\\(span) · phase \\(min(4, Int(Double(capped) / Double(goal) * 4) + 1))")
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundStyle(V54ReactorTheme.secondary)
            } else {
                Text("Données en attente de l'iPhone")
                    .font(.caption2).foregroundStyle(V54ReactorTheme.secondary)
            }
        }
    }

    private func whole(_ value: Double?) -> String {
''','watch ascension content')
# New pause/resume UX, backwards compatible with saved start time
s=replace(s, '''    @AppStorage("bilux.watch.workout.activity") private var activity = V54CombatMode.musculation.rawValue
''','''    @AppStorage("bilux.watch.workout.activity") private var activity = V54CombatMode.musculation.rawValue
    @AppStorage("bilux.watch.workout.pausedAt") private var pausedAt: Double = 0
    @AppStorage("bilux.watch.workout.pauseSeconds") private var pauseSeconds: Double = 0
''','pause persistent storage')
s=replace(s, '''    private var running: Bool { startTimestamp > 0 }

    var body: some View {
        ScrollView {
            VStack(spacing: 9) {
                V54ReactorTitle(text: "LA FORGE", symbol: "dumbbell.fill")
''','''    private var running: Bool { startTimestamp > 0 }
    private var paused: Bool { running && pausedAt > 0 }

    private func elapsedSeconds(now: Date) -> Int {
        let stop = paused ? pausedAt : now.timeIntervalSince1970
        return max(0, Int(stop - startTimestamp - pauseSeconds))
    }
    private func resetTimer() {
        startTimestamp = 0
        pausedAt = 0
        pauseSeconds = 0
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 9) {
                V54ReactorTitle(text: "LA FORGE · WATCH 3.0", symbol: "dumbbell.fill")
''','timer methods')
s=replace(s, '''                            let seconds = max(0, Int(context.date.timeIntervalSince1970 - startTimestamp))
''','''                            let seconds = elapsedSeconds(now: context.date)
''','elapsed timer')
s=replace(s, '''                    Button {
                        let start = Date(timeIntervalSince1970: startTimestamp)
                        let minutes = Int(Date().timeIntervalSince(start) / 60)
''','''                    Button {
                        if paused {
                            pauseSeconds += max(0, Date().timeIntervalSince1970 - pausedAt)
                            pausedAt = 0
                        } else {
                            pausedAt = Date().timeIntervalSince1970
                        }
                    } label: {
                        Label(paused ? "REPRENDRE" : "PAUSE", systemImage: paused ? "play.fill" : "pause.fill")
                            .font(.system(size: 11, weight: .heavy))
                    }
                    .buttonStyle(.bordered)
                    .tint(V54ReactorTheme.purple)

                    Button {
                        let start = Date(timeIntervalSince1970: startTimestamp)
                        let minutes = elapsedSeconds(now: .now) / 60
''','watch pause button')
s=replace(s,'''                            startTimestamp = 0
                            localMessage = "Séance transférée ou mise en attente."
''','''                            resetTimer()
                            localMessage = "Séance transférée ou mise en attente."
''','reset after workout')
s=replace(s,'''                            startTimestamp = 0
                            localMessage = nil
''','''                            resetTimer()
                            localMessage = nil
''','reset abandon')
s=replace(s,'''                        startTimestamp = Date().timeIntervalSince1970
                        localMessage = nil
''','''                        pauseSeconds = 0
                        pausedAt = 0
                        startTimestamp = Date().timeIntervalSince1970
                        localMessage = nil
''','reset start')
files[name]=s

# Preconditions: exact known stable release markers and no V6 already applied
if 'BILUX V5.9.1' not in read('BiluxIOS/BiluxScreens.swift') and '@MainActor\nprivate enum BILUXV59Legacy' not in read('BiluxIOS/BiluxScreens.swift'):
    raise SystemExit('❌ La base n’est pas la version V5.9.1 avec MainActor.')
if '@MainActor\nprivate enum BILUXV59Legacy' not in read('BiluxIOS/BiluxScreens.swift'):
    raise SystemExit('❌ V5.9.1 MainActor manquant : aucun fichier modifié.')
if 'BILUX V6.0' in read('BiluxIOS/BiluxScreens.swift') or 'WATCH 3.0' in read('BiluxWatch/WatchRootView.swift'):
    raise SystemExit('❌ V6.0 semble déjà installée.')

for name, content in files.items():
    target = stage / name
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(content, encoding='utf-8')
    print(f'✅ Préparé : {name} ({len(content.splitlines())} lignes)')
print('✅ BILUX V6.0 prête en zone temporaire. Aucun fichier source modifié.')
