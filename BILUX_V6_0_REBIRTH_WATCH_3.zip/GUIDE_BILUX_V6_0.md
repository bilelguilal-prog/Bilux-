# BILUX V6.0 — REBIRTH / NUCLEAR WATCH 3.0

Base obligatoire : **V5.9.1 build 18**, branche `bilux-v5.9.1-main-actor-fix`.

## Fonctionnalités

**iPhone** : fiche du combattant dans Héritage avec heures d'entraînement consignées, diversité d'exercices, séances hebdomadaires éligibles et prochaine transformation. Titres, auras et emblèmes existants inchangés ; aucune règle d'XP modifiée.

**Watch 3.0** : cinquième page *Ascension* avec progression hebdomadaire et PV des Gardien du Réacteur et Souverain du Néant, titre et aura équipés sur le cockpit, nombre de séances et dernière séance synchronisée. Les PV sont des représentations du journal : pas de combat ni gain XP depuis la Watch.

**La Forge Watch** : pause / reprise du chronomètre persistante sur la montre, durée enregistrée hors pauses, catégories existantes conservées, transfert vers l'iPhone inchangé. Cela demeure une séance manuelle : **aucun démarrage d'une séance Apple HealthKit**.

### Installation

1. Dans BILUX V5.9.1, exporter une sauvegarde JSON privée ; ne pas l'uploader sur GitHub.
2. Sur GitHub, choisir `bilux-v5.9.1-main-actor-fix`, faire `Add file → Upload files`, déposer `BILUX_V6_0_REBIRTH_WATCH_3.zip`, Commit.
3. Dans Codespaces, coller :

```bash
git switch bilux-v5.9.1-main-actor-fix && git pull --ff-only origin bilux-v5.9.1-main-actor-fix && unzip -o BILUX_V6_0_REBIRTH_WATCH_3.zip -d /tmp/bilux-v60 && bash /tmp/bilux-v60/INSTALLER_V6_0.sh
```

4. Sur Codemagic, branche `bilux-v6.0-rebirth-watch3` : lancer d'abord **BILUX - Vérifier le projet iOS**, puis **BILUX V4.1 - Vérifier Apple Watch**, tous deux sans signature.
5. Si **les deux** sont verts, dans le même Codespace :

```bash
bash /tmp/bilux-v60/PREPARER_BUILD_19.sh
```

6. Codemagic : sélectionner `bilux-v6.0-rebirth-watch3`, workflow **BILUX - Publier sur TestFlight** ; vérifier le build 19 dans App Store Connect, installer sur iPhone et Apple Watch.

### Tests sur l'appareil

- Depuis iPhone : Héritage → Fiche du combattant, vérifier chiffres et titres existants.
- Depuis Watch : ouvrir le cockpit, voir titre/aura équipés après synchro, balayer jusqu'à Ascension : semaine, Gardien 0-12, Souverain 0-30. Si rien, ouvrir iPhone BILUX puis sur Watch toucher Synchroniser.
- Watch La Forge : démarrer, mettre en pause, reprendre, terminer après au moins une minute **effective**, vérifier une seule séance dans l'historique iPhone.
- Les données Health sont lues uniquement avec autorisation ; la synchronisation du profil et des boss ne contient aucune donnée médicale nouvelle.

### Compatibilité et précautions

- Les nouveaux champs WatchSnapshot sont tous optionnels ; les anciens snapshots cachés restent lisibles.
- Aucune modification du modèle BiluxData ni du calcul des XP. Aucun reset de rang/trophée.
- Le script génère les fichiers en zone temporaire et vérifie les quatre avant de modifier le dépôt.
- La validation de syntaxe Swift sur Linux n'est **pas** une compilation iOS/watchOS. Seul Codemagic peut valider les cibles Apple.
- Conserver V5.9.1 build 18 comme secours jusqu'à la vérification TestFlight.
