#!/usr/bin/env bash
set -euo pipefail
BASE='bilux-v5.9.1-main-actor-fix'
DEST='bilux-v6.0-rebirth-watch3'
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail(){ printf '❌ %s\n' "$*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Place-toi à la racine du dépôt BILUX.'
[[ "$(git branch --show-current)" == "$BASE" ]] || fail "Branche attendue : $BASE."
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications locales suivies détectées : annulation.'
git diff --cached --quiet || fail 'Index Git non vide.'
! git show-ref --quiet --verify "refs/heads/$DEST" || fail "La branche $DEST existe déjà."
command -v python3 >/dev/null || fail 'Python 3 introuvable.'
git var GIT_AUTHOR_IDENT >/dev/null 2>&1 || fail 'Identité Git manquante.'
[[ -f "$HERE/APPLIQUER_V6_0.py" ]] || fail 'Script Python absent du ZIP.'
python3 - <<'PY'
from pathlib import Path
import plistlib
for name in ('BiluxIOS/Info.plist', 'BiluxWatch/Info.plist'):
    actual = str(plistlib.loads(Path(name).read_bytes()).get('CFBundleVersion'))
    if actual != '18':
        raise SystemExit(f'❌ {name} : build 18 requis, trouvé {actual}. Aucun fichier modifié.')
print('✅ Build 18 iPhone et Watch confirmé.')
PY
TEMP="$(mktemp -d)"
trap 'rm -rf "$TEMP"' EXIT
python3 "$HERE/APPLIQUER_V6_0.py" "$(pwd)" "$TEMP" || fail 'Base incompatible : aucun fichier modifié.'
if command -v swiftc >/dev/null 2>&1; then
  while IFS= read -r -d '' path; do
    swiftc -frontend -parse "$path" || fail "Syntaxe Swift invalide : $path"
  done < <(find "$TEMP" -name '*.swift' -print0)
  echo '✅ Analyse syntaxique Swift réussie (compilation Xcode à vérifier sur Codemagic).'
else
  echo 'ℹ️ swiftc absent : la compilation Swift sera vérifiée sur Codemagic.'
fi
FILES=(
  'BiluxShared/WatchSnapshot.swift'
  'BiluxIOS/WatchPhoneBridge.swift'
  'BiluxIOS/BiluxScreens.swift'
  'BiluxWatch/WatchRootView.swift'
)
for file in "${FILES[@]}"; do
  [[ -s "$TEMP/$file" ]] || fail "Fichier préparé absent : $file"
done
# Aucune modification suivie avant que les quatre fichiers aient passé les contrôles.
git switch -c "$DEST"
for file in "${FILES[@]}"; do cp "$TEMP/$file" "$file"; done
git add -- "${FILES[@]}"
git diff --cached --check || fail 'Diff invalide.'
git commit -m 'BILUX V6.0 - Rebirth character sheet and Watch 3.0 Ascension'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
  git push -u origin "$DEST" || fail "Envoi GitHub échoué ; les modifications restent dans la branche locale $DEST."
else
  echo '🧪 Simulation locale : git push désactivé.'
fi
echo "✅ BILUX V6.0 intégrée sur $DEST."
echo '➡️ Lance les deux workflows de vérification iOS et Apple Watch sur Codemagic.'
echo '➡️ Ne prépare le build 19 qu’après deux validations vertes.'
