#!/usr/bin/env bash
set -euo pipefail
BASE='bilux-v7.1-nuclear-performance'
TARGET='bilux-v7.2-nuclear-awakening'
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail() { echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Placer le terminal à la racine du dépôt BILUX.'
[[ "$(git branch --show-current)" == "$BASE" ]] || fail "Branche source attendue : $BASE"
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications Git non sauvegardées : les committer ou les stasher.'
git diff --cached --quiet || fail 'Index Git non vide.'
! git show-ref --verify --quiet "refs/heads/$TARGET" || fail "La branche $TARGET existe déjà."
command -v python3 >/dev/null || fail 'Python 3 introuvable.'
git var GIT_AUTHOR_IDENT >/dev/null 2>&1 || fail 'Identité Git non configurée.'
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
python3 "$HERE/APPLIQUER_V7_2.py" "$(pwd)" "$TMP" || fail 'Base incompatible, dépôt inchangé.'
[[ -s "$TMP/BiluxIOS/BiluxScreens.swift" ]] || fail 'Swift généré absent.'
if command -v swiftc >/dev/null 2>&1; then
  swiftc -frontend -parse "$TMP/BiluxIOS/BiluxScreens.swift" BiluxIOS/Models.swift || fail 'Syntaxe Swift invalide ; dépôt inchangé.'
  echo '✅ Syntaxe Swift vérifiée (typage SwiftUI à confirmer sur Xcode).'
else
  echo 'ℹ️ swiftc absent de Codespaces, compilation Xcode nécessaire.'
fi
git switch -c "$TARGET"
cp "$TMP/BiluxIOS/BiluxScreens.swift" BiluxIOS/BiluxScreens.swift
git add -- BiluxIOS/BiluxScreens.swift
git diff --cached --check || fail 'Diff Git invalide.'
git commit -m 'BILUX V7.2 - Nuclear Awakening cosmetic chamber'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
  git push -u origin "$TARGET" || fail "Commit local créé : relancer git push -u origin $TARGET"
else
  echo '🧪 Mode test : aucun push.'
fi
echo "✅ V7.2 prête sur $TARGET. Préparer maintenant le build 32."
