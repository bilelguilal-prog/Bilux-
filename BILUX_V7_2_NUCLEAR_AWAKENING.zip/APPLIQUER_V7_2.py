#!/usr/bin/env python3
"""BILUX V7.2, additive SwiftUI-only module from validated V7.1 build 31.

Apply in staging; no changes to user's checkout unless all anchors validate.
"""
from pathlib import Path
import plistlib
import sys

if len(sys.argv) != 3:
    raise SystemExit('Usage: APPLIQUER_V7_2.py <racine_repo> <dossier_staging>')
root, stage = map(lambda s: Path(s).resolve(), sys.argv[1:])
here = Path(__file__).resolve().parent

def fail(message):
    raise SystemExit('❌ ' + message + ' — aucun fichier du projet modifié.')

def check_once(text, anchor, label):
    n = text.count(anchor)
    if n != 1:
        fail(f'{label}: une occurrence attendue, {n} trouvées')
    return anchor

for relative in ('BiluxIOS/Info.plist', 'BiluxWatch/Info.plist', 'BiluxWatchWidget/Info.plist'):
    try:
        n = str(plistlib.loads((root/relative).read_bytes())['CFBundleVersion'])
    except Exception as exc:
        fail(f'{relative} manquant / invalide : {exc}')
    if n != '31':
        fail(f'Build 31 attendu dans {relative}, obtenu {n}')
for relative, tokens in {
    'BiluxIOS/Models.swift': ['struct BiluxData:', 'struct V63MasterySnapshot', 'enum BILUXV55Progression'],
    'BiluxIOS/BiluxStore.swift': ['var heroLevel:', 'var totalXP:', 'var unlockedStageIndex:'],
    'BiluxWatch/WatchRootView.swift': ['V69WatchQuestsPage', 'V61LiveWorkoutView().tag(5)'],
    'BiluxWatchWidget/NuclearLiveWidget.swift': ['BILUXWatchWidgetPack: WidgetBundle'],
}.items():
    try:
        content = (root / relative).read_text(encoding='utf-8')
    except Exception as exc:
        fail(f'Fichier source absent {relative}: {exc}')
    for token in tokens:
        if token not in content:
            fail(f'{relative}: élément de référence introuvable {token}')
if not (root/'scripts/assign_widget_signing.py').is_file():
    fail('Correctif de signature WidgetKit non retrouvé')

src = root/'BiluxIOS/BiluxScreens.swift'
if not src.is_file(): fail('BiluxScreens.swift absent')
s = src.read_text(encoding='utf-8')
for symbol in (
    'private struct V70RebirthCommandDeck: View',
    'private struct V70NuclearForge: View',
    'private struct V71ExercisePerformance: View',
    'private struct V71AscensionChronicleView: View',
    'private struct NuclearHeroAura: View',
    'private struct BILUXV57RankCinema: View',
    'private struct V65DepthCompositing: View',
    'private struct BILUXV67Contemplation: View',
    'private struct V63NuclearMasteryView: View',
    'private struct NuclearStage: Identifiable',
):
    if s.count(symbol) != 1:
        fail(f'Moteur V7.1 / cinématique requis absent ou ambigu : {symbol}')
if 'V64StormMastery.dominantPath(' not in s:
    fail('Moteur de voie dominante V6.4 non retrouvé')
if 'private struct V72AwakeningChamber: View' in s:
    fail('V7.2 déjà présente')

# 1. A discreet, cosmetic-only reactor seal attached to the EXISTING animated portrait.
home_start = s.index('struct HomeScreen: View')
home_end = s.index('struct SportScreen: View', home_start)
home = s[home_start:home_end]
original = '                    heroPanel\n                    V70RebirthCommandDeck().environmentObject(journal)'
check_once(home, original, 'QG et portrait V7.1')
revised = '''                    heroPanel
                        .overlay(alignment: .bottomTrailing) {
                            V72CoreSeal(stageIndex: journal.unlockedStageIndex,
                                        masteryTotal: V63MasterySnapshot.evaluate(journal.data).unlockedTotal)
                                .frame(width: 76, height: 76)
                                .padding(13)
                                .allowsHitTesting(false)
                        }
                    V70RebirthCommandDeck().environmentObject(journal)'''
home = home.replace(original, revised, 1)
s = s[:home_start] + home + s[home_end:]

# 2. Discoverable link in Ascension, retaining its current rank / loadout / mastery layout.
a_start = s.index('struct AscensionScreen: View')
a_end = s.index('private struct V70RebirthCommandDeck: View', a_start)
a = s[a_start:a_end]
markers = ['                    SectionCaption(title: "Ton ascension")',
           '                    SectionCaption(title: "Ascension du héros")']
found = [marker for marker in markers if marker in a]
if len(found) != 1 or a.count(found[0]) != 1:
    fail('Section Ascension introuvable ou ambiguë')
a = a.replace(found[0],
              '                    V72AwakeningEntry().environmentObject(journal)\n' + found[0], 1)
s = s[:a_start] + a + s[a_end:]

# 3. Link inside the existing command deck, keeping every V7.1 action unchanged.
qg_start = s.index('private struct V70RebirthCommandDeck: View')
qg_end = s.index('private struct V70ForgeSportEntry: View', qg_start)
qg = s[qg_start:qg_end]
anchor = '            HStack(spacing: 9) {\n                V70RebirthTile(title: "SÉANCES / 7 J"'
check_once(qg, anchor, 'Tuiles de performance du QG')
qg = qg.replace(anchor, '            V72AwakeningEntry().environmentObject(journal)\n' + anchor, 1)
s = s[:qg_start] + qg + s[qg_end:]

# 4. No model, HealthKit, UserDefaults selection, XP, Watch or widget edits.
module = (here/'V72_NUCLEAR_AWAKENING.swift.txt').read_text(encoding='utf-8')
for marker in ('private struct V72CoreSeal: View',
               'private struct V72AwakeningChamber: View',
               'private struct V72MilestoneCinema: View'):
    check_once(module, marker, marker)
s = s.rstrip() + '\n' + module.rstrip() + '\n'
out = stage/'BiluxIOS/BiluxScreens.swift'
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(s, encoding='utf-8')
print('✅ Chambre d’Éveil : rangs, réacteur, reliques et cinématiques V7.2 intégrés.')
print('✅ Un seul fichier d’interface iPhone modifié. Stockage, XP, Santé, Watch, WidgetKit préservés.')
