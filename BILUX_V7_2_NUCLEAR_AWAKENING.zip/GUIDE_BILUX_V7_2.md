# ☢️ BILUX V7.2 — Nuclear Awakening

**Source stable** : `bilux-v7.1-nuclear-performance` — build 31 validé sur iPhone et Apple Watch.  
**Nouvelle branche** : `bilux-v7.2-nuclear-awakening`.  
**Prochain TestFlight** : build 32 — **un seul workflow de publication**.

## Ce qui change

- **Chambre d'Éveil** accessible depuis Accueil (QG) et Ascension.
- **Réacteur évolutif** : son nombre d'anneaux et son intensité visuelle dépendent du rang et des maîtrises déjà acquises. L'avatar réutilise les moteurs de foudre existants : pas de second orage concurrent.
- **Reliques des cinq rangs** : débloquées automatiquement depuis les données de progression existantes.
- **Insignes des quatre voies de maîtrise** : affichage des 12 compétences avec leurs états acquis/verrouillé.
- **Célébrations cinématiques rejouables** : cinq jalons symboliques aux niveaux 10, 25, 50, 75 et 100, plus la cinématique de rang existante. Elles ne sont disponibles que si le niveau est atteint.
- Un petit réacteur visuel s'affiche au coin du portrait du QG. Réduction des animations iOS et réglage BILUX d'animations respectés.

**Aucune écriture de récompense**, aucun bonus XP, aucune obligation de séance quotidienne. Les déblocages visuels sont **recalculés depuis le journal existant** : leur présence ne dépend pas d'une nouvelle propriété sauvegardée, mais ils peuvent changer si tu modifies/supprimes les données d'origine. Les cinématiques des niveaux symboliques ne revendiquent **aucune date historique** d'obtention.

**Non modifiés** : `Models.swift`, `BiluxStore.swift`, HealthKit, Nuclear Live, synchronisation Watch, WidgetKit, profils Apple, données santé, export/import JSON, journaux, statistiques V7.1.

## 0. Sauvegarde

Depuis BILUX > Ascension, exporte un JSON de sauvegarde et conserve-le **dans Fichiers/iCloud privé**. Ne publie jamais de données personnelles/santé dans le dépôt GitHub.

## 1. GitHub sur iPhone

1. Ouvre `https://github.com/bilelguilal-prog/Bilux-`.
2. Sélectionne **`bilux-v7.1-nuclear-performance`**.
3. **Add file → Upload files** : ajoute `BILUX_V7_2_NUCLEAR_AWAKENING.zip` à la racine.
4. **Commit changes**.

## 2. Codespaces — une commande

À la racine du dépôt, colle tout ce bloc :

```bash
git switch bilux-v7.1-nuclear-performance && git pull --ff-only origin bilux-v7.1-nuclear-performance && unzip -o BILUX_V7_2_NUCLEAR_AWAKENING.zip -d /tmp/bilux-v72 && bash /tmp/bilux-v72/INSTALLER_V7_2.sh && bash /tmp/bilux-v72/PREPARER_BUILD_32.sh
```

La commande crée la branche V7.2, y committe l'unique source SwiftUI modifiée, prépare ensuite les versions **32** dans les trois Info.plist ainsi que Xcode, et pousse le tout sur GitHub.

L'installateur **refuse d'opérer** si le projet n'est pas sur la bonne branche, si des modifications suivies ne sont pas enregistrées, si le build de départ n'est pas 31 ou si les composants existants sont absents. Il contrôle la syntaxe Swift lorsque `swiftc` est disponible.

Si le répertoire temporaire `/tmp/bilux-v72` a été vidé après installation, récupère simplement les scripts par :

```bash
unzip -o BILUX_V7_2_NUCLEAR_AWAKENING.zip -d /tmp/bilux-v72
```

Ne relance **pas** `INSTALLER_V7_2.sh` après que la branche a été créée. Si la préparation du build 32 est déjà passée, ne la relance pas non plus : chaque script refuse les doubles changements.

## 3. Codemagic — procédure économe

- Branche : **`bilux-v7.2-nuclear-awakening`**
- Workflow : **BILUX — Publier sur TestFlight**
- Version : **1.0 (32)**
- **Aucun build simulateur préalable obligatoire** : notre procédure validée prévoit un seul build complet. En cas d'erreur Xcode, conserver le log et corriger sans multiplier les essais.

Les essais locaux vérifient l'application du patch, la syntaxe Swift, les états de version et les diffs. **Ils ne remplacent pas le typage SwiftUI et l'archivage Xcode**, qui doivent être confirmés dans Codemagic.

## 4. Validation après installation TestFlight

1. **QG** : le portrait garde son aspect et son moteur d'orage ; réacteur en coin visible, sans masquer le personnage.
2. **Accueil → Chambre d'Éveil** : image du rang actif, progression actuelle et réacteur évolutif.
3. **Reliques** : exactement les rangs réellement débloqués apparaissent comme acquis.
4. **Quatre voies** : la Chambre d'Éveil retrouve les 12 insignes déjà renseignés dans l'arbre V6.3.
5. **Cinématiques** : le bouton « Revoir l'éveil » ouvre la cinématique du rang ; les jalons inaccessibles restent verrouillés.
6. **Fermer / Passer** : le bouton de sortie fonctionne à chaque phase de la cinématique.
7. **Réduire les animations** : le réglage iOS désactive les mouvements sans masquer le contenu.
8. **V7.1 et Watch** : Forge, Analytics, progression par exercice, journal, XP et Nuclear Live doivent fonctionner comme au build 31 ; vérifier la synchro Watch.

**Retour arrière** : conserver BILUX V7.1 — build 31 comme base stable jusqu'à ce que le build 32 soit validé sur iPhone et Apple Watch.
