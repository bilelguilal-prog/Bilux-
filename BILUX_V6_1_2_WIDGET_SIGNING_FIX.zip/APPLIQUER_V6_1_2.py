#!/usr/bin/env python3
"""Make an idempotent, guarded change to the TestFlight signing steps."""
from pathlib import Path
import plistlib
import sys

if len(sys.argv) != 2:
    sys.exit('Usage: python3 APPLIQUER_V6_1_2.py /path/to/repo')
repo = Path(sys.argv[1])
yaml_path = repo / 'codemagic.yaml'
watch_plist = repo / 'BiluxWatch/Info.plist'
ios_plist = repo / 'BiluxIOS/Info.plist'
pbx_path = repo / 'BiluxIOS.xcodeproj/project.pbxproj'

for path in [yaml_path, watch_plist, ios_plist, pbx_path]:
    if not path.is_file():
        sys.exit('❌ Missing expected file: ' + str(path))
for path in [watch_plist, ios_plist]:
    ver = plistlib.loads(path.read_bytes()).get('CFBundleVersion')
    if str(ver) != '21':
        sys.exit(f'❌ Expected prepared Build 21 in {path.name}; found {ver}')
if 'com.bilux.nuclearascension.watchkitapp.nuclearlivewidget' not in pbx_path.read_text():
    sys.exit('❌ WidgetKit target missing from Xcode project')

original = yaml_path.read_text(encoding='utf-8')
old = '''      - name: Appliquer les profils Apple (iPhone et Watch)
        script: xcode-project use-profiles --project BiluxIOS.xcodeproj
      - name: Construire la version TestFlight'''
new = '''      - name: Appliquer les profils Apple (iPhone, Watch et Widget)
        script: xcode-project use-profiles --project BiluxIOS.xcodeproj --code-signing-setup-verbose-logging
      - name: Associer explicitement le profil de signature WidgetKit
        script: python3 scripts/assign_widget_signing.py
      - name: Construire la version TestFlight'''
if original.count(old) != 1:
    sys.exit('❌ Codemagic signing layout differs from the expected V6.1.1. No files changed.')
if (repo/'scripts/assign_widget_signing.py').exists():
    sys.exit('❌ Widget signing helper exists already; no files changed.')
updated = original.replace(old, new)
# Validate YAML syntax before writing when PyYAML is present
try:
    import yaml
except ImportError:
    pass
else:
    doc = yaml.safe_load(updated)
    scripts = doc['workflows']['distribution-testflight']['scripts']
    if not any('Associer explicitement' in step.get('name','') for step in scripts):
        sys.exit('❌ YAML validation failed; no files changed')
source = Path(__file__).resolve().parent/'assign_widget_signing.py'
compile(source.read_text(), str(source), 'exec')
(repo/'scripts').mkdir(exist_ok=True)
(repo/'scripts/assign_widget_signing.py').write_text(source.read_text(), encoding='utf-8')
yaml_path.write_text(updated, encoding='utf-8')
print('✅ Codemagic YAML: widget profile binding step installed')
print('✅ scripts/assign_widget_signing.py added')
print('✅ Prepared build 21 retained (do NOT increment the build number)')
