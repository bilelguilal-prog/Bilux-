# ☢️ BILUX V6.1.2 — Correction de signature WidgetKit (build 21)

## Pourquoi ce correctif

L'archivage Codemagic du build 21 échoue avec :

```
"BiluxWatchWidget" requires a provisioning profile.
```

Cela ne signifie pas que le profil est absent du tableau de bord : il est possible que le workflow n'ait pas téléchargé le profil, ou que la cible Xcode `BiluxWatchWidget` n'ait pas été associée au profil pendant `xcode-project use-profiles`.

Le correctif ne touche pas aux fichiers Swift, aux données BILUX ni aux autres profils. Il ajoute une étape de signature **uniquement au workflow de publication TestFlight**. Cette étape décode localement les profils disponibles sur le Mac Codemagic, vérifie l'identifiant explicite du widget, la nature App Store et l'expiration, puis définit pour `BiluxWatchWidget / Release` le profil et la team correspondants.

## Installation

1. Depuis GitHub `bilelguilal-prog/Bilux-`, choisir la branche `bilux-v6.1.1-watch-widget` (build 21) et y déposer **`BILUX_V6_1_2_WIDGET_SIGNING_FIX.zip`** via Add file > Upload files > Commit.
2. Dans Codespaces :

```bash
git switch bilux-v6.1.1-watch-widget && git pull --ff-only origin bilux-v6.1.1-watch-widget && unzip -o BILUX_V6_1_2_WIDGET_SIGNING_FIX.zip -d /tmp/bilux-v612 && bash /tmp/bilux-v612/INSTALLER_V6_1_2.sh
```

L'installateur crée et pousse la branche `bilux-v6.1.2-widget-signing`.

## Essai de publication

Dans Codemagic, lancer directement **BILUX — Publier sur TestFlight**, branche `bilux-v6.1.2-widget-signing`.

**Garder le build 21.** Le précédent archivage a échoué avant distribution ; inutile d'incrémenter maintenant le numéro. Les deux builds simulateur ont déjà réussi et aucun code Swift n'a changé.

Dans les logs, regarder ces deux étapes :

1. `Appliquer les profils Apple (iPhone, Watch et Widget)`
2. `Associer explicitement le profil de signature WidgetKit`

La seconde doit afficher :

```
✅ Widget profile found: ... (Team ..., UUID ...)
✅ Applied the widget distribution profile to BiluxWatchWidget / Release
```

Si l'étape affiche `No App Store profile was downloaded`, c'est que le profil est visible dans Codemagic **mais pas présent dans les fichiers que le workflow a téléchargés**. Vérifier qu'il est bien type `app_store`, pour `com.bilux.nuclearascension.watchkitapp.nuclearlivewidget`, associé au certificat Apple Distribution, puis transmettre le journal de l'étape : il faudra peut-être passer la configuration YAML de récupération automatique à une liste explicite des **trois** références de profils et du certificat.

Si l'étape est verte mais que l'archive échoue encore, transmettre la nouvelle première ligne rouge `error:` du build.

## Sécurité et retour arrière

- Aucun changement aux identifiants et profils sur Apple Developer.
- Aucun changement à HealthKit ni aux séances et XP.
- Aucune copie de certificat, de profil ou de fichier privé dans GitHub ; la sélection des profils se fait **uniquement sur la machine Codemagic pendant le build**.
- Branche de secours : `bilux-v6.1-nuclear-live` / build 20.

### Sources techniques

- https://docs.codemagic.io/yaml-code-signing/signing-ios/
- https://github.com/codemagic-ci-cd/cli-tools/blob/master/docs/xcode-project/use-profiles.md
