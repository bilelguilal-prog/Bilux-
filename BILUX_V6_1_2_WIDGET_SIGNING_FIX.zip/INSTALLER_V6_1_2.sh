#!/usr/bin/env bash
set -euo pipefail
cd "$(git rev-parse --show-toplevel)"
BASE='bilux-v6.1.1-watch-widget'
NEW='bilux-v6.1.2-widget-signing'
if [ "$(git branch --show-current)" != "$BASE" ]; then
  echo "❌ Switch to $BASE first." >&2; exit 1
fi
if [ -n "$(git status --porcelain)" ]; then
  echo '❌ Uncommitted changes found. Commit/stash first.' >&2; exit 1
fi
if git show-ref --verify --quiet "refs/heads/$NEW"; then
  echo "❌ $NEW already exists; nothing changed." >&2; exit 1
fi
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
python3 "$HERE/APPLIQUER_V6_1_2.py" "$PWD"
python3 -m py_compile scripts/assign_widget_signing.py
if python3 -c 'import yaml' >/dev/null 2>&1; then
  python3 -c 'import yaml; yaml.safe_load(open("codemagic.yaml")); print("✅ Codemagic YAML parses correctly")'
fi
git switch -c "$NEW"
git add codemagic.yaml scripts/assign_widget_signing.py
git commit -m 'BILUX V6.1.2 - explicit widget App Store signing in Codemagic'
git push -u origin "$NEW"
echo "✅ $NEW published. Re-run TestFlight archive with build 21."
