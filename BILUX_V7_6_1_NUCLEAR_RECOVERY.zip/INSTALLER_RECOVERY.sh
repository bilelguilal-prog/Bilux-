#!/usr/bin/env bash
set -euo pipefail
BASE=bilux-v7.6-nuclear-watch5
TARGET=bilux-v7.6.1-nuclear-recovery
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
[[ "$(git branch --show-current)" == "$BASE" ]] || { echo 'Branche V7.6 requise'; exit 1; }
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || { echo 'Modifications suivies non validées ; arrêt.'; exit 1; }
! git show-ref --verify --quiet "refs/heads/$TARGET" || { echo 'Branche de récupération déjà présente ; arrêt.'; exit 1; }
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
python3 "$HERE/PATCH.py" "$(pwd)" "$TMP"
FILES=(BiluxIOS/BiluxStore.swift BiluxIOS/BiluxApp.swift BiluxIOS/WatchPhoneBridge.swift BiluxWatch/WatchBridge.swift BiluxIOS/Info.plist BiluxWatch/Info.plist BiluxWatchWidget/Info.plist BiluxIOS.xcodeproj/project.pbxproj)
if command -v swiftc >/dev/null; then for rel in "${FILES[@]}"; do [[ "$rel" != *.swift ]] || swiftc -frontend -parse "$TMP/$rel"; done; fi
git switch -c "$TARGET"
for rel in "${FILES[@]}"; do cp "$TMP/$rel" "$rel"; done
git add -- "${FILES[@]}"
git diff --cached --check
git commit -m 'BILUX V7.6.1 - recovery journal fail closed backup and Watch receipt build 37'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != 1 ]]; then git push -u origin "$TARGET"; fi
printf '\nBuild 37 prêt. Publier uniquement la nouvelle branche sur TestFlight.\n'
