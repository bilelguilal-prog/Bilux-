#!/usr/bin/env python3
from pathlib import Path
import sys, plistlib
root,stage=map(lambda p:Path(p).resolve(),sys.argv[1:]);here=Path(__file__).parent

def read(p): return (root/p).read_text()
def load(p): return (here/p).read_text()
def once(s,a,b):
    if s.count(a)!=1: raise SystemExit('Base incompatible : '+repr(a[:140])+' ; sources inchangées.')
    return s.replace(a,b,1)
def output(p,s):
    f=stage/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s);print('Préparé :',p)
for p in ['BiluxIOS/Info.plist','BiluxWatch/Info.plist','BiluxWatchWidget/Info.plist']:
    obj=plistlib.loads((root/p).read_bytes())
    if str(obj['CFBundleVersion'])!='36': raise SystemExit('Build 36 requis : '+p)
    obj['CFBundleVersion']='37';f=stage/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(plistlib.dumps(obj,sort_keys=False))
p='BiluxIOS.xcodeproj/project.pbxproj';s=read(p)
if s.count('CURRENT_PROJECT_VERSION = 36;')!=2: raise SystemExit('Numéros Xcode inattendus')
output(p,s.replace('CURRENT_PROJECT_VERSION = 36;','CURRENT_PROJECT_VERSION = 37;'))
p='BiluxIOS/BiluxStore.swift';s=read(p)
s=once(s,'import Combine\n','import Combine\nimport UIKit\n')
a=s.index('    private let url: URL\n');b=s.index('    func add(_ session: WorkoutSession)',a)
if '.completeFileProtection' not in s[a:b] or 'BILUXV55Progression.makeAnchor' not in s[a:b]: raise SystemExit('Stockage inconnu')
s=s[:a]+load('STORE_CORE.txt')+'\n'+s[b:]
s=once(s,'        data.workouts.insert(session, at: 0)\n','        guard recoveryReady, !data.workouts.contains(where: { $0.id == session.id }) else { return }\n        data.workouts.insert(session, at: 0)\n')
s=once(s,'            let result = try V3Import.parse(object)','''            guard recoveryReady else { throw CocoaError(.fileWriteNoPermission) }
            let result: BiluxData
            if object["version"] as? Int == 4 {
                result = try JSONDecoder().decode(BiluxData.self, from: raw)
            } else { result = try V3Import.parse(object) }''')
s=once(s,'            save()\n            feedback = "Import terminé', '            guard save() else { return }\n            feedback = "Import terminé')
s=once(s,'            let file = FileManager.default.temporaryDirectory.appendingPathComponent("bilux-v4-sauvegarde.json")','''            guard recoveryReady else { throw CocoaError(.fileReadNoPermission) }
            let file = FileManager.default.temporaryDirectory.appendingPathComponent("bilux-v4-sauvegarde-\\(UUID().uuidString).json")''')
output(p,s)
p='BiluxIOS/BiluxApp.swift';s=read(p)
s=once(s,'import SwiftUI\n','import SwiftUI\nimport Combine\nimport UIKit\nimport HealthKit\nimport UniformTypeIdentifiers\n')
s=once(s,'    @StateObject private var journal: BiluxStore','    @Environment(\\.scenePhase) private var scenePhase\n    @StateObject private var journal: BiluxStore')
s=once(s,'''            MainTabs()
                .environmentObject(journal)
                .environmentObject(health)
                .preferredColorScheme(.dark)''','''            Group {
                if journal.recoveryReady { MainTabs() }
                else { V761RecoveryScreen() }
            }
            .environmentObject(journal)
            .environmentObject(health)
            .preferredColorScheme(.dark)
            .onReceive(NotificationCenter.default.publisher(for: UIApplication.protectedDataDidBecomeAvailableNotification)) { _ in
                journal.reloadRecovery()
                WatchPhoneBridge.shared.retryRecoveryWorkouts()
            }
            .onChange(of: scenePhase) { phase in
                if phase == .active {
                    journal.reloadRecovery()
                    WatchPhoneBridge.shared.retryRecoveryWorkouts()
                }
            }''')
output(p,s+load('RECOVERY_UI.txt'))
p='BiluxIOS/WatchPhoneBridge.swift';s=read(p)
s=once(s,'import WatchConnectivity\n','import WatchConnectivity\nimport UIKit\n')
s=once(s,'    private var snapshot = WatchSnapshot.empty\n','    private var snapshot = WatchSnapshot.empty\n    private var recoverySnapshotValid = false\n')
s=once(s,'        for pending in awaitingWorkouts { receiveWorkout(pending) }\n        awaitingWorkouts.removeAll()','''        journal.$recoveryReady.receive(on: DispatchQueue.main).sink { [weak self, weak health] ready in
            guard let self, ready, let health, let data = self.journal?.safeSnapshotData else { return }
            self.updateSnapshot(data: data, health: health.today)
            self.retryRecoveryWorkouts()
        }.store(in: &subscriptions)
        retryRecoveryWorkouts()''')
s=once(s,'    private func updateSnapshot(data: BiluxData, health: DailyHealthSummary) {','''    private func updateSnapshot(data _: BiluxData, health: DailyHealthSummary) {
        guard let data = journal?.safeSnapshotData else { recoverySnapshotValid = false; return }
        recoverySnapshotValid = true''')
s=once(s,'        var enriched = snapshot\n        enriched.updatedAt = Date()','''        guard recoverySnapshotValid, journal?.safeSnapshotData != nil else { return nil }
        var enriched = snapshot
        // Ne jamais réhorodater un résumé vide ou obsolète comme s'il était neuf.''')
s=once(s,'    private func receiveWorkout(_ message: [String: Any]) {\n        guard let journal else { awaitingWorkouts.append(message); return }',load('INBOX.txt')+'''\n    private func receiveWorkoutNow(_ message: [String: Any]) {
        guard let journal, journal.recoveryReady else { return }''')
s=once(s,'        journal.add(entry)\n        if let forge, isLive { V76LinkWatchWorkout(forge, workout: entry) }','''        journal.add(entry)
        if let forge, isLive, journal.safeSnapshotData?.workouts.contains(where: { $0.id == entry.id }) == true {
            V76LinkWatchWorkout(forge, workout: entry)
        }''')
s=once(s,'''        if let old = journal.data.workouts.first(where: { $0.id == id }) {
            if let forge { V76LinkWatchWorkout(forge, workout: old) }
            return
        }
''','''        let recoveredEntry = journal.data.workouts.first(where: { $0.id == id })
        // Ne jamais réécrire une séance déjà journalisée, sauf mise à niveau d'une
        // entrée minimale issue de la recherche Santé de cette version.
        if let old = recoveredEntry, !old.notes.hasPrefix("Récupération V7.6.1 depuis Apple Santé") {
            if let forge { V76LinkWatchWorkout(forge, workout: old) }
            return
        }
''')
s=once(s,'''        journal.add(entry)
        if let forge, isLive, journal.safeSnapshotData?.workouts.contains(where: { $0.id == entry.id }) == true {''','''        if let old = recoveredEntry {
            if !old.exercises.isEmpty { entry.exercises = old.exercises }
            if let rpe = old.rpe { entry.rpe = rpe }
            journal.updateWorkout(entry)
        } else { journal.add(entry) }
        if let forge, isLive, journal.safeSnapshotData?.workouts.contains(where: { $0.id == entry.id }) == true {''')
# Rejouer à l'activation du pont, même lors d'un lancement de fond.
s=once(s,'            activated = state == .activated\n            sendSnapshot()','            activated = state == .activated\n            retryRecoveryWorkouts()\n            sendSnapshot()')
output(p,s)
p='BiluxWatch/WatchBridge.swift';s=read(p)
s=once(s,'        for event in pending { WCSession.default.transferUserInfo(event) }\n        UserDefaults.standard.removeObject(forKey: pendingKey)','''        let session = WCSession.default
        for event in pending {
            guard let key = event["id"] as? String,
                  !session.outstandingUserInfoTransfers.contains(where: { $0.userInfo["id"] as? String == key }) else { continue }
            session.transferUserInfo(event)
        }
        // V7.6.1 : garder la copie Watch jusqu'à la confirmation de l'écriture iPhone.''')
s=once(s,'    nonisolated func session(_ session: WCSession, didReceiveMessage message: [String: Any]) {','''    nonisolated func session(_ session: WCSession, didReceiveUserInfo userInfo: [String: Any]) {
        guard userInfo["type"] as? String == "v761WorkoutAck", let key = userInfo["id"] as? String else { return }
        Task { @MainActor in
            let pending = UserDefaults.standard.array(forKey: self.pendingKey) as? [[String: Any]] ?? []
            UserDefaults.standard.set(pending.filter { $0["id"] as? String != key }, forKey: self.pendingKey)
        }
    }
    nonisolated func session(_ session: WCSession, didReceiveMessage message: [String: Any]) {''')
output(p,s)
