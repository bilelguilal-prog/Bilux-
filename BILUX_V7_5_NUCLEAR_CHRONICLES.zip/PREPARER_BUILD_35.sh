#!/usr/bin/env bash
set -euo pipefail
BRANCH='bilux-v7.5-nuclear-chronicles'
fail(){ echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Se placer à la racine du dépôt.'
[[ "$(git branch --show-current)" == "$BRANCH" ]] || fail "Branche attendue : $BRANCH"
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications locales non commitées.'
git diff --cached --quiet || fail 'Index Git non vide.'
for marker in 'private struct V75WeeklyChroniclesView: View' 'private struct V74UnifiedDebrief: View' 'private struct V73EternalForgeHub: View'; do
  grep -qF "$marker" BiluxIOS/BiluxScreens.swift || fail "Composant absent : $marker"
done
grep -qF 'V61LiveWorkoutView().tag(5)' BiluxWatch/WatchRootView.swift || fail 'Nuclear Live absent.'
grep -qF 'V69WatchQuestsPage' BiluxWatch/WatchRootView.swift || fail 'Watch 4.1 absente.'
grep -qF 'BILUXWatchWidgetPack' BiluxWatchWidget/NuclearLiveWidget.swift || fail 'Widget absent.'
[[ -f scripts/assign_widget_signing.py ]] || fail 'Script signature widget absent.'
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
python3 - "$TMP" <<'PY'
import sys, plistlib
from pathlib import Path
root = Path.cwd()
target = Path(sys.argv[1])
for rel in ('BiluxIOS/Info.plist','BiluxWatch/Info.plist','BiluxWatchWidget/Info.plist'):
    try:
        obj = plistlib.loads((root/rel).read_bytes())
    except Exception as e:
        raise SystemExit(f'❌ Plist invalide {rel} : {e}')
    version = str(obj.get('CFBundleVersion'))
    if version == '35':
        raise SystemExit(f'ℹ️ Build 35 déjà préparé dans {rel}. Ne pas relancer.')
    if version != '34':
        raise SystemExit(f'❌ Build 34 attendu dans {rel}, trouvé {version}.')
    obj['CFBundleVersion'] = '35'
    dest = target/rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(plistlib.dumps(obj,sort_keys=False))
rel = 'BiluxIOS.xcodeproj/project.pbxproj'
source = (root/rel).read_text(encoding='utf-8')
if source.count('CURRENT_PROJECT_VERSION = 34;') != 2:
    raise SystemExit('❌ Xcode attend exactement deux CURRENT_PROJECT_VERSION = 34;')
if 'BiluxWatchWidget' not in source:
    raise SystemExit('❌ Extension WidgetKit absente du projet Xcode.')
dest = target/rel
(dest.parent).mkdir(parents=True, exist_ok=True)
dest.write_text(source.replace('CURRENT_PROJECT_VERSION = 34;', 'CURRENT_PROJECT_VERSION = 35;'), encoding='utf-8')
print('✅ Build 35 préparé pour les trois cibles.')
PY
FILES=(BiluxIOS/Info.plist BiluxWatch/Info.plist BiluxWatchWidget/Info.plist BiluxIOS.xcodeproj/project.pbxproj)
for rel in "${FILES[@]}"; do cp "$TMP/$rel" "$rel"; done
git add -- "${FILES[@]}"
git diff --cached --check || fail 'Diff Git invalide.'
git commit -m 'BILUX V7.5 - Build 35 iPhone Watch WidgetKit'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
  git push origin "$BRANCH" || fail 'Commit local prêt ; réessayer le push.'
else
  echo '🧪 Mode test local sans push.'
fi
echo '✅ Build 35 prêt. Lancer seulement BILUX — Publier sur TestFlight.'
