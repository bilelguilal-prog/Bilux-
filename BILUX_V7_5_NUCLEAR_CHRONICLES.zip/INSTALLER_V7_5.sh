#!/usr/bin/env bash
set -euo pipefail
BASE='bilux-v7.4-nuclear-synchronization'
TARGET='bilux-v7.5-nuclear-chronicles'
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail(){ echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Se placer à la racine de BILUX.'
[[ "$(git branch --show-current)" == "$BASE" ]] || fail "Branche de base attendue : $BASE"
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications suivies non validées ; commit ou stash nécessaire.'
git diff --cached --quiet || fail 'Index Git non vide.'
! git show-ref --verify --quiet "refs/heads/$TARGET" || fail "La branche $TARGET existe déjà."
command -v python3 >/dev/null || fail 'Python 3 requis.'
git var GIT_AUTHOR_IDENT >/dev/null 2>&1 || fail 'Configure ton identité Git.'
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
python3 "$HERE/APPLIQUER_V7_5.py" "$(pwd)" "$TMP" || fail 'V7.4 incompatible ; aucune source changée.'
[[ -s "$TMP/BiluxIOS/BiluxScreens.swift" ]] || fail 'Fichier corrigé introuvable.'
if command -v swiftc >/dev/null 2>&1; then
  swiftc -frontend -parse "$TMP/BiluxIOS/BiluxScreens.swift" BiluxIOS/Models.swift || fail 'Analyse syntaxique Swift en échec ; dépôt inchangé.'
  echo '✅ Syntaxe Swift validée localement (pas le typage SwiftUI Xcode).'
fi
git switch -c "$TARGET"
cp "$TMP/BiluxIOS/BiluxScreens.swift" BiluxIOS/BiluxScreens.swift
git add -- BiluxIOS/BiluxScreens.swift
git diff --cached --check || fail 'Diff Git invalide.'
git commit -m 'BILUX V7.5 - Weekly nuclear chronicles'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
  git push -u origin "$TARGET" || fail 'Commit local créé ; réessayer le push sur la nouvelle branche.'
else
  echo '🧪 Test local : pas de push.'
fi
echo "✅ V7.5 installée sur $TARGET. Préparer le build 35."
