#!/usr/bin/env python3
"""Patch additionnel, en lecture seule : V7.5 Nuclear Chronicles."""
from pathlib import Path
import plistlib
import sys

if len(sys.argv) != 3:
    raise SystemExit('Usage : APPLIQUER_V7_5.py <depot> <staging>')
root, stage = (Path(value).resolve() for value in sys.argv[1:])
here = Path(__file__).resolve().parent

def fail(reason):
    raise SystemExit('❌ ' + reason + ' — aucun fichier du projet modifié.')

def once(source, needle, what):
    count = source.count(needle)
    if count != 1:
        fail(f'{what} : une occurrence attendue, {count} trouvée(s)')
    return needle

for rel in ('BiluxIOS/Info.plist', 'BiluxWatch/Info.plist', 'BiluxWatchWidget/Info.plist'):
    try:
        version = str(plistlib.loads((root/rel).read_bytes())['CFBundleVersion'])
    except Exception as exc:
        fail(f'{rel} absent ou invalide : {exc}')
    if version != '34':
        fail(f'{rel} : build 34 attendu, reçu {version}')

for rel, marker in {
    'BiluxIOS/Models.swift': 'struct WorkoutSession:',
    'BiluxIOS/BiluxStore.swift': 'var totalXP:',
    'BiluxWatch/WatchRootView.swift': 'V69WatchQuestsPage',
    'BiluxWatchWidget/NuclearLiveWidget.swift': 'BILUXWatchWidgetPack: WidgetBundle',
}.items():
    try:
        content = (root/rel).read_text(encoding='utf-8')
    except Exception as exc:
        fail(f'Fichier manquant : {rel} ({exc})')
    if marker not in content:
        fail(f'Base V7.4 incohérente : {marker} absent dans {rel}')
if not (root/'scripts/assign_widget_signing.py').is_file():
    fail('Script de signature WidgetKit introuvable')

src_file = root/'BiluxIOS/BiluxScreens.swift'
s = src_file.read_text(encoding='utf-8')
for marker in ('private struct V70RebirthCommandDeck: View',
               'private struct V71AscensionChronicleView: View',
               'private enum V71AscensionChronicle',
               'private struct V73EternalForgeHub: View',
               'private struct V74UnifiedDebrief: View'):
    once(s, marker, marker)
if 'private struct V75WeeklyChroniclesView: View' in s:
    fail('La V7.5 est déjà installée')

start = s.index('private struct V70RebirthCommandDeck: View')
end = s.index('private struct V70ForgeSportEntry: View', start)
qg = s[start:end]
needle = '                .accessibilityIdentifier("bilux.v70.analytics.home")\n'
once(qg, needle, 'Raccourci Analytics du QG')
new_entry = '''
                NavigationLink {
                    V75WeeklyChroniclesView().environmentObject(journal)
                } label: {
                    Label("CHRONIQUES HEBDOMADAIRES", systemImage: "calendar.badge.clock")
                        .font(.subheadline.weight(.heavy))
                        .frame(maxWidth: .infinity, minHeight: 42)
                }
                .buttonStyle(.bordered).tint(Nuclear.gold)
                .accessibilityIdentifier("bilux.v75.weekly.entry")
'''
qg = qg.replace(needle, needle + new_entry, 1)
s = s[:start] + qg + s[end:]

module = (here/'V75_WEEKLY_CHRONICLES.swift.txt').read_text(encoding='utf-8')
for needle in ('private struct V75WeekSummary', 'private struct V75WeeklyChroniclesView: View',
               'V71AscensionChronicle.events(journal.data)', 'journal.totalXP'):
    once(module, needle, 'Moteur V7.5 incomplet : '+needle)
s = s.rstrip() + '\n' + module.rstrip() + '\n'
out = stage/'BiluxIOS/BiluxScreens.swift'
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(s, encoding='utf-8')
print('✅ V7.5 : chroniques hebdomadaires et raccourci QG préparés.')
print('✅ Seule source iPhone modifiée : BiluxIOS/BiluxScreens.swift.')
print('✅ XP, Santé, séances, programmes, Watch et WidgetKit inchangés.')
