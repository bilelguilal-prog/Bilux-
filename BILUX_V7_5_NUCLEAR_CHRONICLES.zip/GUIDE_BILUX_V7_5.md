# ☢️ BILUX V7.5 — NUCLEAR CHRONICLES

**Base stable :** `bilux-v7.4-nuclear-synchronization` — build **34**.  
**Branche créée :** `bilux-v7.5-nuclear-chronicles`.  
**Prochain TestFlight :** build **35** (iPhone, Watch et widget).

## Pourquoi cette version ?

BILUX possède déjà une Forge (séances, charges et records), des statistiques de performance, un Journal de l'Ascension et des boss. **Nuclear Chronicles** leur donne une lecture **semaine après semaine** sans créer de nouvelle base de données.

Sur l'iPhone, via **Accueil → Centre de commandement → CHRONIQUES HEBDOMADAIRES** :

- Naviguer entre la semaine actuelle et les **52 semaines précédentes**.
- Visualiser les **7 journées du lundi au dimanche** : séance enregistrée, repos ou journée future. **Aucun malus de repos**.
- Lire les séances, jours actifs, minutes d'entraînement et **volume musculaire (kg)** de la semaine.
- Comparer **séances et minutes** avec la semaine précédente, avec un avertissement lorsque la semaine est encore en cours.
- Retrouver les **records, jalons et victoires historiques déductibles** du Journal de l'Ascension. Les règles des Gardiens existants sont réutilisées.
- Consulter la liste des séances réelles et le niveau / XP **actuels**, clairement distingués d'un gain d'XP hebdomadaire historique non enregistré.

**Aucune modification du journal, des XP, des combats, de la Watch, des données Santé ou des sauvegardes.** La vue est en lecture seule et ne crée aucun événement.

## 0. Sauvegardes privées

Avant toute installation, exporte depuis BILUX ton **JSON principal** vers Fichiers/iCloud privé. Si tu utilises les programmes V7.3, exporte également leur **sauvegarde JSON séparée** depuis Eternal Forge : ces programmes ne sont pas dans l'export principal. Ne charge jamais ces sauvegardes privées dans GitHub.

## 1. Ajouter le ZIP à GitHub

1. Sur iPhone, ouvre `https://github.com/bilelguilal-prog/Bilux-`.
2. Sélectionne la branche **`bilux-v7.4-nuclear-synchronization`**.
3. Choisis **Add file → Upload files**, puis dépose **`BILUX_V7_5_NUCLEAR_CHRONICLES.zip`** à la racine.
4. Valide le commit.

## 2. Installation + préparation du build 35

Dans Codespaces, à la racine du dépôt, colle **une seule commande** :

```bash
git switch bilux-v7.4-nuclear-synchronization && git pull --ff-only origin bilux-v7.4-nuclear-synchronization && unzip -o BILUX_V7_5_NUCLEAR_CHRONICLES.zip -d /tmp/bilux-v75 && bash /tmp/bilux-v75/INSTALLER_V7_5.sh && bash /tmp/bilux-v75/PREPARER_BUILD_35.sh
```

L'installateur vérifie la présence du build 34 dans les trois `Info.plist` et des composants V7.4, puis prépare une modification **uniquement de `BiluxIOS/BiluxScreens.swift`** dans un dossier temporaire. En cas de base incompatible, il s'arrête **avant de modifier les sources**. Si `swiftc` est disponible, il vérifie la syntaxe Swift.

La nouvelle branche est **`bilux-v7.5-nuclear-chronicles`**. Le script de préparation passe les versions à **35** dans les trois `Info.plist` et dans le projet Xcode, puis commit/push sur cette branche.

Si Codespaces redémarre et perd `/tmp` **après installation mais avant la préparation**, réextrais le ZIP **depuis la branche de base**, puis relance uniquement `PREPARER_BUILD_35.sh` depuis la branche V7.5. **Ne réexécute pas l'installateur.**

## 3. Codemagic — un seul build TestFlight

| Paramètre | Valeur |
|---|---|
| Branche | `bilux-v7.5-nuclear-chronicles` |
| Workflow | **BILUX — Publier sur TestFlight** |
| Numéro | **35** |
| Builds simulateur avant publication | **Aucun** dans notre méthode optimisée |

Tests locaux effectués : syntaxe Swift, cas de calcul hebdomadaire (deux séances le même jour, exclusion des séances futures, historique lundi-dimanche), simulation de branche Git, installation et préparation des numéros de build. La compilation/type-checking SwiftUI complète nécessite toujours **Xcode via Codemagic**. Si la publication échoue, inspecter les premières erreurs Xcode avant de relancer.

## 4. Vérifications sur iPhone après mise à jour

1. **Accueil → Centre de commandement → CHRONIQUES HEBDOMADAIRES** : l'écran s'ouvre.
2. Aller à la **semaine précédente** : le calendrier et les totaux changent.
3. Vérifier qu'une journée de repos ne montre **aucun malus**.
4. Vérifier que les séances historiques et les records correspondent aux informations de Sport / Journal de l'Ascension.
5. Vérifier que les **XP** indiqués sont bien le **total actuel**, pas un bonus hebdomadaire.
6. Fermer puis rouvrir l'app ; contrôler les XP, les programmes et les séances.
7. Vérifier que **Nuclear Live**, **Watch 4.1** et les complications sont toujours présents.

**Le build 34 reste la version de secours jusqu'à validation du build 35.**

## 5. Protection des acquis

- Pas de changement de `BiluxStore`, `Models.swift`, `V3Import`, HealthKit ou des données stockées.
- Pas de changement des fichiers Swift de l'Apple Watch, de WidgetKit ou des certificats/profils Codemagic.
- Aucun XP supplémentaire, aucun boss artificiellement blessé, aucune nouvelle séance.
- Les dates d'événements historiques continuent d'être **déduites des séances** lorsque possible ; un passage de rang antérieur sans date fiable ne reçoit pas de fausse date.

---

☢️ **V7.5 est une évolution de consultation et de motivation, pas une évolution des règles du jeu.**
