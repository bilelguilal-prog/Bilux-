#!/usr/bin/env python3
"""BILUX V5.5 - verifies anchors and prepares all files in staging, no in-place mutations."""
from pathlib import Path
import re, sys
if len(sys.argv) != 3: raise SystemExit('Usage: APPLIQUER_V5_5.py <repo> <stage>')
root, stage = [Path(arg).resolve() for arg in sys.argv[1:]]
here = Path(__file__).resolve().parent
changed = {}

def load(filename):
    p = root / filename
    if not p.is_file(): raise ValueError(f'Fichier manquant: {filename}')
    s=p.read_text(encoding='utf-8')
    if 'BILUX V5.5' in s or 'LongAscensionAnchor' in s: raise ValueError(f'V5.5 deja presente: {filename}')
    return s

def replace(s, old, new, filename, count=1):
    actual = s.count(old)
    if actual != count: raise ValueError(f'{filename}: section attendue absente ou ambigue ({actual} au lieu de {count}): {old[:90]!r}')
    return s.replace(old, new, count)

try:
    # 1. Additive optional model, pure Foundation progression engine, no pbx modifications.
    f='BiluxIOS/Models.swift'; s=load(f)
    s=replace(s, '    var exerciseLibrary: [String]? = nil',
              '    var exerciseLibrary: [String]? = nil\n    var longAscensionAnchor: LongAscensionAnchor? = nil',f)
    s=s.rstrip()+'\n\n'+(here/'ENGINE_V55.swift.txt').read_text(encoding='utf-8').strip()+'\n'
    changed[f]=s

    # 2. Preserve old XP, level, and unlocked stage on first launch; journal remains unchanged.
    f='BiluxIOS/BiluxStore.swift'; s=load(f)
    s=replace(s, '''        if let file = try? Data(contentsOf: url), let recovered = try? JSONDecoder().decode(BiluxData.self, from: file) {
            data = recovered
        }
    }
    func save()''',
    '''        if let file = try? Data(contentsOf: url), let recovered = try? JSONDecoder().decode(BiluxData.self, from: file) {
            data = recovered
        }
        // V5.5: la premiere migration fige les XP deja gagnes et les formes acquises.
        if data.longAscensionAnchor == nil {
            data.longAscensionAnchor = BILUXV55Progression.makeAnchor(data)
            save()
        }
    }
    func save()''',f)
    start=s.index('    var totalXP: Int {'); end=s.index('    var todaysMeals:',start)
    section=s[start:end]
    if 'let workoutXP = data.workouts.count * 25' not in section or 'var xpFraction:' not in section:
        raise ValueError('BiluxStore: modele XP de base non reconnu')
    new='''    var totalXP: Int { BILUXV55Progression.totalXP(data) }
    var heroLevel: Int { BILUXV55Progression.heroLevel(data) }
    var unlockedStageIndex: Int { BILUXV55Progression.stageIndex(data) }
    var rankName: String { BILUXV55Progression.stageNames[unlockedStageIndex].capitalized }
    var xpFraction: Double { BILUXV55Progression.fraction(data) }
    var xpToNextLevel: Int { BILUXV55Progression.remainingXP(data) }
    var questsToday: (workout: Bool, meal: Bool, checkin: Bool) {
        let value = BILUXV55Progression.currentQuestProgress(data)
        return (value.todayWorkout, value.todayMeal, value.todayCheckin)
    }
'''
    s=s[:start]+new+s[end:]
    # On an empty new phone, restore the full V5.5 XP anchor from exported JSON.
    s=replace(s, '            let result = try V3Import.parse(object)\n',
              '            let result = try V3Import.parse(object)\n            let emptyBeforeImport = data.workouts.isEmpty && data.meals.isEmpty && data.checkins.isEmpty && data.labs.isEmpty\n',f)
    s=replace(s, '            if data.caloriesGoal == nil { data.caloriesGoal = result.caloriesGoal }\n            save()', "            if data.caloriesGoal == nil { data.caloriesGoal = result.caloriesGoal }\n            // Restauration complète du point de départ XP depuis une sauvegarde BILUX.\n            // Ne pas réécrire la progression d'un journal déjà actif.\n            if emptyBeforeImport {\n                data.longAscensionAnchor = result.longAscensionAnchor\n                    ?? BILUXV55Progression.makeAnchor(data)\n            }\n            save()",f)
    changed[f]=s

    # 3. One Watch snapshot truth: same XP and rank engine as iPhone.
    f='BiluxIOS/WatchPhoneBridge.swift'; s=load(f)
    start=s.index('        let xp = data.workouts.count * 25'); end=s.index('        let now = Date()',start)
    if 'case 15...' not in s[start:end] or 'Set(data.meals.map' not in s[start:end]:
        raise ValueError('WatchPhoneBridge: modele XP ancien non reconnu')
    s=s[:start]+'''        let xp = BILUXV55Progression.totalXP(data)
        let level = BILUXV55Progression.heroLevel(data)
        let rank = BILUXV55Progression.stageNames[BILUXV55Progression.stageIndex(data)]
'''+s[end:]
    start=s.index('        let didWorkout = data.workouts.contains')
    end=s.index('        snapshot = WatchSnapshot(', start)
    if 'didCheckin' not in s[start:end]: raise ValueError('Watch quest base not recognized')
    s=s[:start]+'        let questStatus = BILUXV55Progression.currentQuestProgress(data, now: now)\n        let didWorkout = questStatus.todayWorkout\n        let didEat = questStatus.todayMeal\n        let didCheckin = questStatus.todayCheckin\n'+s[end:]
    s=replace(s,'xpProgress: Double(xp % 100) / 100,', 'xpProgress: BILUXV55Progression.fraction(data),',f)
    s=replace(s,'completed: didWorkout, reward: 25','completed: didWorkout, reward: 45',f)
    s=replace(s,'completed: didEat, reward: 8','completed: didEat, reward: 6',f)
    s=replace(s,'completed: didCheckin, reward: 8','completed: didCheckin, reward: 6',f)
    changed[f]=s

    # 4. App screens: preserve the working 5.3.2 portrait transitions and mastery tree.
    f='BiluxIOS/BiluxScreens.swift'; s=load(f)
    if 'outgoingArtwork' not in s or 'duration: 6.5' not in s or 'NuclearMasteryTree' not in s:
        raise ValueError('BiluxScreens: base V5.3.2 requise (portrait ou arbre introuvable)')
    for old, new in [('minLevel: 3, subtitle:', 'minLevel: 11, subtitle:'),
                     ('minLevel: 6, subtitle:', 'minLevel: 31, subtitle:'),
                     ('minLevel: 10, subtitle:', 'minLevel: 56, subtitle:'),
                     ('minLevel: 15, subtitle:', 'minLevel: 81, subtitle:')]:
        s=replace(s,old,new,f)
    s=replace(s,'    private var lockedPreview: Bool { stageOverride != nil && stage.minLevel > level }',
              '    private var lockedPreview: Bool { stageOverride != nil && stage.minLevel > level && stage.id > minimumStage }',f)
    s=replace(s,'    let stageOverride: NuclearStage?\n    @Environment',
                '    let stageOverride: NuclearStage?\n    let minimumStage: Int\n    @Environment',f)
    s=replace(s,'''    init(level: Int, effectsEnabled: Bool, stageOverride: NuclearStage? = nil) {
        self.level = level
        self.effectsEnabled = effectsEnabled
        self.stageOverride = stageOverride
    }''',
    '''    init(level: Int, effectsEnabled: Bool, stageOverride: NuclearStage? = nil, minimumStage: Int = 0) {
        self.level = level
        self.effectsEnabled = effectsEnabled
        self.stageOverride = stageOverride
        self.minimumStage = minimumStage
    }''',f)
    # Level-up modal keeps a legacy-rank image if previously unlocked.
    s=replace(s,'private struct NuclearLevelUp: View {\n    let level: Int',
              'private struct NuclearLevelUp: View {\n    let level: Int\n    let legacyStage: Int',f)
    s=replace(s,'''    private var stage: NuclearStage { NuclearStage.current(level: level) }
    private var newForm: Bool { stage.minLevel == level }''',
    '''    private var stage: NuclearStage {
        NuclearStage.all[max(NuclearStage.current(level: level).id, legacyStage)]
    }
    private var newForm: Bool { stage.minLevel == level && stage.id > legacyStage }''',f)
    s=replace(s,'NuclearLevelUp(level: journal.heroLevel) {',
              'NuclearLevelUp(level: journal.heroLevel, legacyStage: journal.data.longAscensionAnchor?.legacyStage ?? 0) {',f)
    s=replace(s,'NuclearHeroAura(level: journal.heroLevel, effectsEnabled: effectsEnabled, stageOverride: homeStage)',
              'NuclearHeroAura(level: journal.heroLevel, effectsEnabled: effectsEnabled, stageOverride: homeStage, minimumStage: journal.unlockedStageIndex)',f)
    s=replace(s,'NuclearHeroAura(level: journal.heroLevel, effectsEnabled: effectsEnabled, stageOverride: NuclearStage.all[selectedStage])',
              'NuclearHeroAura(level: journal.heroLevel, effectsEnabled: effectsEnabled, stageOverride: NuclearStage.all[selectedStage], minimumStage: journal.unlockedStageIndex)',f)
    s=replace(s,'$0.id == equippedTransformationID && $0.minLevel <= journal.heroLevel',
              '$0.id == equippedTransformationID && $0.id <= journal.unlockedStageIndex',f,count=2)
    s=replace(s,'?? NuclearStage.current(level: journal.heroLevel)',
              '?? NuclearStage.all[journal.unlockedStageIndex]',f,count=2)
    s=replace(s,'    private var formIndex: Int {\n        switch journal.heroLevel { case 15...: return 4; case 10...: return 3; case 6...: return 2; case 3...: return 1; default: return 0 }\n    }',
              '    private var formIndex: Int { journal.unlockedStageIndex }',f)
    s=replace(s,'Text("\\(100 - journal.totalXP % 100) XP avant le prochain niveau")',
              'Text(journal.heroLevel >= 100 ? "MAÎTRISE ULTIME" : "\\(journal.xpToNextLevel) XP avant le prochain niveau")',f)
    # Daily XP labels and qualification (the day has to be after V5.5 migration).
    s=replace(s,'quest("Consigner une séance", done: journal.data.workouts.contains { BiluxFormat.sameDay($0.date, .now) }, xp: "25 XP")',
              'quest("Consigner une séance", done: journal.questsToday.workout, xp: "45 XP")',f)
    s=replace(s,'quest("Suivre l\'alimentation", done: !journal.todaysMeals.isEmpty || health.today.consumedKcal != nil, xp: "8 XP")',
              'quest("Suivre l\'alimentation", done: journal.questsToday.meal, xp: "6 XP")',f)
    s=replace(s,'quest("Noter ton ressenti", done: journal.data.checkins.contains { BiluxFormat.sameDay($0.date, .now) }, xp: "8 XP")',
              'quest("Noter ton ressenti", done: journal.questsToday.checkin, xp: "6 XP")',f)
    s=replace(s,'let unlocked = journal.heroLevel >= stage.minLevel',
              'let unlocked = journal.unlockedStageIndex >= stage.id',f)
    s=replace(s,'journal.heroLevel >= stage.minLevel',
              'journal.unlockedStageIndex >= stage.id',f,count=2)
    s=replace(s,'(equippedTransformationID == -1 && NuclearStage.current(level: journal.heroLevel).id == stage.id)',
              '(equippedTransformationID == -1 && journal.unlockedStageIndex == stage.id)',f)
    s=replace(s,'Text("+25 XP par séance, +8 XP par jour de repas saisis et +8 XP par jour de bilan. Aucun malus de repos.")',
              'Text("V5.5 : 45 XP par journée de séance (10 min min., max. 5 jours/semaine), 6 XP par journée de repas ou de ressenti, plus quêtes et boss. Aucun malus de repos.")',f)
    s=replace(s, r'"Transformation acquise · niveau \(stage.minLevel)"',
              r'(journal.heroLevel < stage.minLevel ? "Forme acquise avant V5.5 · conservée" : "Transformation acquise · niveau \(stage.minLevel)")', f)
    # Add new quests board to Ascension only (not the Home transformation header).
    start=s.index('struct AscensionScreen: View {')
    asc=s[start:]
    asc=replace(asc,'                    SectionCaption(title: "Les cinq transformations")',
                '                    LongAscensionQuestBoard()\n                    SectionCaption(title: "Les cinq transformations")',f)
    s=s[:start]+asc
    s=s.rstrip()+'\n'+(here/'QUESTS_V55.swift.txt').read_text(encoding='utf-8')
    changed[f]=s

    # 5. Watch symbol follows the rank itself, not the obsolete V5.4 level thresholds.
    f='BiluxWatch/WatchRootView.swift'; s=load(f)
    old='''        switch level {
        case 15...: return "crown.fill"
        case 10...: return "atom"
        case 6...: return "bolt.fill"
        case 3...: return "sparkles"
        default: return "shield.fill"
        }'''
    new='''        switch rank.uppercased() {
        case "ASCENSION": return "crown.fill"
        case "NUCLÉAIRE": return "atom"
        case "RÉACTEUR": return "bolt.fill"
        case "ÉVEIL": return "sparkles"
        default: return "shield.fill"
        }'''
    s=replace(s,old,new,f)
    changed[f]=s

    for filename, text in changed.items():
        if '<<<<<<< ' in text or '>>>>>>> ' in text: raise ValueError('Marqueur de conflit detecte')
        p=stage/filename
        p.parent.mkdir(parents=True,exist_ok=True)
        p.write_text(text,encoding='utf-8')
        print(f'✅ {filename} ({len(text.splitlines())} lignes), aucun fichier original touche')
    print('✅ V5.5 preparee en zone temporaire')
except (OSError, ValueError) as exc:
    print('❌ ARRET SANS MODIFICATION :',exc,file=sys.stderr)
    sys.exit(1)
