# ☢️ BILUX V5.5 — THE LONG ASCENSION

## Avant tout : conserver une sauvegarde

Dans la V5.4 installée sur l'iPhone, ouvre **Ascension → Préparer la sauvegarde V4 → Partager le fichier JSON** et garde-le en sécurité. Le fichier peut contenir des données personnelles et médicales. Ne le mets pas dans un dépôt GitHub public.

## Contenu V5.5

- **100 niveaux** ; XP nécessaire au niveau 100 : **13 330 XP**. Objectif de rythme indicatif : environ **6 à 12 mois**, selon tes séances et ton usage du journal ; il n'y a aucune date de fin imposée.
- Paliers : **Survivant 1–10**, **Éveil 11–30**, **Réacteur 31–55**, **Nucléaire 56–80**, **Ascension 81–100**.
- **Migration unique** au premier démarrage : les anciens XP, le niveau existant et les formes déjà débloquées sont conservés dans le journal JSON (`longAscensionAnchor`). Les données de sport, nutrition, santé et les portraits restent inchangés.
- **45 XP** par journée avec une séance d'au moins **10 minutes**, dans la limite de **5 jours/semaine** ; **6 XP** par journée de repas noté et **6 XP** par journée de ressenti noté, maximum 5 jours/semaine chacun.
- Quêtes hebdomadaires : **3 jours d'entraînement (+70 XP)**, **4 jours de repas (+20 XP)**, **3 jours de journal (+25 XP)**.
- **Boss mensuel** : 12 journées de séance dans le mois (**+140 XP**).
- **Boss légendaire trimestriel** : 30 journées de séance dans le trimestre civil (**+180 XP**).
- Une seule récompense par objectif et période ; les répétitions d'une séance le même jour ne rapportent pas deux fois les XP. Aucun malus de repos ; pas de récompense conditionnée aux résultats de tests médicaux.
- L'Apple Watch continue d'envoyer les séances et affiche les nouveaux rangs et les XP synchronisés.
- Le niveau 100 donne le titre « Maîtrise ultime » dans l'interface ; l'historique continue après le niveau 100.

**Important :** les quêtes nouvelles ne recalculent pas les anciens événements d'avant la migration. Ils sont déjà inclus dans la base d'XP conservée. Modifier/supprimer une séance postérieure à la migration recalcule les XP associés à cette séance et aux objectifs concernés.

## Étape 1 — GitHub (iPhone)

1. Ouvrir `https://github.com/bilelguilal-prog/Bilux-`.
2. Sélectionner la branche stable **`bilux-v5.4-watch-2`**.
3. **Add file → Upload files**, envoyer **`BILUX_V5_5_LONG_ASCENSION.zip`**, valider le commit.

## Étape 2 — Codespaces

Dans le terminal à la racine du projet :

```bash
git switch bilux-v5.4-watch-2 && git pull --ff-only origin bilux-v5.4-watch-2 && unzip -o BILUX_V5_5_LONG_ASCENSION.zip -d /tmp/bilux-v55 && bash /tmp/bilux-v55/INSTALLER_V5_5.sh
```

Le script vérifie les fichiers sur la branche V5.4, prépare la V5.5 dans un dossier temporaire, vérifie la syntaxe Swift si Swift est installé, crée la branche **`bilux-v5.5-long-ascension`** et pousse le commit. Si une structure inattendue est détectée, le script s'arrête avant de modifier le projet. Il ne lance **pas** le build 11.

## Étape 3 — Deux tests Codemagic AVANT publication

Sur la branche `bilux-v5.5-long-ascension`, exécuter :

1. **BILUX — Vérifier le projet iOS (sans Apple Developer)**.
2. **BILUX V4.1 — Vérifier Apple Watch (sans signature)**.

Si l'un des tests échoue, ne pas préparer le build 11 : enregistrer le journal d'erreur.

## Étape 4 — Build 11 après les deux tests verts

```bash
unzip -o BILUX_V5_5_LONG_ASCENSION.zip -d /tmp/bilux-v55 && bash /tmp/bilux-v55/PREPARER_BUILD_11.sh
```

Le script vérifie d'abord que les deux cibles (iPhone et Watch) sont au build 10, puis passe les deux à **11**, commit et push. Il ne modifie pas la version marketing.

## Étape 5 — TestFlight

Dans Codemagic, lancer **BILUX — Publier sur TestFlight** sur la branche `bilux-v5.5-long-ascension`. Une fois publié et installé, vérifier :

- Niveau et XP inchangés au premier lancement de la V5.5, anciennes formes toujours déverrouillées.
- « Ascension » affiche les quêtes hebdomadaires, boss mensuel et boss légendaire.
- Sur l'Apple Watch, une séance de 10 minutes ou plus se synchronise avec l'iPhone ; les XP se rafraîchissent.
- Le journal antérieur, les exercices, les repas et les bilans sont toujours présents.
- Les transformations gardent les transitions fluides de la V5.3.2.

## Vérifications déjà exécutées (hors Xcode)

- Analyse syntaxique Swift des cinq fichiers modifiés avec `swiftc -frontend -parse`.
- Tests Swift Foundation de la courbe, de la migration, des quêtes, de l'anti-doublon, des deux boss et du codage/décodage JSON.
- Simulation d'installation sur une copie reconstruite de V5.4 et simulation de passage du build 10 au build 11 pour les deux apps.
- Simulation d'une base incompatible : arrêt sans écriture.

**Limite :** compilation SwiftUI et validation de l'app réelle non effectuées ici ; les workflows Codemagic sont obligatoires.
