#!/usr/bin/env bash
set -euo pipefail
[[ "$(git branch --show-current)" == "bilux-v5.5-long-ascension" ]] || { echo '❌ Branche v5.5 attendue'; exit 1; }
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || { echo '❌ Sauvegarde les modifications locales'; exit 1; }
python3 - <<'PY'
import plistlib
from pathlib import Path
files=[Path('BiluxIOS/Info.plist'),Path('BiluxWatch/Info.plist')]
for f in files:
    if not f.exists(): raise SystemExit(f'❌ {f} absent')
    with f.open('rb') as h: p=plistlib.load(h)
    print(f, 'version actuelle',p.get('CFBundleVersion'))
    if str(p.get('CFBundleVersion'))!='10':
        raise SystemExit('❌ Build 10 attendu dans les deux Info.plist. Aucun fichier modifie.')
for f in files:
    with f.open('rb') as h: p=plistlib.load(h)
    p['CFBundleVersion']='11'
    with f.open('wb') as h: plistlib.dump(p,h,fmt=plistlib.FMT_XML,sort_keys=False)
print('✅ Build 11 iPhone + Watch configure')
PY
git add BiluxIOS/Info.plist BiluxWatch/Info.plist
git diff --cached --check
git commit -m 'BILUX V5.5 - TestFlight build 11'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
  git push -u origin bilux-v5.5-long-ascension
else
  echo '🧪 Test local : push non effectue.'
fi
echo '✅ Build 11 envoye. Lancer workflow TestFlight dans Codemagic.'
