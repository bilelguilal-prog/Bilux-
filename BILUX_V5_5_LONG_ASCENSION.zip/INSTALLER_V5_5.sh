#!/usr/bin/env bash
set -euo pipefail
BASE="bilux-v5.4-watch-2"
BRANCH="bilux-v5.5-long-ascension"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail() { echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Place-toi a la racine de ton projet.'
[[ "$(git branch --show-current)" == "$BASE" ]] || fail "Branche attendue : $BASE"
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications locales non sauvegardees.'
! git show-ref --verify --quiet "refs/heads/$BRANCH" || fail "La branche $BRANCH existe deja."
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
python3 "$HERE/APPLIQUER_V5_5.py" "$(pwd)" "$TMP/stage" || fail 'Compatibilite de la base non confirmee.'
FILES=(BiluxIOS/Models.swift BiluxIOS/BiluxStore.swift BiluxIOS/BiluxScreens.swift BiluxIOS/WatchPhoneBridge.swift BiluxWatch/WatchRootView.swift)
if command -v swiftc >/dev/null 2>&1; then
  swiftc -frontend -parse "${FILES[@]/#/$TMP/stage/}" || fail 'Erreur syntaxe Swift. Rien modifie.'
  echo '✅ Syntaxe Swift validee (compilation SwiftUI a faire sur Codemagic).'
else
  echo 'ℹ️ swiftc absent, la compilation reelle se fera sur Codemagic.'
fi
# No mutations before all file checks succeed. Branch starts at the validated base.
git switch -c "$BRANCH"
for f in "${FILES[@]}"; do cp "$TMP/stage/$f" "$f"; done
git add -- "${FILES[@]}"
git diff --cached --check || fail 'Controle Git non passe : ne pas publier.'
git commit -m 'BILUX V5.5 - long ascension, preserved XP, quests and boss'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
  git push -u origin "$BRANCH" || fail "Push interrompu : relance git push -u origin $BRANCH"
else
  echo '🧪 Test local : push non effectue.'
fi
echo "✅ V5.5 envoyee : $BRANCH"
echo '➡️ Controle d abord les workflows iPhone et Apple Watch sur Codemagic.'
