#!/usr/bin/env python3
'''Additive, fail-closed V5.4 install: preserves existing WatchRootView as LegacyWatchRootView.
Writes to an isolated staging directory; caller copies only after all checks.
'''
from pathlib import Path
import re, sys

if len(sys.argv) != 3:
    raise SystemExit("Usage: apply_additive.py <repo_root> <staging_dir>")
root, staging = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
scriptdir = Path(__file__).resolve().parent
required = [
    Path('BiluxWatch/WatchRootView.swift'),
    Path('BiluxWatch/WatchBridge.swift'),
    Path('BiluxIOS/WatchPhoneBridge.swift'),
]
for rel in required:
    if not (root/rel).is_file():
        raise SystemExit(f"ARRET: fichier absent: {rel}")
    (staging/rel.parent).mkdir(parents=True, exist_ok=True)

rootf=root/required[0]
s=rootf.read_text(encoding='utf-8')
if 'BILUX V5.4 — Watch 2.0' in s or 'LegacyWatchRootView' in s or 'V54WatchWorkoutView' in s:
    raise SystemExit('ARRET: éléments V5.4 déjà présents; vérification manuelle requise')
pattern=r'(?m)^(\s*)(struct\s+WatchRootView\s*:\s*View\s*\{)'
matches=list(re.finditer(pattern,s))
if len(matches)!=1:
    raise SystemExit('ARRET: declaration WatchRootView introuvable ou ambiguë; aucun changement')
if not re.search(r'(?m)^\s*struct\s+WatchWorkoutView\s*:\s*View\s*\{',s):
    raise SystemExit('ARRET: WatchWorkoutView ancien introuvable; aucun changement')

# Only rename the legacy root type. All existing code stays present and compiled.
s=re.sub(r'(?m)^(\s*)struct(\s+)WatchRootView(\s*:\s*View\s*\{)',
         r'\1struct\2LegacyWatchRootView\3',s,count=1)
modern=(scriptdir/'NOUVEL_ECRAN_V54.swift').read_text(encoding='utf-8')
assert modern.count('struct WatchRootView: View')==1
assert 'struct V54WatchWorkoutView: View' in modern
s=s.rstrip('\n')+'\n\n// MARK: - BILUX V5.4 — Nouvel écran, ancien écran conservé ci-dessus\n'+modern.rstrip('\n')+'\n'
(staging/required[0]).write_text(s,encoding='utf-8')

# Watch bridge: extend existing API with backward-compatible default argument.
s=(root/required[1]).read_text(encoding='utf-8')
pattern=r'func\s+finishWorkout\s*\(\s*start:\s*Date\s*,\s*elapsedMinutes:\s*Int\s*\)\s*\{'
if len(re.findall(pattern,s))!=1:
    raise SystemExit('ARRET: API finishWorkout differente; aucun changement')
s=re.sub(pattern,'func finishWorkout(start: Date, elapsedMinutes: Int, activity: String = "Séance Apple Watch") {',s,count=1)
mark='"durationMinutes": min(elapsedMinutes, 240),'
if s.count(mark)!=1:
    raise SystemExit('ARRET: payload WatchBridge inattendu; aucun changement')
s=s.replace(mark,mark+' "activity": activity,',1)
(staging/required[1]).write_text(s,encoding='utf-8')

# iPhone bridge: accept only a known activity category; old watch remains supported.
s=(root/required[2]).read_text(encoding='utf-8')
mark='activity: "Séance Apple Watch", durationMinutes: duration,'
if s.count(mark)!=1:
    raise SystemExit('ARRET: journal iPhone inattendu; aucun changement')
replacement='''activity: activity, durationMinutes: duration,'''
s=s.replace(mark,replacement,1)
needle='''        journal.add(WorkoutSession('''
if s.count(needle)!=1:
    raise SystemExit('ARRET: insertion du journal iPhone ambigue; aucun changement')
checks='''        // BILUX V5.4 : catégorie validée, repli compatible avec les anciennes Watch.
        let allowedActivities: Set<String> = ["Musculation", "Marche", "Cardio", "Mobilité"]
        let requestedActivity = message["activity"] as? String
        let activity = requestedActivity.flatMap { allowedActivities.contains($0) ? $0 : nil } ?? "Séance Apple Watch"
'''
s=s.replace(needle,checks+needle,1)
(staging/required[2]).write_text(s,encoding='utf-8')

# Sanity check: no accidental conflict markers, unique public entry view.
for rel in required:
    candidate=(staging/rel).read_text(encoding='utf-8')
    assert '<<<<<<< ' not in candidate and '>>>>>>> ' not in candidate
    assert candidate.strip()
if (staging/required[0]).read_text().count('struct WatchRootView: View')!=1:
    raise SystemExit('ARRET: déclaration d entree WatchRootView non unique')
for rel in required:
    before=(root/rel).read_bytes()
    after=(staging/rel).read_bytes()
    if before==after:
        raise SystemExit(f'ARRET: résultat inchangé: {rel}')
    print(f'✅ {rel} : ancien code préservé, intégration V5.4 préparée')
