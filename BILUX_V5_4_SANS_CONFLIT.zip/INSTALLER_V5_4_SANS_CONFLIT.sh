#!/usr/bin/env bash
set -euo pipefail
SOURCE='bilux-v5.3.2-slow-aura'
TARGET='bilux-v5.4-watch-2'
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail(){ printf '❌ %s\n' "$*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Execute cette commande à la racine de BILUX.'
[[ "$(git branch --show-current)" == "$SOURCE" ]] || fail "Branche attendue : $SOURCE."
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications non enregistrées : sauvegarde-les avant.'
! git show-ref --verify --quiet "refs/heads/$TARGET" || fail "La branche $TARGET existe déjà."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
python3 "$HERE/APPLIQUER_V5_4_SANS_FUSION.py" "$(pwd)" "$TMP/stage" || fail 'Installation interrompue avant toute modification.'
if command -v swiftc >/dev/null 2>&1; then
    swiftc -frontend -parse "$TMP/stage/BiluxWatch/WatchRootView.swift" "$TMP/stage/BiluxWatch/WatchBridge.swift" "$TMP/stage/BiluxIOS/WatchPhoneBridge.swift" || fail 'La syntaxe Swift n est pas valide.'
    echo '✅ Syntaxe Swift validée.'
else
    echo 'ℹ️ swiftc absent : la vraie compilation se fera sur Codemagic.'
fi
git switch -c "$TARGET"
for f in BiluxWatch/WatchRootView.swift BiluxWatch/WatchBridge.swift BiluxIOS/WatchPhoneBridge.swift; do
    cp "$TMP/stage/$f" "$f"
done
git add -- BiluxWatch/WatchRootView.swift BiluxWatch/WatchBridge.swift BiluxIOS/WatchPhoneBridge.swift
git diff --cached --check || fail 'Problème de format du correctif. Ne pas publier.'
git commit -m 'BILUX V5.4 - Watch 2.0 integrated without merge conflicts'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
    git push -u origin "$TARGET" || fail 'Commit local créé mais push échoué. Relance git push -u origin bilux-v5.4-watch-2.'
else
    echo '🧪 Test : push volontairement non exécuté.'
fi
printf '\n✅ BILUX V5.4 envoyée : branche %s\n' "$TARGET"
echo 'Prochaine étape : tests iOS et Apple Watch sur Codemagic, puis seulement build 10.'
