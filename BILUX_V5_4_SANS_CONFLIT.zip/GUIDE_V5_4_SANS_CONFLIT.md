# BILUX V5.4 — intégration additive sans fusion de WatchRootView.swift

**Cause du blocage :** l'ancien patch V5.4 partait d'une autre version du fichier `WatchRootView.swift`. Le `git merge-file` a détecté un conflit. Ne force pas le patch.

**Principe de ce correctif :** garder tout le code Watch existant (renommage du seul `WatchRootView` initial en `LegacyWatchRootView`) et ajouter un écran Watch 2.0 avec des helpers préfixés `V54` pour éviter les collisions. Deux modifications mineures et vérifiées sont ajoutées aux bridges iPhone/Watch pour transmettre le type de séance.

**Préparation :** téléverser le ZIP sur la branche `bilux-v5.3.2-slow-aura` dans GitHub, puis dans Codespaces (racine du dépôt) :

```bash
git switch bilux-v5.3.2-slow-aura && git pull --ff-only origin bilux-v5.3.2-slow-aura && unzip -o BILUX_V5_4_SANS_CONFLIT.zip -d /tmp/bilux-v54-fixed && bash /tmp/bilux-v54-fixed/INSTALLER_V5_4_SANS_CONFLIT.sh
```

Ce script **ne modifie rien** si les points d'intégration sont manquants ou ambigus, ni en cas de modifications suivies non enregistrées. Il prépare les fichiers dans un dossier temporaire, vérifie la syntaxe Swift si l'outil est présent, puis crée `bilux-v5.4-watch-2` et pousse la branche.

Après installation, faire les deux compilations Codemagic sur cette branche : iOS sans signature puis Watch sans signature. Si les deux sont vertes, appeler `bash /tmp/bilux-v54-fixed/PREPARER_BUILD_10.sh`, et seulement ensuite publier sur TestFlight. **Ne pas relancer** l'ancien patch.

**Limite :** sans accès aux fichiers exacts du dépôt dans l'environnement de compilation Xcode, nous ne pouvons pas garantir le succès de la compilation. Le script s'arrête plutôt que de dégrader la version V5.3.2 stable. En cas d'arrêt, transmettre la sortie de contrôle du terminal.
