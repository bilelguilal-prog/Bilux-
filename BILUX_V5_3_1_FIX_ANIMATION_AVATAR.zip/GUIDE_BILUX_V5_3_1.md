# BILUX V5.3.1 — Correctif animation de l'avatar

## Pourquoi l'animation se deforme ?
Dans V5.3, le modificateur `.animation(.easeInOut(duration: 3).repeatForever(...), value: energized)` est appliqué **à l'ensemble du `GeometryReader`**, ce qui peut animer par accident la taille des sous-vues pendant l'apparition. La vidéo montre la photo qui se comprime en colonne, puis revient à sa taille normale.

## Ce que change V5.3.1
- `BiluxIOS/BiluxScreens.swift` : remplacement **uniquement** du composant `NuclearHeroAura`.
- Le portrait garde une taille constante issue du conteneur (`GeometryReader`), une image source à ratio inchangé (`scaledToFill`) et un recadrage stable.
- Animation de respiration du halo et de l'anneau **localisée à ces deux overlays** ; plus d'animation globale du conteneur.
- Changement de forme par fondu d'opacité entre deux portraits (0,55 s), sans interpolation de la largeur, hauteur ou ratio.
- Respect de `Réduire les animations` et du réglage intégré ; **aucune modification** du modèle des données, des XP, de l'Apple Watch ou de la sauvegarde JSON.

## Installer depuis iPhone
1. Sur GitHub, choisir `bilux-v5.3-metamorphosis`, importer `BILUX_V5_3_1_FIX_ANIMATION_AVATAR.zip` et faire `Commit changes`.
2. Depuis la racine du dépôt dans Codespaces :

```bash
git switch bilux-v5.3-metamorphosis && git pull --ff-only origin bilux-v5.3-metamorphosis && unzip -o BILUX_V5_3_1_FIX_ANIMATION_AVATAR.zip -d /tmp/bilux-v531 && bash /tmp/bilux-v531/INSTALLER_V5_3_1.sh
```

3. Dans Codemagic : branche **`bilux-v5.3.1-avatar-fix`** → workflow « Vérifier le projet iOS (sans Apple Developer) ».
4. Si la compilation réussit, dans Codespaces : `bash /tmp/bilux-v531/PREPARER_BUILD_8.sh`, puis Codemagic TestFlight sur la même branche, version attendue **1.0 (8)**.

## Vérification sur iPhone
- Depuis Ascension, laisser tourner le halo pendant 10 secondes : **pas de portrait qui s'écrase en colonne**.
- Appuyer successivement sur *Survivant*, *Éveil* et un rang verrouillé : le portrait change par fondu et le cadre ne bouge pas.
- Couper « Animations nucléaires » : aucune animation répétée, l'image reste entièrement visible.
- Vérifier Accueil et les statistiques Sport. Si problème, revenir au build 7 et conserver la sauvegarde JSON.

## Si tu préfères coller directement du code
Dans `BiluxIOS/BiluxScreens.swift`, remplacer tout le bloc à partir de `private struct NuclearHeroAura: View {` **jusqu'avant** `private struct NuclearSkillRow: View {` par le contenu de `NuclearHeroAura_V5_3_1.swift`. Ne pas supprimer `NuclearSkillRow` ni ajouter le nouveau composant en double.

## Validation de ce paquet
Le code a été soumis à `swiftc -frontend -parse` sur Linux et le patch a été appliqué en simulation Git. Le compilateur **iOS réel** (SwiftUI) et le rendu doivent être validés dans Codemagic et sur iPhone.
