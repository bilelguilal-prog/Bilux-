#!/usr/bin/env bash
set -euo pipefail
BASE='bilux-v5.3.1-avatar-fix'
[[ "$(git branch --show-current)" == "$BASE" ]] || { echo "❌ Branche $BASE attendue." >&2; exit 1; }
python3 - <<'PY'
from pathlib import Path
import re, plistlib
files = [Path('BiluxIOS/Info.plist'), Path('BiluxWatch/Info.plist')]
pattern = re.compile(r'(<key>CFBundleVersion</key>\s*<string>)7(</string>)')
updates = []
for path in files:
    src = path.read_text()
    info = plistlib.loads(src.encode('utf-8'))
    if str(info.get('CFBundleVersion')) != '7':
        raise SystemExit(f"❌ {path}: build 7 attendu, trouvé {info.get('CFBundleVersion')!r}. Aucun fichier modifié.")
    new, count = pattern.subn(r'\g<1>8\g<2>', src)
    if count != 1 or str(plistlib.loads(new.encode('utf-8'))['CFBundleVersion']) != '8':
        raise SystemExit(f"❌ {path}: structure inattendue. Aucun fichier modifié.")
    updates.append((path,new))
for path,new in updates:
    path.write_text(new)
    print(f'✅ {path}: build 7 → 8')
PY
git diff --check
git add -- BiluxIOS/Info.plist BiluxWatch/Info.plist
git commit -m 'BILUX V5.3.1 - Build 8 iPhone et Watch'
git push origin "$BASE"
