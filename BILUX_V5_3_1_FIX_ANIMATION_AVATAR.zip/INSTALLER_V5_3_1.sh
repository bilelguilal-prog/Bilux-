#!/usr/bin/env bash
set -euo pipefail
BASE='bilux-v5.3-metamorphosis'
DEST='bilux-v5.3.1-avatar-fix'
TARGET='BiluxIOS/BiluxScreens.swift'
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH="$HERE/BILUX_V5_3_1_AVATAR_ANIMATION.patch"
abort() { printf '❌ %s\n' "$*" >&2; exit 1; }
[[ -d .git && -f "$TARGET" && -f "$PATCH" ]] || abort 'Lance ce script depuis la racine du depot BILUX.'
[[ "$(git branch --show-current)" == "$BASE" ]] || abort "Branche attendue : $BASE."
[[ -z "$(git status --porcelain -- "$TARGET")" ]] || abort "Le fichier $TARGET contient deja des modifications non validees. Arret sans ecraser."
git diff --cached --quiet || abort 'Des modifications sont deja indexees : arret par securite.'
! git show-ref --verify --quiet "refs/heads/$DEST" || abort "La branche $DEST existe deja en local."
if git ls-remote --exit-code --heads origin "$DEST" >/dev/null 2>&1; then
    abort "La branche distante $DEST existe deja."
fi

git apply --check "$PATCH" || abort 'Le patch ne correspond pas exactement a BILUX V5.3. Aucune modification effectuee.'
git switch -c "$DEST"
git apply "$PATCH"
git diff --check || abort 'Le correctif contient un probleme de formatage.'
if command -v swiftc >/dev/null 2>&1; then
    swiftc -frontend -parse "$TARGET" || abort 'Le parseur Swift a detecte une erreur.'
fi

git add -- "$TARGET"
git commit -m 'BILUX V5.3.1 - Corriger la deformation de l avatar'
git push -u origin "$DEST"
printf '\n✅ BILUX V5.3.1 pousse sur GitHub : %s\n' "$DEST"
printf '➡️ Verifier avec Codemagic (simulateur sans signature), puis preparer le build 8.\n'
