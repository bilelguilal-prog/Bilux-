# BILUX V5.4 — Correctif de compatibilité (Watch 2.0)

## Pourquoi cette archive ?
Le premier patch V5.4 échouait à la ligne 1 de `BiluxWatch/WatchRootView.swift` car le code du dépôt avait divergé de la version utilisée pour préparer le patch. Le script réconcilie les trois fichiers Swift à partir d'une base commune, sans supprimer les modifications existantes lorsque la fusion est automatique.

## Sur iPhone
1. Dans GitHub, ouvre la branche `bilux-v5.3.2-slow-aura` du dépôt `bilelguilal-prog/Bilux-`.
2. **Add file → Upload files** : importe `BILUX_V5_4_WATCH_2_COMPATIBLE.zip`, puis **Commit changes**.
3. Ouvre GitHub Codespaces (terminal à la racine de Bilux-) et colle **une seule fois** :

```bash
git switch bilux-v5.3.2-slow-aura && git pull --ff-only origin bilux-v5.3.2-slow-aura && unzip -o BILUX_V5_4_WATCH_2_COMPATIBLE.zip -d /tmp/bilux-v54-compatible && bash /tmp/bilux-v54-compatible/INSTALLER_V5_4_COMPATIBLE.sh
```

L'installateur vérifie la branche, exige un espace de travail propre, calcule les changements dans un dossier temporaire et refuse les fusions avec conflits. Il n'altère pas la branche stable ; en cas de succès, crée `bilux-v5.4-watch-2` et la publie.

## Avant TestFlight
Sur Codemagic, branche `bilux-v5.4-watch-2`, utilise successivement les workflows de vérification du simulateur iOS et d'Apple Watch. **Ne publie pas encore** : le script n'a pas été compilé dans Xcode ici.

## Si le script affiche un conflit
Il stoppe **avant** de modifier les fichiers du dépôt. Envoie le message et, si possible, le contenu du fichier Swift signalé. On préparera un patch fondé sur ta version exacte.

## Préparation du build 10
Le script de préparation du build 10 de la V5.4 précédente est compatible après une installation réussie ; si le fichier temporaire `/tmp/bilux-v54/PREPARER_BUILD_10.sh` n'existe plus, récupère-le en décompressant l'ancien ZIP V5.4. Vérifier d'abord les deux workflows au vert.
