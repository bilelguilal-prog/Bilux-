#!/usr/bin/env bash
set -euo pipefail
SOURCE_BRANCH="bilux-v5.3.2-slow-aura"
DEST_BRANCH="bilux-v5.4-watch-2"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FILES=(
  "BiluxWatch/WatchRootView.swift"
  "BiluxWatch/WatchBridge.swift"
  "BiluxIOS/WatchPhoneBridge.swift"
)

fail() { printf '\n❌ %s\n' "$*" >&2; exit 1; }

[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail "Lance la commande depuis la racine du dépôt BILUX."
[[ "$(git branch --show-current)" == "$SOURCE_BRANCH" ]] || fail "Branche attendue : $SOURCE_BRANCH. Rien n'a été modifié."
git diff --quiet && git diff --cached --quiet || fail "Tu as des modifications Git non enregistrées. Arrêt de sécurité."
if git show-ref --verify --quiet "refs/heads/$DEST_BRANCH"; then
  fail "La branche locale $DEST_BRANCH existe déjà. Aucun fichier modifié."
fi

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

printf '🔎 Adaptation sûre du correctif V5.4 au code actuel…\n'
for relative in "${FILES[@]}"; do
  [[ -f "$relative" ]] || fail "Fichier manquant : $relative."
  [[ -f "$HERE/BASE/$relative" && -f "$HERE/NEW/$relative" ]] || fail "Archive de réparation incomplète : $relative."
  mkdir -p "$TMP/merged/$(dirname "$relative")"
  # Merge à trois sources : actuel / base d'origine / refonte voulue.
  # Tous les résultats sont calculés dans un dossier temporaire.
  if git merge-file -p -L "BILUX actuel" -L "Base V4.1" -L "BILUX V5.4" \
      "$relative" "$HERE/BASE/$relative" "$HERE/NEW/$relative" \
      > "$TMP/merged/$relative"; then
    echo "✅ Compatible : $relative"
  else
    fail "Conflit de fusion dans $relative. Aucun fichier du projet n'a été modifié. Envoie-moi le fichier pour un correctif ciblé."
  fi
done

# Pas de validation à l'aveugle : le résultat doit être différent du code actuel.
changed=0
for relative in "${FILES[@]}"; do
  if ! cmp -s "$relative" "$TMP/merged/$relative"; then changed=1; fi
done
[[ "$changed" -eq 1 ]] || fail "Les changements V5.4 semblent déjà présents. Arrêt sans modification."

git switch -c "$DEST_BRANCH"
for relative in "${FILES[@]}"; do
  cp "$TMP/merged/$relative" "$relative"
done
git add -- "${FILES[@]}"
git diff --cached --check
git diff --cached --quiet && fail "Aucun changement à committer."
git commit -m "BILUX V5.4 - Nuclear Watch 2.0 (base compatible)"
git push -u origin "$DEST_BRANCH"
printf '\n✅ BILUX V5.4 installée sur GitHub : %s\n' "$DEST_BRANCH"
printf '🧪 Étape suivante : tester iOS ET watchOS dans Codemagic avant le build 10.\n'
