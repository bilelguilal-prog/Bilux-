#!/usr/bin/env bash
set -euo pipefail
BRANCH='bilux-v6.1-nuclear-live'
[[ "$(git branch --show-current)" == "$BRANCH" ]] || { echo "❌ Branche $BRANCH obligatoire" >&2; exit 1; }
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || { echo '❌ Modifications locales détectées' >&2; exit 1; }
python3 - <<'PY'
from pathlib import Path
import plistlib
paths=[Path('BiluxIOS/Info.plist'),Path('BiluxWatch/Info.plist')]
for p in paths:
    obj=plistlib.loads(p.read_bytes())
    if str(obj.get('CFBundleVersion'))!='19':
        raise SystemExit(f'❌ {p}: build 19 attendu, trouvé {obj.get("CFBundleVersion")}. Aucun fichier modifié.')
for p in paths:
    obj=plistlib.loads(p.read_bytes());obj['CFBundleVersion']='20'
    p.write_bytes(plistlib.dumps(obj,fmt=plistlib.FMT_XML,sort_keys=False))
    print(f'✅ {p}: 19 → 20')
PY
git add BiluxIOS/Info.plist BiluxWatch/Info.plist
git diff --cached --check
git commit -m 'BILUX V6.1 - build 20 iPhone and Apple Watch'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then git push; else echo '🧪 Sans push'; fi
echo '✅ Build 20 préparé. Codemagic: Publier sur TestFlight.'
