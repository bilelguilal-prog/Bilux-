#!/usr/bin/env python3
"""BILUX V6.1: stage-only HealthKit workout integration (source files untouched)."""
from pathlib import Path
import plistlib
import sys

if len(sys.argv) != 3:
    sys.exit('Usage: APPLIQUER_V6_1.py DOSSIER_REPO DOSSIER_STAGING')
repo, stage = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
here = Path(__file__).resolve().parent


def read(rel):
    p = repo / rel
    if not p.is_file():
        raise SystemExit(f'❌ Fichier absent: {rel}')
    return p.read_text(encoding='utf-8')


def replace_once(s, old, new, why):
    n = s.count(old)
    if n != 1:
        raise SystemExit(f'❌ Base V6.0 incompatible ({why}), {n} marqueur(s) au lieu de 1. Aucun fichier modifié.')
    return s.replace(old, new, 1)


def write(rel, content):
    target = stage / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding='utf-8')
    print(f'✅ Préparé : {rel}')

# Garde-fous : base V6.0 et Watch 3.0 exactes, pas V6.1 appliquée.
watch = read('BiluxWatch/WatchRootView.swift')
assertions = [
    ('Watch 3.0', 'REBIRTH · WATCH 3.0' in watch),
    ('Fiche Ascension Watch', 'private var ascensionPage' in watch),
    ('Forge manuelle', 'struct V54WatchWorkoutView: View' in watch),
    ('Pas de V6.1', 'V61NuclearLive' not in watch)
]
for label, ok in assertions:
    if not ok:
        raise SystemExit(f'❌ Base incompatible ({label}). Aucun fichier modifié.')
watch = replace_once(watch, '            V54WatchWorkoutView().tag(4)\n',
                     '            V54WatchWorkoutView().tag(4)\n            V61LiveWorkoutView().tag(5)\n',
                     'onglet Nuclear Live')
watch = replace_once(watch,
'''                Button {
                    selectedPage = 3
                } label: {
                    Label("LES GARDIENS", systemImage: "shield.fill")''',
'''                Button {
                    selectedPage = 5
                } label: {
                    Label("NUCLEAR LIVE", systemImage: "heart.fill")
                        .font(.caption2.bold())
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .tint(V54ReactorTheme.purple)

                Button {
                    selectedPage = 3
                } label: {
                    Label("LES GARDIENS", systemImage: "shield.fill")''',
                     'bouton cockpit vers Nuclear Live')
watch = watch.rstrip() + '\n' + (here/'NUCLEAR_LIVE_V61.swift.txt').read_text(encoding='utf-8')
write('BiluxWatch/WatchRootView.swift', watch)

bridge = read('BiluxWatch/WatchBridge.swift')
if '"activity": activity' not in bridge or 'V61' in bridge:
    raise SystemExit('❌ WatchBridge non reconnu ou déjà modifié.')
bridge = replace_once(bridge,
'    private func flushWorkouts() {',
'''    // V6.1 : envoi idempotent après sauvegarde effective de HKWorkout.
    // UUID Apple Santé = UUID du journal BILUX ; WCSession peut rejouer le transfert.
    func finishLiveWorkout(start: Date, elapsedMinutes: Int, activity: String,
                           workoutID: UUID, activeKcal: Double?) {
        guard (1...240).contains(elapsedMinutes),
              WCSession.isSupported() else {
            feedback = "Séance Santé sauvegardée, mais transfert BILUX indisponible."
            return
        }
        var event: [String: Any] = [
            "type": "workoutCompleted", "id": workoutID.uuidString,
            "startedAt": start.timeIntervalSince1970,
            "durationMinutes": elapsedMinutes, "activity": activity,
            "source": "healthkit"
        ]
        if let activeKcal, activeKcal.isFinite {
            event["activeKcal"] = max(0, activeKcal)
        }
        var queued = UserDefaults.standard.array(forKey: pendingKey) as? [[String: Any]] ?? []
        if !queued.contains(where: { ($0["id"] as? String) == workoutID.uuidString }) {
            queued.append(event)
            UserDefaults.standard.set(queued, forKey: pendingKey)
        }
        flushWorkouts()
        feedback = "Nuclear Live sauvegardé. Transfert vers BILUX en cours."
    }

    private func flushWorkouts() {''', 'méthode de transfert HealthKit')
write('BiluxWatch/WatchBridge.swift', bridge)

iphone = read('BiluxIOS/WatchPhoneBridge.swift')
if 'let allowedActivities: Set<String>' not in iphone or 'notes: "Chronométrée dans BILUX Watch (sans enregistrement HealthKit)"' not in iphone:
    raise SystemExit('❌ WatchPhoneBridge V5.4+ introuvable ; aucun fichier modifié.')
iphone = replace_once(iphone,
'        journal.add(WorkoutSession(\n',
'''        // V6.1 : une vraie séance Santé, identifiée par son UUID d'origine,
        // peut figurer dans La Forge sans être recréée dans Apple Santé.
        let isLive = (message["source"] as? String) == "healthkit"
        let note: String
        if isLive {
            let calories = (message["activeKcal"] as? Double).flatMap { $0.isFinite ? max(0, $0) : nil }
            let energyText = calories.map { " · \\(Int($0.rounded())) kcal actives" } ?? ""
            note = "Nuclear Live : séance déjà sauvegardée dans Apple Santé\\(energyText)."
        } else {
            note = "Chronométrée dans BILUX Watch (sans enregistrement HealthKit)"
        }
        journal.add(WorkoutSession(
''', 'note pour journal BILUX')
iphone = replace_once(iphone,
'notes: "Chronométrée dans BILUX Watch (sans enregistrement HealthKit)", exercises: []',
'notes: note, exercises: []', 'note HealthKit vs manuelle')
write('BiluxIOS/WatchPhoneBridge.swift', iphone)

plistpath = repo/'BiluxWatch/Info.plist'
plist = plistlib.loads(plistpath.read_bytes())
if str(plist.get('CFBundleVersion')) != '19':
    raise SystemExit(f'❌ Le build 19 Watch est attendu, reçu {plist.get("CFBundleVersion")}')
if 'workout-processing' in plist.get('WKBackgroundModes', []):
    raise SystemExit('❌ Mode background déjà présent : vérifier le projet manuellement.')
plist['WKBackgroundModes'] = list(dict.fromkeys(plist.get('WKBackgroundModes', []) + ['workout-processing']))
plist['NSHealthShareUsageDescription'] = ('Avec votre autorisation, BILUX Watch lit le pouls et les calories actives '
                                          'pendant les entraînements Nuclear Live et pour votre suivi sportif.')
plist['NSHealthUpdateUsageDescription'] = ('Avec votre autorisation, Nuclear Live enregistre une séance '
                                           'dans Apple Santé uniquement lorsque vous la terminez sur la montre.')
newplist = plistlib.dumps(plist, fmt=plistlib.FMT_XML, sort_keys=False)
sp = stage/'BiluxWatch/Info.plist'; sp.parent.mkdir(parents=True,exist_ok=True)
sp.write_bytes(newplist)
print('✅ Préparé : BiluxWatch/Info.plist (autorisation et workout-processing)')

# Validate other build version (do not modify it until PREPARER_BUILD_20.sh).
ip = plistlib.loads((repo/'BiluxIOS/Info.plist').read_bytes())
if str(ip.get('CFBundleVersion')) != '19':
    raise SystemExit('❌ iPhone build 19 requis. Aucun fichier source modifié.')
print('✅ Base V6.0 build 19 reconnue. Quatre fichiers préparés en zone temporaire.')
