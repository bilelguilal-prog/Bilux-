#!/usr/bin/env bash
set -euo pipefail
BASE='bilux-v6.0-rebirth-watch3'
DEST='bilux-v6.1-nuclear-live'
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail(){ printf '❌ %s\n' "$*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Place-toi à la racine du dépôt BILUX.'
[[ "$(git branch --show-current)" == "$BASE" ]] || fail "Branche attendue : $BASE."
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications locales suivies détectées : arrêt.'
git diff --cached --quiet || fail 'Index Git non vide.'
! git show-ref --verify --quiet "refs/heads/$DEST" || fail "La branche $DEST existe déjà."
command -v python3 >/dev/null || fail 'Python3 manquant.'
git var GIT_AUTHOR_IDENT >/dev/null 2>&1 || fail 'Identité Git absente.'
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
python3 "$HERE/APPLIQUER_V6_1.py" "$(pwd)" "$TMP" || fail 'Base incompatible, aucun fichier source modifié.'
FILES=('BiluxWatch/WatchRootView.swift' 'BiluxWatch/WatchBridge.swift' 'BiluxIOS/WatchPhoneBridge.swift' 'BiluxWatch/Info.plist')
for file in "${FILES[@]}"; do [[ -s "$TMP/$file" ]] || fail "Fichier manquant: $file"; done
if command -v swiftc >/dev/null; then
  for f in "${FILES[@]}"; do
    if [[ "$f" == *.swift ]]; then swiftc -frontend -parse "$TMP/$f" || fail "Erreur de syntaxe : $f"; fi
  done
  echo '✅ Syntaxe Swift analysée (compilation Xcode sur Codemagic obligatoire).'
fi
python3 - "$TMP/BiluxWatch/Info.plist" <<'PY'
import sys,plistlib
p=plistlib.load(open(sys.argv[1],'rb'))
assert 'workout-processing' in p['WKBackgroundModes']
assert p['CFBundleVersion']=='19'
print('✅ watchOS workout-processing et Info.plist valides.')
PY
git switch -c "$DEST"
for f in "${FILES[@]}"; do cp "$TMP/$f" "$f"; done
git add -- "${FILES[@]}"
git diff --cached --check || fail 'Diff Git invalide.'
git commit -m 'BILUX V6.1 - Nuclear Live HealthKit watch workout tracking'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
  git push -u origin "$DEST" || fail 'Push interrompu : la branche locale reste disponible.'
else
  echo '🧪 Simulation : git push désactivé.'
fi
echo "✅ BILUX V6.1 intégrée : $DEST."
echo '➡️ Codemagic : vérifier iPhone ET Apple Watch avant toute publication.'
