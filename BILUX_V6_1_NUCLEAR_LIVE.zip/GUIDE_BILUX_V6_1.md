# BILUX V6.1 — NUCLEAR LIVE · Watch 3.1

**Base requise :** `bilux-v6.0-rebirth-watch3` (version 1.0, **build 19** iPhone et Apple Watch).

## Fonctionnalités

- Nouvelle **page NUCLEAR LIVE** sur Apple Watch, accessible depuis le cockpit et par défilement vertical.
- **Quatre activités** : Musculation, Marche, Cardio, Mobilité.
- Vraie `HKWorkoutSession` et `HKLiveWorkoutBuilder` : montre la fréquence cardiaque et les calories actives lorsqu'Apple Santé fournit les données.
- **Pause / Reprendre**, temps effectif hors pauses, Terminer et enregistrer, Annuler sans enregistrer.
- Après **enregistrement réussi** dans Apple Santé, transmet un résumé via WatchConnectivity vers le journal La Forge sur iPhone. Identifiant de séance = UUID du `HKWorkout` ; les retransmissions ne doivent pas créer de doublon dans BILUX.
- La **Forge manuelle** V6.0 reste intacte, séparée de Nuclear Live. Aucun bonus d'XP spécifique pour lancer le Live ; les règles existantes s'appliquent à l'entrée ajoutée au journal.
- Ajouter le mode watchOS `WKBackgroundModes = workout-processing`, et expliquer les autorisations de lecture/écriture HealthKit dans le fichier Info.plist de la montre.

## Avant l'installation

1. Depuis BILUX V6.0 sur iPhone, sauvegarder le **JSON** dans un dossier privé de l'app Fichiers. **Ne jamais l'envoyer sur GitHub.**
2. Dans GitHub, ouvrir le dépôt `bilelguilal-prog/Bilux-`, choisir la branche `bilux-v6.0-rebirth-watch3`.
3. `Add file → Upload files` : téléverser `BILUX_V6_1_NUCLEAR_LIVE.zip`, puis `Commit changes`.

## Installation Codespaces

Depuis la racine du dépôt, copier cette commande entière :

```bash
git switch bilux-v6.0-rebirth-watch3 && git pull --ff-only origin bilux-v6.0-rebirth-watch3 && unzip -o BILUX_V6_1_NUCLEAR_LIVE.zip -d /tmp/bilux-v61 && bash /tmp/bilux-v61/INSTALLER_V6_1.sh
```

Le script **prépare les quatre fichiers dans un dossier temporaire**, vérifie les marqueurs exacts de V6.0 et le build 19, analyse la syntaxe Swift si `swiftc` est disponible, puis crée la branche **`bilux-v6.1-nuclear-live`**. Aucune modification des fichiers applicatifs n'est faite avant cette vérification.

## Codemagic — vérifications obligatoires

Sur la branche **`bilux-v6.1-nuclear-live`**, lancer :

1. **BILUX — Vérifier le projet iOS (sans Apple Developer)**.
2. **BILUX V4.1 — Vérifier Apple Watch (sans signature)**.

Le résultat du test Watch est indispensable : c'est la première version BILUX qui utilise une vraie séance HealthKit et la permission d'écriture. La vérification syntaxique Linux ne valide pas les APIs Apple. Ne pas préparer le build 20 si l'un des deux workflows échoue.

## Build 20 / TestFlight

Une fois les **deux workflows verts**, dans le même Codespace :

```bash
bash /tmp/bilux-v61/PREPARER_BUILD_20.sh
```

Le script passe les bundles iPhone **et** Watch de 19 à 20 et pousse le commit, sans permettre de recommencer si le build est déjà 20. Puis Codemagic : workflow **BILUX — Publier sur TestFlight**, branche **`bilux-v6.1-nuclear-live`**, version attendue **1.0 (20)**. Installer depuis TestFlight sur iPhone et Apple Watch.

## Test sur une vraie Apple Watch

1. Ouvrir BILUX Watch → **NUCLEAR LIVE**, puis choisir une activité et appuyer **DÉMARRER LIVE**.
2. Lors de la première séance, accorder à BILUX Watch l'accès à la fréquence cardiaque, aux calories et **l'écriture des séances** dans Apple Santé. Les mesures peuvent apparaître après un délai, ou afficher « — » si non autorisées ou indisponibles.
3. Faire **au moins 1 minute effective** d'activité ; vérifier la fréquence cardiaque, les calories et le chronomètre. Tester Pause / Reprendre : la durée ne doit pas avancer pendant la pause.
4. Appuyer **TERMINER ET SAUVER** ; attendre le message confirmant la sauvegarde dans Apple Santé.
5. Sur l'iPhone, ouvrir **Apple Santé → Parcourir → Activité → Entraînements** : la séance est présente. Ouvrir BILUX → Sport → historique : **une seule séance** de la même activité et durée. Si l'iPhone est déconnecté, la Watch utilise la file de transfert WatchConnectivity ; rouvrir les deux apps et réessayer la synchronisation.
6. Vérifier que la **Forge manuelle** de V6.0 continue de fonctionner indépendamment et que les XP existants sont conservés.

**Attention :** ne pas lancer simultanément une séance « Exercice » d'Apple et Nuclear Live ; HealthKit ne prévoit pas deux sessions de sport concurrentes sur la même montre. Les données sont réelles et dépendent de la permission Apple Santé, elles ne sont pas simulées. La sauvegarde HealthKit et la connexion iPhone doivent être testées **sur la montre physique**.

## Limitations de cette première version

- Pas encore de carte GPS, de programmes fractionnés, de zones cardiaques ou de complication de cadran.
- Les sessions interrompues par un redémarrage complet de watchOS ne sont pas encore automatiquement restaurées ; commencer par des séances courtes de test.
- La Forge iPhone a une limite existante de 240 minutes par séance ; les séances Nuclear Live doivent respecter cette limite pour être consignées automatiquement.
- En cas d'échec pendant le test Watch, conserver V6.0 / build 19 comme version de secours et partager le **premier message `error:`** du journal Codemagic.
