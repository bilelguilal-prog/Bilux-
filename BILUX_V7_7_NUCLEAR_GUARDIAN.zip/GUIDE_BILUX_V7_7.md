# BILUX V7.7 — Nuclear Watch 5.1 × Nuclear Guardian
## Build 38 — base Recovery 37

### 0. Sécurité avant mise à jour
Depuis le build 37, conserver un nouvel export JSON du journal, le précédent, et les exports séparés Eternal Forge et traitement si utilisés. Conserver ces fichiers dans Fichiers privé ; **jamais dans GitHub**. Ne désinstaller ni l'app iPhone ni celle de la Watch. Ne pas restaurer pour tester.

### 1. Nouveau groupe d'applications Apple (obligatoire)
Les complications dynamiques nécessitent un conteneur partagé entre l'app watchOS et son extension WidgetKit. Il contient uniquement un résumé minimal, jamais le journal principal ni les historiques médicaux. Apple Developer : https://developer.apple.com/account/resources/identifiers/list

- Identifiers > bouton + > App Groups > Continue. Description : BILUX Watch Shared. Identifier exact : `group.com.bilux.nuclearascension.watchshared`. Register.
- Dans Identifiers, sélectionner App IDs puis ouvrir **com.bilux.nuclearascension.watchkitapp** (Watch). Cocher App Groups, Configure, sélectionner BILUX Watch Shared, Save. Conserver HealthKit et toutes les capacités existantes.
- Faire la même chose pour **com.bilux.nuclearascension.watchkitapp.nuclearlivewidget** (extension). Ne rien changer à l'identifiant iPhone com.bilux.nuclearascension.
- Apple peut invalider les profils précédemment générés pour ces deux identifiants. Ne révoquer aucun certificat, ne supprimer aucun App ID. Les anciens profils restent référencés par les anciennes branches ; si elles doivent être recompilées un jour, leurs profils peuvent nécessiter un renouvellement.

### 2. Deux profils, même certificat de distribution
https://developer.apple.com/account/resources/profiles/list

Créer ou régénérer deux profils de distribution de type App Store Connect (ou App Store suivant l'interface), un par App ID ci-dessus, avec le **même certificat Apple Distribution que le build 37**. Les noms Apple peuvent être BILUX-Watch-V77-AppStore et BILUX-Widget-V77-AppStore. Télécharger les deux fichiers .mobileprovision / .provisionprofile. Dans Codemagic, Team settings/Personal settings > codemagic.yaml settings > Code signing identities > iOS provisioning profiles, importer avec les nouvelles références exactes :

| Profil | Reference name Codemagic |
|---|---|
| Watch | `bilux_watch_v77_appstore` |
| Widget | `bilux_widget_v77_appstore` |

Ne pas modifier `BILUX-AppStore` ni la référence du certificat. Ne pas remplacer ou supprimer les anciens fichiers Codemagic ; le nouveau YAML référence uniquement les nouveaux profils Watch/Widget. Ne pas télécharger ces profils vers le dépôt. Le script de préflight vérifie le groupe et le type des profils installés sur le Mac de compilation, avant l'archivage. Les comptes Apple et Codemagic réels ne sont pas accessibles depuis cet environnement.

### 3. Installation dans GitHub / Codespaces
Sélectionner la branche `bilux-v7.6.1-nuclear-recovery` et téléverser uniquement `BILUX_V7_7_NUCLEAR_GUARDIAN.zip` à la racine du projet, commiter. Dans Codespaces :

```bash
git switch bilux-v7.6.1-nuclear-recovery && git pull --ff-only origin bilux-v7.6.1-nuclear-recovery && unzip -o BILUX_V7_7_NUCLEAR_GUARDIAN.zip -d /tmp/bilux-v77 && bash /tmp/bilux-v77/INSTALLER_V7_7.sh
```

Le script prépare directement le build 38, crée `bilux-v7.7-nuclear-guardian` et pousse la nouvelle branche. Il exige la présence des protections Recovery et refuse les sources incompatibles. Avant Codemagic, vérifier que les deux nouveaux profils sont disponibles et que les références correspondent à l'étape 2. Un seul workflow **BILUX — Publier sur TestFlight**, branche V7.7. Installer le build 38 par-dessus le build 37 et mettre à jour la Watch, sans désinstallation. Si une étape échoue, ne pas réinitialiser l'app : envoyer le log.

### 4. Vérification Guardian en premier
QG > Nuclear Guardian · Sauvegardes (aussi depuis les réglages d'Ascension si la section est reconnue). Vérifier niveau, XP, séances et date de dernière écriture. Créer une copie protégée ; sélectionner son aperçu, vérifier qu'il correspond au journal actuel, et l'exporter dans Fichiers privé. Comparer le journal après fermeture et réouverture. Le bouton « Ouvrir le mode récupération » crée d'abord une copie et bloque les écritures ; ne l'utiliser qu'en cas de besoin réel. Recovery exige ensuite une prévisualisation puis une confirmation avant restauration. Les sauvegardes locales contiennent les anciennes versions, pas des données déjà perdues avant Recovery. Le centre ne sauvegarde pas automatiquement les programmes, le traitement ni la configuration du cadran ; utiliser les exports séparés. Pas de rotation, d'effacement ou de transfert iCloud automatique. Les journaux techniques concernent les nouvelles mises en file et erreurs depuis V7.7 ; mise en file ne signifie pas réception sur la Watch.

### 5. Complications Watch
Ouvrir BILUX iPhone déverrouillé puis ouvrir/actualiser l'app Watch. Sur le cadran compatible : appui long > Modifier > Complications. Choisir BILUX XP, Quêtes, Gardien ou Confirmation. LIVE reste inchangée. Le Gardien affiche les jours restant pour vaincre le Gardien mensuel (12 jours), et non un nouveau système de PV. L'anneau représente la fraction restante. Les données RPG trop anciennes sont masquées (4 h ou changement de jour). La confirmation du traitement apparaît seulement pour le jour daté et un résumé récent (1 h), sans action de prise en attente et avec une confirmation concordante ; sinon « ? ». L'heure de génération du résumé est distincte de l'horodatage RPG. Le cadran ne permet pas de confirmer ou d'annuler directement ; toucher pour ouvrir l'application. Les complications peuvent montrer des résumés retardés par watchOS, même lors d'une correction. **Ne jamais se servir du cadran seul pour décider de prendre ou reprendre une dose** ; vérifier dans les applications, et en cas de doute demander l'avis d'un pharmacien ou médecin. Affichage marqué sensible ; choisir un autre raccourci si souhait de confidentialité.

### 6. Ce qui a été testé et ce qui reste à tester
Analyse syntaxique des ajouts Swift et installation Git sur une maquette composée de fragments des archives précédentes ; vérification des trois plists, entitlements et conservation du cœur de stockage Recovery. Les nouvelles fonctions Guardian ont été compilées et testées avec des modèles fictifs et un adaptateur de verrouillage sur Linux (copie octet pour octet, refus verrouillage/conflit, aperçu, fermeture de la porte d'écriture en récupération). Ce n'est pas une compilation Xcode ni un essai sur l'iPhone jumelé. Le dépôt distant exact, la protection de fichiers Apple réelle, les profils et l'actualisation WidgetKit restent à confirmer. Aucune donnée personnelle n'est incluse dans le ZIP. Le niveau et les XP ne sont ni recalculés par le widget ni écrits par lui. Le build 37 est la référence validée à conserver.

Documentation Apple : https://developer.apple.com/help/account/identifiers/enable-app-capabilities/ ; https://developer.apple.com/documentation/widgetkit/keeping-a-widget-up-to-date/ ; https://developer.apple.com/help/account/provisioning-profiles/edit-download-or-delete-profiles/ .
