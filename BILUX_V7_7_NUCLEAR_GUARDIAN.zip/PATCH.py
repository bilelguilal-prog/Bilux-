#!/usr/bin/env python3
from pathlib import Path
import sys, plistlib
root,stage=map(lambda p:Path(p).resolve(),sys.argv[1:]);here=Path(__file__).parent
GROUP='group.com.bilux.nuclearascension.watchshared'
files={}
def stop(msg): raise SystemExit('Base incompatible : '+msg+' ; aucun fichier du projet modifié.')
def read(p): return (root/p).read_text()
def load(p): return (here/p).read_text()
def once(s,a,b):
    if s.count(a)!=1: stop(repr(a[:160]))
    return s.replace(a,b,1)
def expect(s,*anchors):
    for a in anchors:
        if a not in s: stop(repr(a[:160]))
def output(p,s): files[p]=s.encode() if isinstance(s,str) else s
for p in ['BiluxIOS/Info.plist','BiluxWatch/Info.plist','BiluxWatchWidget/Info.plist']:
    obj=plistlib.loads((root/p).read_bytes())
    if str(obj['CFBundleVersion'])!='37': stop('build 37 requis : '+p)
    obj['CFBundleVersion']='38';output(p,plistlib.dumps(obj,sort_keys=False))
if not (root/'scripts/assign_widget_signing.py').is_file(): stop('signature WidgetKit Recovery absente')
p='BiluxIOS.xcodeproj/project.pbxproj';s=read(p)
if s.count('CURRENT_PROJECT_VERSION = 37;')!=2: stop('versions Xcode')
if s.count('INFOPLIST_FILE = BiluxWatchWidget/Info.plist;')!=2: stop('configurations widget')
if 'BiluxWatchWidget/BiluxWatchWidget.entitlements' in s: stop('entitlements widget déjà présents')
if s.count('CODE_SIGN_ENTITLEMENTS = BiluxWatch/BiluxWatch.entitlements;')!=2: stop('entitlements Watch inconnus')
s=s.replace('CURRENT_PROJECT_VERSION = 37;','CURRENT_PROJECT_VERSION = 38;')
s=s.replace('INFOPLIST_FILE = BiluxWatchWidget/Info.plist;', 'CODE_SIGN_ENTITLEMENTS = BiluxWatchWidget/BiluxWatchWidget.entitlements;\n        INFOPLIST_FILE = BiluxWatchWidget/Info.plist;')
output(p,s)
p='codemagic.yaml';s=read(p)
s=once(s,'- bilux_watch_appstore','- bilux_watch_v77_appstore')
s=once(s,'- bilux_widget_appstore','- bilux_widget_v77_appstore')
s=once(s,'python3 scripts/assign_widget_signing.py','python3 scripts/verify_v77_groups.py && python3 scripts/assign_widget_signing.py')
output(p,s)
if (root/'scripts/verify_v77_groups.py').exists(): stop('préflight déjà présent')
output('scripts/verify_v77_groups.py',load('VERIFY_GROUPS.py'))
p='BiluxWatch/BiluxWatch.entitlements';ent=plistlib.loads((root/p).read_bytes())
if ent.get('com.apple.developer.healthkit') is not True: stop('HealthKit Watch absent')
key='com.apple.security.application-groups';ent[key]=list(dict.fromkeys(ent.get(key,[])+[GROUP]));output(p,plistlib.dumps(ent,sort_keys=False))
p='BiluxWatchWidget/BiluxWatchWidget.entitlements'
if (root/p).exists(): stop('entitlements widget inattendus')
output(p,plistlib.dumps({key:[GROUP]}))
# All core persistence protections remain byte-for-byte unchanged; append separate helpers.
p='BiluxIOS/BiluxStore.swift';s=read(p)
expect(s,'private func persist(_ candidate: BiluxData) throws','guard previous == committedRaw','try previous.write(to: backupDirectory','var safeSnapshotData: BiluxData?','func recoveryRestore(','private let approvalKey = "bilux.v761.storage.approved"','@Published private(set) var recoveryReady = false')
output(p,s.rstrip()+load('GUARDIAN_STORE.swift.txt'))
p='BiluxIOS/BiluxApp.swift';s=read(p)
expect(s,'if journal.recoveryReady { MainTabs() }','else { V761RecoveryScreen() }','journal.reloadRecovery()','WatchPhoneBridge.shared.retryRecoveryWorkouts()')
s=once(s,'    @State private var chooseFile = false\n','    @State private var chooseFile = false\n    @State private var v77PreviewURL: URL?\n    @State private var v77PreviewText = ""\n    @State private var v77Confirm = false\n')
s=once(s,'Button("Restaurer : \\(file.lastPathComponent.prefix(20))") { journal.recoveryRestore(file) }','Button("Examiner : \\(file.lastPathComponent.prefix(20))") { v77Inspect(file) }')
s=once(s,'if case .success(let file) = result { journal.recoveryRestore(file) }','if case .success(let file) = result { v77Inspect(file) }')
s=once(s,'        .alert("Créer un journal neuf ?", isPresented: $newPrompt) {','''        .confirmationDialog("Restaurer la sauvegarde examinée ?", isPresented: $v77Confirm, titleVisibility: .visible) {
            Button("Restaurer et fusionner", role: .destructive) {
                if let file = v77PreviewURL { journal.recoveryRestore(file) }
                v77PreviewURL = nil
            }
            Button("Annuler", role: .cancel) { v77PreviewURL = nil }
        } message: { Text(v77PreviewText) }
        .alert("Créer un journal neuf ?", isPresented: $newPrompt) {''')
s=once(s,'                        Text(status).font(.caption)\n','                        Text(status).font(.caption)\n') # check existing
# Display preview errors outside the Health section too.
s=once(s,'                    Text(journal.recoveryStatus).font(.callout).foregroundStyle(.yellow)\n','                    Text(journal.recoveryStatus).font(.callout).foregroundStyle(.yellow)\n                    if !v77PreviewText.isEmpty { Text(v77PreviewText).font(.caption).foregroundStyle(.secondary) }\n')
s=once(s,'    private func findHealthWorkouts() async {','''    private func v77Inspect(_ file: URL) {
        v77PreviewURL = nil
        do {
            let preview = try journal.v77Preview(file)
            v77PreviewText = "Copie sélectionnée : " + preview.text + ". Les entrées locales non présentes dans cette copie seront fusionnées par UUID ; l’ancrage RPG provient de la copie choisie."
            v77PreviewURL = file
            v77Confirm = true
        } catch { v77PreviewText = "Copie illisible ou vide. Aucune restauration effectuée." }
    }
    private func findHealthWorkouts() async {''')
output(p,s.rstrip()+load('GUARDIAN_UI.swift.txt'))
p='BiluxIOS/BiluxScreens.swift';s=read(p)
expect(s,'private struct V76TreatmentCard: View','private struct V75WeeklyChroniclesView: View')
anchor='            V76TreatmentCard()\n            V73EternalForgeEntry()'
s=once(s,anchor,'''            NavigationLink {
                V77GuardianCenter().environmentObject(journal)
            } label: {
                Label("NUCLEAR GUARDIAN · SAUVEGARDES", systemImage: "shield.lefthalf.filled")
                    .font(.subheadline.weight(.heavy)).frame(maxWidth: .infinity, minHeight: 40)
            }.buttonStyle(.bordered).tint(Nuclear.gold)
            V76TreatmentCard()
            V73EternalForgeEntry()''')
# Settings section is retained from V6.7; add a second entry without changing the toggles.
settings='                        Toggle("Animations nucléaires", isOn: $effectsEnabled).tint(Nuclear.gold)'
if s.count(settings)==1:
    s=s.replace(settings, settings+'\n                        NavigationLink("Sauvegardes · Nuclear Guardian") { V77GuardianCenter().environmentObject(journal) }\n                            .tint(Nuclear.gold)',1)
output(p,s)
p='BiluxShared/WatchSnapshot.swift';s=read(p)
s=once(s,'    var treatmentRecords: [V76TreatmentRecord]? = nil\n','    var treatmentRecords: [V76TreatmentRecord]? = nil\n    // Horodatage indépendant : ne jamais avancer la date du résumé RPG.\n    var v77TreatmentSummaryAt: Date? = nil\n')
output(p,s)
p='BiluxIOS/WatchPhoneBridge.swift';s=read(p)
expect(s,'guard recoverySnapshotValid, journal?.safeSnapshotData != nil else { return nil }','guard let data = journal?.safeSnapshotData else','func retryRecoveryWorkouts()','v761WorkoutAck','journal.recoveryReady')
s=once(s,'        try? WCSession.default.updateApplicationContext(["biluxSnapshot": payload])','''        do {
            try WCSession.default.updateApplicationContext(["biluxSnapshot": payload])
            v77Log("Résumé RPG mis en file")
        } catch { v77Log("Échec de mise en file du résumé") }''')
s=once(s,'                        WCSession.default.transferUserInfo(["type": "v761WorkoutAck", "id": key])','''                        WCSession.default.transferUserInfo(["type": "v761WorkoutAck", "id": key])
                        v77Log("Séance stockée · acquittement mis en file")''')
s=once(s,'            // Le fichier précédemment écrit et/ou la file Watch restent disponibles pour un nouvel essai.','''            v77Log("Transfert séance en attente · erreur de stockage")
            // Le fichier précédemment écrit et/ou la file Watch restent disponibles pour un nouvel essai.''')
s=once(s,'            treatmentRecords = merged\n','            treatmentRecords = merged\n            v77Log("Confirmation quotidienne fusionnée")\n')
s=once(s,'        enriched.treatmentRecords = Array(treatmentRecords.prefix(366))\n','        enriched.treatmentRecords = Array(treatmentRecords.prefix(366))\n        enriched.v77TreatmentSummaryAt = Date()\n')
output(p,s.rstrip()+load('DIAGNOSTICS.swift.txt'))
p='BiluxWatch/WatchBridge.swift';s=read(p)
expect(s,'v761WorkoutAck','// V7.6.1 : garder la copie Watch','guard value.updatedAt >= snapshot.updatedAt else { return }','private let cacheKey = "bilux.watch.snapshot"')
s=once(s,'import WatchConnectivity\n','import WatchConnectivity\nimport WidgetKit\n')
s=once(s,'        treatmentRecords = local; pendingTreatment = pending\n','        treatmentRecords = local; pendingTreatment = pending\n        v77PublishFace()\n')
s=once(s,'        guard value.updatedAt >= snapshot.updatedAt else { return }\n        snapshot = value\n','''        guard value.updatedAt >= snapshot.updatedAt else { v77PublishFace(); return }
        snapshot = value
        v77PublishFace()
''')
s=once(s,'            snapshot = saved\n','            snapshot = saved\n            v77PublishFace()\n')
output(p,s.rstrip()+load('CACHE.swift.txt'))
p='BiluxWatch/WatchRootView.swift';s=read(p)
expect(s,'V76WatchForge().tag(7)','V61LiveWorkoutView().tag(5)','case "live": selectedPage = 5','V76WatchTreatment()')
s=once(s,'Text("WATCH 5.0")','Text("WATCH 5.1")')
output(p,s)
p='BiluxWatchWidget/NuclearLiveWidget.swift';s=read(p)
expect(s,'struct NuclearLiveWatchComplication: Widget','.widgetURL(URL(string: "biluxwatch://live"))','@main\nstruct BILUXWatchWidgetPack: WidgetBundle')
a=s.index('// MARK: - BILUX V6.9 / Watch 4.1')
s=s[:a].rstrip()+'\n\n'+load('WIDGET.swift.txt')
if s.count('@main')!=1: stop('WidgetBundle')
output(p,s)
for p,raw in files.items():
    f=stage/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw);print('Préparé :',p)
