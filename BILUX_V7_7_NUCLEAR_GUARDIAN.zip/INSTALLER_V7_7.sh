#!/usr/bin/env bash
set -euo pipefail
BASE=bilux-v7.6.1-nuclear-recovery
TARGET=bilux-v7.7-nuclear-guardian
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
[[ "$(git branch --show-current)" == "$BASE" ]] || { echo 'Branche Recovery build 37 requise'; exit 1; }
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || { echo 'Modifications suivies non validées ; arrêt.'; exit 1; }
! git show-ref --verify --quiet "refs/heads/$TARGET" || { echo 'Branche déjà présente ; arrêt.'; exit 1; }
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
python3 "$HERE/PATCH.py" "$(pwd)" "$TMP"
FILES=(codemagic.yaml scripts/verify_v77_groups.py BiluxShared/WatchSnapshot.swift BiluxIOS/BiluxStore.swift BiluxIOS/BiluxApp.swift BiluxIOS/BiluxScreens.swift BiluxIOS/WatchPhoneBridge.swift BiluxWatch/WatchBridge.swift BiluxWatch/WatchRootView.swift BiluxWatchWidget/NuclearLiveWidget.swift BiluxWatch/BiluxWatch.entitlements BiluxWatchWidget/BiluxWatchWidget.entitlements BiluxIOS/Info.plist BiluxWatch/Info.plist BiluxWatchWidget/Info.plist BiluxIOS.xcodeproj/project.pbxproj)
if command -v swiftc >/dev/null; then for rel in "${FILES[@]}"; do [[ "$rel" != *.swift ]] || swiftc -frontend -parse "$TMP/$rel"; done; fi
git switch -c "$TARGET"
for rel in "${FILES[@]}"; do cp "$TMP/$rel" "$rel"; done
git add -- "${FILES[@]}"
git diff --cached --check
git commit -m 'BILUX V7.7 Guardian + Watch read-only complication cache build 38'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != 1 ]]; then git push -u origin "$TARGET"; fi
printf '\nBuild 38 prêt. AVANT Codemagic : renouveler les deux profils Watch et Widget avec App Groups.\n'
