#!/usr/bin/env bash
set -euo pipefail
BASE='bilux-v6.2-nuclear-command'
NEW='bilux-v6.3-nuclear-mastery'
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail(){ echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Lance cette commande à la racine du dépôt BILUX.'
[[ "$(git branch --show-current)" == "$BASE" ]] || fail "Branche de départ requise : $BASE"
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Des modifications locales suivies sont présentes. Annulation.'
git diff --cached --quiet || fail 'Des modifications sont indexées.'
! git show-ref --quiet --verify "refs/heads/$NEW" || fail "La branche $NEW existe déjà."
git var GIT_AUTHOR_IDENT >/dev/null 2>&1 || fail 'Identité Git non configurée.'
command -v python3 >/dev/null 2>&1 || fail 'Python 3 absent.'
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
python3 "$HERE/APPLIQUER_V6_3.py" "$(pwd)" "$TMP" || fail 'Base incompatible ; aucun fichier source modifié.'
FILES=('BiluxIOS/Models.swift' 'BiluxIOS/BiluxScreens.swift')
for f in "${FILES[@]}"; do [[ -s "$TMP/$f" ]] || fail "Fichier manquant en staging: $f"; done
if command -v swiftc >/dev/null 2>&1; then
  swiftc -frontend -parse "$TMP/BiluxIOS/Models.swift" "$TMP/BiluxIOS/BiluxScreens.swift" || fail 'Syntaxe Swift invalide.'
  swiftc -typecheck "$TMP/BiluxIOS/Models.swift" || fail 'Types des modèles Swift invalides.'
  echo '✅ Syntaxe des écrans et types des modèles vérifiés. La compilation iOS doit encore être validée sur Codemagic.'
else
  echo 'ℹ️ Compilateur Swift absent dans Codespaces : vérifier sur Codemagic.'
fi
# Only after all preflight checks succeed is a new branch created.
git switch -c "$NEW"
for f in "${FILES[@]}"; do cp "$TMP/$f" "$f"; done
git add -- "${FILES[@]}"
git diff --cached --check || fail 'Diff Git invalide.'
git commit -m 'BILUX V6.3 - Nuclear Mastery interactive skill tree'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
  git push -u origin "$NEW" || fail "Push échoué : git push -u origin $NEW"
else
  echo '🧪 Simulation locale : push désactivé.'
fi
echo "✅ V6.3 installée sur $NEW. Tester iOS et Apple Watch avant le build 23."
