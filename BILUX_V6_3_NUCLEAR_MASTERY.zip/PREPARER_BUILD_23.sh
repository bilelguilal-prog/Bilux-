#!/usr/bin/env bash
set -euo pipefail
BRANCH='bilux-v6.3-nuclear-mastery'
fail(){ echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Place-toi à la racine de BILUX.'
[[ "$(git branch --show-current)" == "$BRANCH" ]] || fail "Branche $BRANCH attendue."
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications locales non commitées.'
git diff --cached --quiet || fail 'Index Git non vide.'
grep -q 'V63NuclearMasteryView' BiluxIOS/BiluxScreens.swift || fail 'Écran V6.3 absent.'
grep -q 'V63MasterySnapshot' BiluxIOS/Models.swift || fail 'Moteur V6.3 absent.'
TMP="$(mktemp -d)";trap 'rm -rf "$TMP"' EXIT
python3 - "$TMP" <<'PY'
from pathlib import Path
import plistlib,sys
root=Path.cwd(); stage=Path(sys.argv[1]); files=['BiluxIOS/Info.plist','BiluxWatch/Info.plist','BiluxWatchWidget/Info.plist']
for rel in files:
    try: obj=plistlib.loads((root/rel).read_bytes())
    except Exception as exc: raise SystemExit(f'❌ Plist invalide {rel}: {exc}')
    if str(obj.get('CFBundleVersion')) != '22':
        raise SystemExit(f'❌ Build 22 attendu dans {rel}, reçu {obj.get("CFBundleVersion")}. Aucun fichier modifié.')
    obj['CFBundleVersion']='23'
    output=stage/rel;output.parent.mkdir(parents=True,exist_ok=True)
    output.write_bytes(plistlib.dumps(obj,sort_keys=False))
project=root/'BiluxIOS.xcodeproj/project.pbxproj'
s=project.read_text(encoding='utf-8')
old='CURRENT_PROJECT_VERSION = 22;'
if s.count(old)!=2 or 'BiluxWatchWidget' not in s:
    raise SystemExit('❌ Versions de cible WidgetKit incorrectes. Aucun fichier modifié.')
p=stage/'BiluxIOS.xcodeproj/project.pbxproj';p.parent.mkdir(parents=True,exist_ok=True)
p.write_text(s.replace(old,'CURRENT_PROJECT_VERSION = 23;'),encoding='utf-8')
print('✅ iPhone + Watch + Widget configurés pour le build 23 en staging.')
PY
if command -v plutil >/dev/null 2>&1; then
  plutil -lint "$TMP/BiluxIOS.xcodeproj/project.pbxproj" || fail 'Projet Xcode invalide.'
fi
FILES=(BiluxIOS/Info.plist BiluxWatch/Info.plist BiluxWatchWidget/Info.plist BiluxIOS.xcodeproj/project.pbxproj)
for f in "${FILES[@]}"; do cp "$TMP/$f" "$f"; done
git add -- "${FILES[@]}"
git diff --cached --check || fail 'Diff invalide.'
git commit -m 'BILUX V6.3 - Build 23 iPhone Watch Widget'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
    git push origin "$BRANCH" || fail 'Commit local créé, relance git push.'
else
    echo '🧪 Simulation locale : push désactivé.'
fi
echo '✅ Build 23 prêt pour TestFlight, après double validation Codemagic.'
