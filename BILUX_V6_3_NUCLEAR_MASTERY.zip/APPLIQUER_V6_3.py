#!/usr/bin/env python3
"""Stage a strict V6.3 cosmetic mastery upgrade on V6.2 build 22."""
from pathlib import Path
import plistlib, sys

if len(sys.argv) != 3:
    sys.exit('Usage: APPLIQUER_V6_3.py RACINE_DEPOT REP_TEMPORAIRE')
repo, stage = (Path(x).resolve() for x in sys.argv[1:])
here = Path(__file__).resolve().parent

def abort(message):
    raise SystemExit('❌ ' + message + ' — aucun fichier de l’application modifié')

def require_one(text, before, after, label):
    count=text.count(before)
    if count != 1:
        abort(f'{label}: marqueur attendu 1 fois, trouvé {count}')
    return text.replace(before, after, 1)

# Confirm that all 3 bundles are on build 22, including WidgetKit.
for relative in ('BiluxIOS/Info.plist','BiluxWatch/Info.plist','BiluxWatchWidget/Info.plist'):
    try: value=plistlib.loads((repo/relative).read_bytes()).get('CFBundleVersion')
    except Exception as exc: abort(f'plist inaccessible {relative}: {exc}')
    if str(value) != '22': abort(f'{relative}: build 22 attendu, trouvé {value}')
if not (repo/'BiluxWatchWidget/NuclearLiveWidget.swift').is_file():
    abort('Extension WidgetKit non trouvée')
if not (repo/'scripts/assign_widget_signing.py').is_file():
    abort('Correctif de signature WidgetKit V6.1.3 manquant')

p = repo/'BiluxIOS/Models.swift'
if not p.is_file(): abort('BiluxIOS/Models.swift manquant')
models = p.read_text(encoding='utf-8')
if models.count('struct NuclearLiveReport: Codable, Equatable') != 1:
    abort('Modèle V6.2 NuclearLiveReport non reconnu')
if 'V63MasterySnapshot' in models: abort('Moteur V6.3 déjà présent')
new_models = models.rstrip() + '\n' + (here/'MAITRISE_ENGINE_V63.swift.txt').read_text(encoding='utf-8')

p = repo/'BiluxIOS/BiluxScreens.swift'
if not p.is_file(): abort('BiluxIOS/BiluxScreens.swift manquant')
screen = p.read_text(encoding='utf-8')
if screen.count('private struct V62NuclearDebrief: View') != 1:
    abort('Débrief V6.2 absent')
if 'V63NuclearMasteryView' in screen:
    abort('Vue de maîtrise déjà installée')
if screen.count('private struct BILUXV59LegacyProfile: View {') != 1 or screen.count('private var rebirthCharacterSheet: some View') != 1:
    abort('Écran Héritage/Rebirth absent ou ambigu')

screen = require_one(screen,
    '''private struct BILUXV59LegacyProfile: View {
    @EnvironmentObject private var journal: BiluxStore
    @Environment(\\.dismiss) private var dismiss
''',
    '''private struct BILUXV59LegacyProfile: View {
    @EnvironmentObject private var journal: BiluxStore
    @Environment(\\.dismiss) private var dismiss
''',
    'Reconnaissance écran profil')
# Keep the view hierarchy unchanged except for one visible entry into the mastery tree.
screen = require_one(screen,
    '''                    profileHeader
                    rebirthCharacterSheet
                    SectionCaption(title: "Titres de légende")''',
    '''                    profileHeader
                    rebirthCharacterSheet
                    masteryEntry
                    SectionCaption(title: "Titres de légende")''',
    'Entrée de maîtrise dans Héritage')

entry = '''    // V6.3 : entrée stable vers un arbre en lecture seule et calculé localement.
    private var masteryEntry: some View {
        NuclearCard {
            HStack(spacing: 10) {
                Image(systemName: "point.3.connected.trianglepath.dotted")
                    .font(.title2).foregroundStyle(Nuclear.purple)
                VStack(alignment: .leading, spacing: 4) {
                    Text("NUCLEAR MASTERY · V6.3")
                        .font(.caption.bold()).tracking(1).foregroundStyle(Nuclear.gold)
                    Text("4 caractéristiques · 12 capacités évolutives")
                        .font(.caption2).foregroundStyle(Nuclear.muted)
                }
            }
            NavigationLink {
                V63NuclearMasteryView().environmentObject(journal)
            } label: {
                Label("OUVRIR L'ARBRE DE MAÎTRISE", systemImage: "arrow.up.right.circle.fill")
                    .font(.subheadline.bold())
                    .frame(maxWidth: .infinity, minHeight: 50)
            }
            .buttonStyle(.borderedProminent)
            .tint(Nuclear.purple)
            .accessibilityIdentifier("bilux.v63.mastery.open")
        }
    }

'''
screen = require_one(screen, '    private var rebirthCharacterSheet: some View {',
    entry+'    private var rebirthCharacterSheet: some View {', 'Nouvelle carte Maîtrise')
screen = screen.rstrip()+'\n'+(here/'MAITRISE_ECRAN_V63.swift.txt').read_text(encoding='utf-8')

for relative,text in (('BiluxIOS/Models.swift',new_models),('BiluxIOS/BiluxScreens.swift',screen)):
    out=stage/relative
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(text,encoding='utf-8')
    print(f'✅ Préparé {relative} ({len(text.splitlines())} lignes)')
print('✅ V6.3 prête en zone temporaire — aucun changement d’XP, de Santé ni de Watch.')
