# ☢️ BILUX V6.3 — NUCLEAR MASTERY

**Base exigée** : `bilux-v6.2-nuclear-command`, build **22** sur iPhone, Apple Watch et WidgetKit.  
**Nouvelle branche** : `bilux-v6.3-nuclear-mastery`.  
**Prochain build TestFlight** : **23**, après validation iOS et Watch.

## Nouveautés

Dans **BILUX iPhone → Ascension → Profil RPG / Héritage**, ouvrir le nouvel encart **NUCLEAR MASTERY** puis toucher **OUVRIR L'ARBRE DE MAÎTRISE**.

- **4 caractéristiques RPG indicatives**, chacune notée /100 à partir du journal : Force = séances de musculation consignées ; Endurance = minutes consignées ; Régularité = semaines distinctes ayant une séance d'au moins 10 minutes ; Maîtrise = nombre d'exercices distincts consignés.
- **12 capacités symboliques** sur quatre voies, trois paliers chacune, avec des exigences progressives sur la durée.
- **Arbre interactif** : sélectionner une voie puis toucher chaque capacité, y compris verrouillée, pour lire sa condition et sa progression.
- **Quête adaptative** : le prochain palier de la voie sélectionnée est mis en avant automatiquement.
- **Aucune obligation de série quotidienne** : les semaines actives sont cumulatives, les jours de repos ne retirent aucun palier acquis.
- **Aucun bonus XP ni écriture supplémentaire** dans la sauvegarde. Les capacités reflètent le journal existant, ce ne sont pas des mesures de force physique ou de santé.

Les règles de progression 1–100 sur environ 6 à 12 mois restent les mêmes. Les profils, cinématiques, personnages, titres, auras, dossiers de combat, Nuclear Live, Apple Santé et la complication Watch restent inchangés.

## Installer depuis GitHub / Codespaces sur iPhone

1. Faire un **export JSON privé** dans l'app Fichiers. Ne jamais mettre ce JSON personnel sur GitHub.
2. Sur GitHub, sélectionner la branche `bilux-v6.2-nuclear-command` du dépôt BILUX.
3. `Add file → Upload files` : ajouter le ZIP `BILUX_V6_3_NUCLEAR_MASTERY.zip` et faire Commit sur cette branche.
4. Dans Codespaces, à la racine du dépôt, coller :

```bash
git switch bilux-v6.2-nuclear-command && git pull --ff-only origin bilux-v6.2-nuclear-command && unzip -o BILUX_V6_3_NUCLEAR_MASTERY.zip -d /tmp/bilux-v63 && bash /tmp/bilux-v63/INSTALLER_V6_3.sh
```

L'installateur s'arrête si le build 22, la fiche RPG ou le débrief V6.2 sont absents. Il prépare les fichiers en zone temporaire, puis crée et pousse `bilux-v6.3-nuclear-mastery`. Il ne modifie que `BiluxIOS/Models.swift` et `BiluxIOS/BiluxScreens.swift`.

## Vérifier les compilations Codemagic

Sur `bilux-v6.3-nuclear-mastery`, lancer les deux workflows habituels :

1. **BILUX — Vérifier le projet iOS** (sans signature).
2. **BILUX V4.1 — Vérifier Apple Watch** (sans signature).

La validation syntaxique Linux ne remplace pas une compilation Xcode. Si l'un des deux échoue, ne pas préparer le build 23 : récupérer la première ligne `error:` du journal et les lignes alentour.

## Préparer le build 23

**Uniquement après deux résultats verts**, dans Codespaces :

```bash
bash /tmp/bilux-v63/PREPARER_BUILD_23.sh
```

Ce script fait **22 → 23** dans les trois Info.plist et les deux configurations de build du widget. Une seconde exécution échoue volontairement. La configuration de signature existante dans `codemagic.yaml` et le script `scripts/assign_widget_signing.py` ne sont pas modifiés.

Lancer ensuite le workflow **BILUX — Publier sur TestFlight** sur `bilux-v6.3-nuclear-mastery` ; vérifier **version 1.0 (23)** et installer sur iPhone et Watch.

## Tests iPhone à réaliser après TestFlight

1. **Ascension → Profil RPG / Héritage** : la fiche Rebirth et les titres/aura existants s'affichent toujours.
2. Ouvrir **NUCLEAR MASTERY** : quatre caractéristiques et douze capacités doivent apparaître.
3. Toucher successivement **Force / Endurance / Régularité / Maîtrise**, puis toucher une capacité verrouillée et une débloquée : le détail s'ouvre au premier appui.
4. Vérifier la cohérence des nombres avec tes séances réelles (une séance de marche ajoute des minutes, mais pas une séance de Force).
5. Fermer puis rouvrir BILUX : les capacités se recalculent sans réinitialiser tes XP. Elles ne sont pas enregistrées comme nouvelle donnée.
6. Sur la Watch, démarrer une courte séance Nuclear Live et vérifier qu'elle apparaît **une seule fois** dans La Forge, puis consulter son débrief V6.2.
7. Vérifier que la complication ⚡ LIVE continue d'ouvrir Nuclear Live.

## Notes et limites

- Les scores **Force** et **Endurance** sont des **indices RPG du journal**, pas un test de puissance musculaire ou de forme cardiovasculaire.
- Les séances de musculation sont classées d'après leur libellé (*Musculation, Strength, Force, Poids*). D'autres activités peuvent ne pas compter dans cette catégorie, mais leurs minutes participent à l'Endurance.
- Les indicateurs sont historiques et cumulatifs, non des défis quotidiens. Les séances importées portant des durées incohérentes sont plafonnées à 24 h chacune **uniquement pour le calcul de la statistique Endurance**, pas pour les XP.
- Les capacités sont **cosmétiques** et s'obtiennent automatiquement, sans achat ni attribution manuelle d'XP.
- Aucun nouveau droit Santé/HealthKit requis.
- Retour arrière : conserver le build **22** de V6.2 tant que le build 23 n'est pas validé sur appareil.
