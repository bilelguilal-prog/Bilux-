# ☢️ BILUX V6.9 — NUCLEAR WATCH 4.1

**Base vérifiée par l'utilisateur :** V6.8 Nuclear Watch 4.0, **build 28** sur iPhone et Apple Watch.  
**Branche source :** `bilux-v6.8-nuclear-watch4`.  
**Nouvelle branche :** `bilux-v6.9-nuclear-watch41`.  
**Prochain TestFlight :** **build 29**, uniquement après les deux tests de compilation Codemagic verts.

## 1. Ce que V6.9 apporte

### Cockpit RPG
- Badge **WATCH 4.1**.
- Carte **Quêtes du jour** avec nombre de quêtes terminées et jauge ; accès direct aux missions.
- Réacteur RPG amélioré par deux petits arcs orbitaux lents. Aucun timer permanent n'est ajouté ; le réglage système **Réduire les animations** est respecté.
- Tous les modules Watch 4.0 restent disponibles, notamment **Maîtrises**, **Nuclear Live**, **Gardiens** et **Forge manuelle**.

### Missions sur la montre
- La page des quêtes montre les **états et récompenses issus du résumé synchronisé avec l'iPhone**.
- Pour une quête d'entraînement non terminée, un bouton ouvre **Nuclear Live** sans lancer automatiquement un exercice.
- Pour la nutrition et le ressenti, le journal reste sur l'iPhone : aucun bouton de complétion fictive.
- Un résumé non actualisé aujourd'hui est signalé. Bouton **Actualiser** pour demander la dernière synchronisation.

### Arène Watch améliorée
- Gardien du Réacteur : progression mensuelle sur **12 journées éligibles**.
- Souverain du Néant : progression trimestrielle sur **30 journées éligibles**.
- Affichage des jours, des PV restants, de la phase et de la victoire, calculés depuis les compteurs déjà synchronisés par V6.0.
- Aucun nouveau combat, aucune récompense manuelle, aucune duplication d'XP.

### Complications WidgetKit
La même extension `BiluxWatchWidget` propose désormais **trois complications à choisir sur le cadran Apple Watch** :

1. **BILUX · Nuclear Live** : raccourci inchangé vers la page 5.
2. **BILUX · XP / Profil** : raccourci vers le cockpit RPG (page 0).
3. **BILUX · Quêtes** : raccourci vers les missions (page 2).

Ces deux nouvelles complications sont **des raccourcis statiques**, pas des valeurs XP / quêtes mises à jour en direct sur le cadran. Une véritable complication de données synchronisées demanderait un partage interprocessus WidgetKit supplémentaire et éventuellement des autorisations de signature spécifiques. **Il ne s'agit pas d'un cadran Apple complet personnalisé : watchOS n'autorise pas à remplacer librement ses cadrans.**

**Inchangés** : `WatchSnapshot.swift`, `WatchPhoneBridge.swift`, HealthKit, Nuclear Live, la synchronisation des séances, les règles XP 1–100, le moteur des boss, le journal JSON et les profils Apple/Codemagic.

## 2. Sauvegarde avant installation

Dans BILUX sur l'iPhone, exporte une sauvegarde JSON privée dans Fichiers/iCloud. **Ne publie pas la sauvegarde sur GitHub**, car elle contient ton suivi personnel.

## 3. Ajouter le ZIP depuis l'iPhone

1. Ouvre : https://github.com/bilelguilal-prog/Bilux-
2. Sélectionne la branche **`bilux-v6.8-nuclear-watch4`**.
3. **Add file → Upload files** : ajoute `BILUX_V6_9_NUCLEAR_WATCH_41.zip` **à la racine du dépôt**.
4. Valide le commit.

## 4. Installer depuis GitHub Codespaces

Ouvre Codespaces, à la racine du dépôt, puis colle **en une fois** :

```bash
git switch bilux-v6.8-nuclear-watch4 && git pull --ff-only origin bilux-v6.8-nuclear-watch4 && unzip -o BILUX_V6_9_NUCLEAR_WATCH_41.zip -d /tmp/bilux-watch41 && bash /tmp/bilux-watch41/INSTALLER_WATCH41.sh
```

L'installateur prépare les modifications **hors du dépôt**, valide la syntaxe Swift si `swiftc` est installé, puis crée, valide et pousse la branche **`bilux-v6.9-nuclear-watch41`**. Les fichiers modifiés sont seulement :

- `BiluxWatch/WatchRootView.swift` ;
- `BiluxWatchWidget/NuclearLiveWidget.swift`.

Il vérifie la présence de la V6.8 et du build 28, et arrête l'installation si la base a divergé. **Ne force pas l'installation si elle échoue** : relève la première erreur.

## 5. Valider les compilations Codemagic

Sur `bilux-v6.9-nuclear-watch41`, lance successivement :

1. **BILUX — Vérifier le projet iOS** (sans signature) ;
2. **BILUX V4.1 — Vérifier Apple Watch** (sans signature).

Attends **les deux résultats verts**. `Queued` ou `Waiting` signifie que la machine n'a pas encore commencé la compilation ; ce n'est pas une erreur Swift.

La syntaxe Swift locale ne valide pas le typage ni les API watchOS/WidgetKit : **la compilation Xcode Codemagic est impérative avant TestFlight**.

## 6. Préparer et publier le build 29

De retour dans Codespaces, colle cette commande **qui fonctionne même si `/tmp` a été vidé** :

```bash
unzip -o BILUX_V6_9_NUCLEAR_WATCH_41.zip -d /tmp/bilux-watch41 && bash /tmp/bilux-watch41/PREPARER_BUILD_29.sh
```

Elle passe les trois `CFBundleVersion` (iPhone, Watch, Widget) **28 → 29** et les deux `CURRENT_PROJECT_VERSION` du projet Xcode **28 → 29**, puis crée un commit et le pousse. Elle **ne modifie pas les profils de signature Apple**.

Sur Codemagic, choisis :

- **Branche** : `bilux-v6.9-nuclear-watch41` ;
- **Workflow** : `BILUX — Publier sur TestFlight`.

Après publication Apple, installe la version **1.0 (29)** depuis TestFlight sur iPhone et vérifie la mise à jour de l'app Watch.

## 7. Vérifier Watch 4.1 sur la Series 10

1. **Accueil** : la montre affiche `WATCH 4.1`, le réacteur RPG et la carte **QUÊTES DU JOUR**, avec progression cohérente avec l'iPhone.
2. **Missions** : ouvre **VOIR LES MISSIONS** ; les trois quêtes sont visibles. Vérifie la distinction **accomplie / en cours**, sans ajout d'XP lors d'un simple affichage.
3. **Bouton Nuclear Live** d'une quête non finie : doit ouvrir la page Live, sans démarrer automatiquement la séance.
4. **Gardiens** : compare le Gardien et le Souverain à l'état de l'arène iPhone. Regarde si PV, phase et journée éligible sont cohérents.
5. **Maîtrises** : les quatre voies de la V6.8 sont toujours présentes, comme les XP et le rang.
6. **Complications** : depuis l'application Watch sur iPhone ou l'édition du cadran, sélectionne les raccourcis **BILUX · XP / Profil** et **BILUX · Quêtes**, puis vérifie les liens. **⚡ Nuclear Live** doit toujours fonctionner.
7. **Séance réelle facultative** : assure-toi que pause/reprise et envoi iPhone ne créent pas de doublon.
8. **Accessibilité** : active « Réduire les animations » ; les nouvelles orbites doivent devenir statiques.

Si une complication nouvellement installée n'apparaît pas immédiatement, vérifie que **l'app Watch et l'extension du build 29 sont effectivement installées**, puis rouvre l'éditeur du cadran.

## 8. Sécurité et limites des tests

- Les quêtes sont en **lecture seule** : les boutons de navigation ne valident aucune quête eux-mêmes.
- Pas de nouvelles permissions, d'App Group, ni de synchronisation HealthKit.
- Pas de mise à jour instantanée des valeurs XP/Quêtes dans les complications : la montre lit toujours les résumés via le mécanisme WatchConnectivity existant.
- Les quêtes et boss sont calculés sur l'iPhone ; un résumé ancien peut afficher des valeurs périmées tant que la synchronisation n'a pas eu lieu.
- Le **build 28** est conservé comme version de secours jusqu'à validation complète de la V6.9.

**Tests effectués dans l'environnement local** : simulation du dépôt, vérification des prérequis, génération de la branche, analyse de syntaxe Swift, unicité du `@main` WidgetKit, destinations des trois complications, préparation du build 29 iPhone+Watch+Widget, vérification d'un dépôt Git propre. **Non réalisés ici** : compilation Xcode sur macOS et test réel Apple Watch ; leur validation se fera sur Codemagic / TestFlight.
