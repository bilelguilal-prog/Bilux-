#!/usr/bin/env bash
set -euo pipefail
BRANCH='bilux-v6.9-nuclear-watch41'
fail() { echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Place-toi à la racine du dépôt BILUX.'
[[ "$(git branch --show-current)" == "$BRANCH" ]] || fail "Branche attendue : $BRANCH"
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Fichiers suivis modifiés ; sauvegarder avant cette étape.'
git diff --cached --quiet || fail 'Index Git non vide.'
grep -q 'V69WatchQuestsPage(selectedPage:' BiluxWatch/WatchRootView.swift || fail 'Quêtes Watch 4.1 absentes.'
grep -q 'V69WatchGuardiansPage(selectedPage:' BiluxWatch/WatchRootView.swift || fail 'Arène Watch 4.1 absente.'
grep -q 'V61LiveWorkoutView().tag(5)' BiluxWatch/WatchRootView.swift || fail 'Nuclear Live absent ; arrêt.'
grep -q 'BILUXWatchWidgetPack: WidgetBundle' BiluxWatchWidget/NuclearLiveWidget.swift || fail 'Nouvelles complications absentes.'
grep -q 'masteryPaths: masteryPaths' BiluxIOS/WatchPhoneBridge.swift || fail 'Sync maîtrises Watch 4.0 manquante.'
[[ -f scripts/assign_widget_signing.py ]] || fail 'Script de signature WidgetKit manquant.'
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
python3 - "$TMP" <<'PY'
from pathlib import Path
import plistlib,sys
root=Path.cwd();stage=Path(sys.argv[1])
for rel in ('BiluxIOS/Info.plist','BiluxWatch/Info.plist','BiluxWatchWidget/Info.plist'):
    try: p=plistlib.loads((root/rel).read_bytes())
    except Exception as exc: raise SystemExit(f'❌ Plist invalide : {rel}: {exc}')
    if str(p.get('CFBundleVersion'))!='28':
        raise SystemExit(f'❌ Build 28 attendu dans {rel} ; aucune modification.')
    p['CFBundleVersion']='29'
    target=stage/rel;target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(plistlib.dumps(p,sort_keys=False))
rel='BiluxIOS.xcodeproj/project.pbxproj'
s=(root/rel).read_text(encoding='utf-8')
if s.count('CURRENT_PROJECT_VERSION = 28;')!=2 or 'BiluxWatchWidget' not in s:
    raise SystemExit('❌ Paramètres Xcode inhabituels ; aucune modification.')
target=stage/rel;target.parent.mkdir(parents=True,exist_ok=True)
target.write_text(s.replace('CURRENT_PROJECT_VERSION = 28;','CURRENT_PROJECT_VERSION = 29;'),encoding='utf-8')
print('✅ Build 29 préparé : iPhone, Apple Watch, widget (certificats inchangés).')
PY
FILES=(BiluxIOS/Info.plist BiluxWatch/Info.plist BiluxWatchWidget/Info.plist BiluxIOS.xcodeproj/project.pbxproj)
for rel in "${FILES[@]}"; do cp "$TMP/$rel" "$rel"; done
git add -- "${FILES[@]}"
git diff --cached --check || fail 'Diff Git invalide.'
git commit -m 'BILUX V6.9 - Build 29 iPhone Watch WidgetKit'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
  git push origin "$BRANCH" || fail 'Commit local créé. Relancer seulement git push.'
else
  echo '🧪 Simulation : push désactivé.'
fi
echo '✅ Build 29 prêt sur GitHub. Publier via Codemagic TestFlight après les deux vérifications vertes.'
