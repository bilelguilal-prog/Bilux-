#!/usr/bin/env python3
"""BILUX V6.9 Nuclear Watch 4.1 / staged fail-closed upgrade on build 28.

Source of truth is the existing WatchSnapshot, including quests and boss counters.
No new permissions, WCSession payload, HealthKit calls or app groups.
"""
from pathlib import Path
import plistlib
import sys

if len(sys.argv) != 3:
    raise SystemExit('Usage: python3 APPLIQUER_WATCH41.py REPO STAGING')
root = Path(sys.argv[1]).resolve()
stage = Path(sys.argv[2]).resolve()
here = Path(__file__).resolve().parent

def stop(message):
    raise SystemExit('❌ ' + message + ' — fichiers du projet non modifiés.')

def read(relative):
    p = root / relative
    if not p.is_file():
        stop('Fichier absent : ' + relative)
    return p.read_text(encoding='utf-8')

def once(source, old, new, label):
    count = source.count(old)
    if count != 1:
        stop(f'Base V6.8 inattendue ({label}) : {count} correspondance(s), 1 attendue')
    return source.replace(old, new, 1)

def save(relative, source):
    p = stage / relative
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(source, encoding='utf-8')
    print(f'✅ Préparé : {relative} ({len(source.splitlines())} lignes)')

# Fail closed on the validated branch's build, including widget/profile.
for relative in ('BiluxIOS/Info.plist', 'BiluxWatch/Info.plist', 'BiluxWatchWidget/Info.plist'):
    try:
        version = str(plistlib.loads((root/relative).read_bytes())['CFBundleVersion'])
    except Exception:
        stop('Plist absent ou invalide : ' + relative)
    if version != '28':
        stop(f'Build 28 requis, mais {relative} affiche {version}')

if not (root/'scripts/assign_widget_signing.py').is_file():
    stop('Signature WidgetKit V6.1.3 absente')
bridge = read('BiluxShared/WatchSnapshot.swift')
for marker in ('struct WatchQuest:', 'var quests: [WatchQuest]', 'var monthlyWorkouts: Int?',
               'var quarterWorkouts: Int?', 'var masteryPaths: [WatchMasteryPath]?'):
    if marker not in bridge:
        stop('Résumé Watch incompatible : ' + marker)

s = read('BiluxWatch/WatchRootView.swift')
for marker in ('V68WatchDashboard(selectedPage: $selectedPage).tag(0)',
               'questPage.tag(2)', 'ascensionPage.tag(3)',
               'V61LiveWorkoutView().tag(5)', 'V68WatchMasteryPage().tag(6)',
               'private struct V68WatchDashboard: View',
               'private struct V68WatchMasteryPage: View',
               'V62CardiacZone',
               '            selectedPage = 5\n            bridge.refresh()'):
    if marker not in s:
        stop('Watch 4.0 non reconnue : ' + marker)
if 'V69WatchQuestsPage' in s or 'WATCH 4.1' in s:
    stop('L’interface Watch 4.1 est déjà installée')

s = once(s, '            questPage.tag(2)\n',
         '            V69WatchQuestsPage(selectedPage: $selectedPage).tag(2)\n',
         'page des quêtes')
s = once(s, '            ascensionPage.tag(3)\n',
         '            V69WatchGuardiansPage(selectedPage: $selectedPage).tag(3)\n',
         'page des Gardiens')

old_route = '''        .onOpenURL { url in
            guard url.scheme?.lowercased() == "biluxwatch",
                  url.host?.lowercased() == "live" else { return }
            selectedPage = 5
            bridge.refresh()
        }'''
new_route = '''        .onOpenURL { url in
            guard url.scheme?.lowercased() == "biluxwatch",
                  let destination = url.host?.lowercased() else { return }
            switch destination {
            case "live": selectedPage = 5 // Conserver le lien ⚡ LIVE V6.1.1.
            case "xp", "profile": selectedPage = 0
            case "quests": selectedPage = 2
            case "guardians": selectedPage = 3
            case "mastery": selectedPage = 6
            default: return
            }
            bridge.refresh()
        }'''
s = once(s, old_route, new_route, 'liens profonds complications')
s = once(s, 'Text("WATCH 4.0")', 'Text("WATCH 4.1")', 'identité Watch')
s = once(s, '            Circle()\n                .stroke(V54ReactorTheme.purple.opacity(0.35), lineWidth: 1)\n                .padding(11)\n            Image(systemName: "atom")', '            Circle()\n                .stroke(V54ReactorTheme.purple.opacity(0.35), lineWidth: 1)\n                .padding(11)\n            // Watch 4.1 : deux impulsions orbitales lentes, sans timer ni calcul continu.\n            Circle()\n                .trim(from: 0.04, to: 0.19)\n                .stroke(V54ReactorTheme.gold.opacity(0.8),\n                        style: StrokeStyle(lineWidth: 2.5, lineCap: .round))\n                .rotationEffect(.degrees(awakened && !reduceMotion ? 300 : 0))\n                .animation(reduceMotion ? nil : .linear(duration: 9).repeatForever(autoreverses: false),\n                           value: awakened)\n                .padding(5)\n            Circle()\n                .trim(from: 0.51, to: 0.58)\n                .stroke(V54ReactorTheme.purple.opacity(0.8),\n                        style: StrokeStyle(lineWidth: 1.8, lineCap: .round))\n                .rotationEffect(.degrees(awakened && !reduceMotion ? -270 : 0))\n                .animation(reduceMotion ? nil : .linear(duration: 11).repeatForever(autoreverses: false),\n                           value: awakened)\n                .padding(5)\n            Image(systemName: "atom")', 'orbites subtiles du réacteur')

anchor = '''                Button {
                    selectedPage = 5 // Identifiant historique : complication ⚡ LIVE.
                } label: {'''
mission_preview = '''                // Quêtes uniquement depuis le résumé Watch envoyé par l'iPhone.
                V54ReactorCard(accent: V54ReactorTheme.purple) {
                    HStack(spacing: 4) {
                        Label("QUÊTES DU JOUR", systemImage: "checkmark.seal.fill")
                            .font(.system(size: 10, weight: .heavy))
                            .foregroundStyle(V54ReactorTheme.paleGold)
                        Spacer(minLength: 2)
                        Text("\\(bridge.snapshot.quests.filter { $0.completed }.count)/\\(bridge.snapshot.quests.count)")
                            .font(.system(size: 12, weight: .black, design: .rounded))
                            .foregroundStyle(V54ReactorTheme.gold)
                    }
                    ProgressView(value: Double(bridge.snapshot.quests.filter { $0.completed }.count),
                                 total: Double(max(1, bridge.snapshot.quests.count)))
                        .tint(V54ReactorTheme.purple)
                    Button { selectedPage = 2 } label: {
                        Label("VOIR LES MISSIONS", systemImage: "arrow.up.right")
                            .font(.system(size: 10, weight: .heavy))
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)
                    .tint(V54ReactorTheme.purple)
                }

'''
s = once(s, anchor, mission_preview + anchor, 'raccourci missions cockpit')

extra = (here/'WATCH41_UI.swift.txt').read_text(encoding='utf-8').rstrip()
for symbol in ('private struct V69WatchQuestsPage: View',
               'private struct V69WatchGuardiansPage: View'):
    if symbol not in extra:
        stop('Module SwiftUI incomplet : ' + symbol)
s = s.rstrip() + '\n\n' + extra + '\n'
save('BiluxWatch/WatchRootView.swift', s)

widget = read('BiluxWatchWidget/NuclearLiveWidget.swift')
for marker in ('@main\nstruct NuclearLiveWatchComplication: Widget',
               '.widgetURL(URL(string: "biluxwatch://live"))',
               'private struct NuclearLiveProvider: TimelineProvider',
               'private enum LiveWidgetTheme'):
    if marker not in widget:
        stop('WidgetKit V6.1.1 inattendu : ' + marker)
if 'BILUXWatchWidgetPack' in widget:
    stop('WidgetKit Watch 4.1 déjà installé')
widget = once(widget, '@main\nstruct NuclearLiveWatchComplication: Widget',
              'struct NuclearLiveWatchComplication: Widget', 'bundle WidgetKit unique')
widgets = (here/'WATCH41_WIDGETS.swift.txt').read_text(encoding='utf-8').rstrip()
if '@main\nstruct BILUXWatchWidgetPack: WidgetBundle' not in widgets:
    stop('Déclaration @main du WidgetBundle absente')
widget = widget.rstrip() + '\n' + widgets + '\n'
if widget.count('@main') != 1:
    stop('Nombre de points d’entrée WidgetKit inattendu')
save('BiluxWatchWidget/NuclearLiveWidget.swift', widget)

print('✅ V6.9 préparée : Watch 4.1, missions, Gardiens et raccourcis XP/Quêtes/Live.')
print('✅ Journal, XP, HealthKit, WatchConnectivity, WidgetKit signing et données non modifiés.')
