#!/usr/bin/env bash
set -euo pipefail
BASE='bilux-v6.8-nuclear-watch4'
BRANCH='bilux-v6.9-nuclear-watch41'
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail() { echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Place-toi à la racine du dépôt BILUX.'
[[ "$(git branch --show-current)" == "$BASE" ]] || fail "Branche attendue : $BASE"
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Des fichiers suivis sont modifiés ; les sauvegarder avant installation.'
git diff --cached --quiet || fail 'Index Git non vide.'
! git show-ref --quiet --verify "refs/heads/$BRANCH" || fail "Branche $BRANCH déjà existante. Ne réinstalle pas par-dessus."
command -v python3 >/dev/null || fail 'Python 3 absent.'
git var GIT_AUTHOR_IDENT >/dev/null 2>&1 || fail 'Identité Git non configurée.'
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
python3 "$HERE/APPLIQUER_WATCH41.py" "$(pwd)" "$TMP" || fail 'Base incompatible ; aucun fichier source modifié.'
FILES=(BiluxWatch/WatchRootView.swift BiluxWatchWidget/NuclearLiveWidget.swift)
for rel in "${FILES[@]}"; do [[ -s "$TMP/$rel" ]] || fail "Fichier de sortie absent : $rel"; done
if command -v swiftc >/dev/null 2>&1; then
  swiftc -frontend -parse "${FILES[@]/#/$TMP/}" || fail 'Syntaxe Swift invalide. Aucun fichier original modifié.'
  echo '✅ Vérification syntaxique Swift réussie (le build Xcode reste obligatoire).'
else
  echo 'ℹ️ swiftc indisponible : vérification complète nécessaire sur Codemagic.'
fi
git switch -c "$BRANCH"
for rel in "${FILES[@]}"; do cp "$TMP/$rel" "$rel"; done
git add -- "${FILES[@]}"
git diff --cached --check || fail 'Diff Git invalide.'
git commit -m 'BILUX V6.9 - Nuclear Watch 4.1 missions bosses complications'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
  git push -u origin "$BRANCH" || fail "Commit local créé. Réessaie seulement : git push -u origin $BRANCH"
else
  echo '🧪 Simulation : push désactivé.'
fi
echo '✅ Watch 4.1 installée. Tester iOS puis Watch dans Codemagic AVANT build 29.'
