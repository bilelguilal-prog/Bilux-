#!/usr/bin/env bash
set -euo pipefail
[[ "$(git branch --show-current)" == 'bilux-v5.6-arene-des-gardiens' ]] || { echo '❌ Branche V5.6 attendue.'; exit 1; }
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || { echo '❌ Modifications locales suivies : commit ou sauvegarde d abord.'; exit 1; }
python3 - <<'PY'
from pathlib import Path
import plistlib
files=[Path('BiluxIOS/Info.plist'),Path('BiluxWatch/Info.plist')]
for f in files:
    if not f.is_file(): raise SystemExit(f'❌ {f} introuvable')
    with f.open('rb') as h: plist=plistlib.load(h)
    if str(plist.get('CFBundleVersion'))!='11':
        raise SystemExit(f'❌ {f} : build 11 attendu, trouvé {plist.get("CFBundleVersion")}. Rien modifié.')
for f in files:
    with f.open('rb') as h: plist=plistlib.load(h)
    plist['CFBundleVersion']='12'
    with f.open('wb') as h: plistlib.dump(plist,h,fmt=plistlib.FMT_XML,sort_keys=False)
    print(f'✅ {f} : build 11 → 12')
PY
git add -- BiluxIOS/Info.plist BiluxWatch/Info.plist
git diff --cached --check
git commit -m 'BILUX V5.6 - TestFlight build 12'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
  git push -u origin bilux-v5.6-arene-des-gardiens
else
  echo '🧪 Simulation : aucun push.'
fi
echo '✅ Build 12 prêt. Lancer le workflow TestFlight dans Codemagic.'
