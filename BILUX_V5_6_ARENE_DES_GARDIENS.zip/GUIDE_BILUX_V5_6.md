# ☢️ BILUX V5.6 — L'ARÈNE DES GARDIENS

**Base exacte :** `bilux-v5.5-long-ascension` — build 11.  
**Branche créée :** `bilux-v5.6-arene-des-gardiens`.  
**Prochain TestFlight :** build 12, *après* deux tests Codemagic verts.

## Ce que V5.6 ajoute

- **Une arène accessible dans Ascension**, sans supprimer les quêtes hebdomadaires, les cinq rangs, les avatars ou l'arbre de maîtrise.
- Deux combats visuels : **Le Gardien du Réacteur** (12 journées de séance sur le mois civil, +140 XP) et **Le Souverain du Néant** (30 journées de séance sur le trimestre civil, +180 XP).
- Un écran détaillé par boss : emblème nucléaire animé (sans déformer l'avatar), jauge des points de vie restants, quatre phases, scène de victoire et description de l'épreuve.
- **Pas de boutons de dégâts ou de récompenses** : la vie des boss et les XP sont déduits des séances déjà enregistrées dans BILUX. Impossible de gagner deux fois des XP en ouvrant l'arène.
- **Alignement du compteur** : seules les journées éligibles comptent, comme dans le moteur V5.5 (une par jour, séance ≥10 minutes, au plus cinq jours par semaine). Cela évite l'affichage d'une victoire sans le bonus associé.
- Réglage existant **Animations nucléaires** et option iOS « Réduire les animations » respectés.

Les XP de base et la courbe 1–100, les rangs, la migration JSON, les données médicales et le code Watch ne sont **pas modifiés**. La Watch continue d'utiliser la connexion à l'iPhone existante. Le correctif HealthKit V5.5.1, que tu avais choisi de ne pas installer, n'est pas inclus.

## 0. Sauvegarde JSON

Depuis BILUX, dans **Ascension**, exporte ton fichier de sauvegarde JSON et garde-le dans Fichiers/iCloud privé. Ne le publie pas sur GitHub : il contient des informations personnelles.

## 1. GitHub sur iPhone

1. Ouvre `https://github.com/bilelguilal-prog/Bilux-`.
2. Sélectionne `bilux-v5.5-long-ascension` (ta V5.5 actuelle).
3. `Add file` → `Upload files` → ajoute `BILUX_V5_6_ARENE_DES_GARDIENS.zip`.
4. Valide le commit.

## 2. Codespaces

Dans le terminal à la racine de BILUX, copie cette **seule ligne** :

```bash
git switch bilux-v5.5-long-ascension && git pull --ff-only origin bilux-v5.5-long-ascension && unzip -o BILUX_V5_6_ARENE_DES_GARDIENS.zip -d /tmp/bilux-v56 && bash /tmp/bilux-v56/INSTALLER_V5_6.sh
```

Le script vérifie la branche, le contenu des fichiers, la compatibilité des blocs d'origine et la syntaxe Swift si disponible **avant toute modification**. En cas d'incompatibilité, il stoppe la procédure sans créer la branche. Si tout passe, il crée et pousse `bilux-v5.6-arene-des-gardiens`.

## 3. Deux compilations Codemagic

Sur `bilux-v5.6-arene-des-gardiens`, exécute dans cet ordre :

1. **BILUX — Vérifier le projet iOS (sans Apple Developer)**.
2. **BILUX V4.1 — Vérifier Apple Watch (sans signature)**.

**N'exécute pas la commande build 12 avant que les deux tests soient verts.** L'analyse syntaxique locale ne remplace pas la compilation iOS/watchOS Xcode.

## 4. Préparer le build 12

Après les deux tests verts, dans Codespaces :

```bash
bash /tmp/bilux-v56/PREPARER_BUILD_12.sh
```

Le script vérifie que les deux `Info.plist` sont au build **11** ; si oui, il fait passer l'iPhone et la Watch au build **12**, commit et push. Il refuse un deuxième passage ou une version différente.

## 5. TestFlight

Dans Codemagic : workflow **BILUX — Publier sur TestFlight**, branche **`bilux-v5.6-arene-des-gardiens`**. Après traitement Apple, attends la disponibilité de **1.0 (12)** dans App Store Connect/TestFlight puis installe la nouvelle version.

### Vérifications dans l'application

1. Tes XP, séances et transformations sont identiques après mise à jour.
2. **Ascension → Arène des gardiens** : touche chaque boss ; l'écran de combat doit s'ouvrir et se fermer.
3. La jauge progresse automatiquement depuis les journées de séance éligibles ; 6 séances le même jour ne comptent qu'une journée.
4. Le bouton d'arène **ne doit jamais** attribuer de nouveaux XP.
5. Watch 2.0 enregistre toujours une séance vers l'iPhone.
6. Animations désactivées ou « Réduire les animations » : l'écran reste lisible et stable.

## Tests effectués sur copie locale

- Installation V5.6 sur copie reconstruite des fichiers V5.5, création de branche et commit simulé sans push.
- Parsing Swift des cinq sources iPhone/Watch concernés.
- Tests Swift Foundation : plafond cinq journées/semaine, boss mensuel à 12 journées, doublons du même jour, exclusion des séances de moins de 10 min, sérialisation JSON et conservation de l'ancre XP.
- Préparation du build 12 sur les deux plist, vérification qu'une nouvelle exécution est rejetée.
- Simulation d'un fichier incompatible : arrêt avant modification du code ou de la branche.

**Non testé localement :** compilation réelle avec le SDK SwiftUI/Xcode, rendu sur l'iPhone, exécution Watch/TestFlight. Ces validations se font dans Codemagic et sur tes appareils.
