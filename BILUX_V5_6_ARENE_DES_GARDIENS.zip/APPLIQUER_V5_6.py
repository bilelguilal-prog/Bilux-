#!/usr/bin/env python3
"""V5.6: verify the *installed* V5.5 anchors, stage changes, then atomically install via shell."""
from pathlib import Path
import sys

if len(sys.argv)!=3:
    raise SystemExit('Usage: APPLIQUER_V5_6.py <repo> <stage>')
root=Path(sys.argv[1]).resolve()
stage=Path(sys.argv[2]).resolve()
here=Path(__file__).resolve().parent

def replace_once(s, old, new, file):
    n=s.count(old)
    if n!=1: raise ValueError(f'{file}: ancre attendue non reconnue ({n}) : {old[:85]!r}')
    return s.replace(old,new,1)

try:
    files=['BiluxIOS/Models.swift','BiluxIOS/BiluxScreens.swift']
    originals={f:(root/f).read_text(encoding='utf-8') for f in files}
    if not all('BILUX V5.5' in originals[f] for f in files):
        raise ValueError('Base V5.5 attendue, n installe pas sur V5.4 ou V5.5.1.')
    if any('BILUX V5.6' in s for s in originals.values()):
        raise ValueError('V5.6 déjà installée.')
    models=originals['BiluxIOS/Models.swift']
    old='''        let workouts = qualifyingWorkoutDays(data, since: since, now: now)
        let meals = journalDays(data, since: since, now: now, meals: true)
        let checkins = journalDays(data, since: since, now: now, meals: false)
        let today = cal.startOfDay(for: now)'''
    new='''        // V5.6 : le tableau de quêtes suit les MÊMES journées plafonnées
        // que earnedXP. Une 6e journée ne peut pas afficher une victoire
        // si elle n'a pas généré les XP de boss.
        let workouts = Set(limitedByWeek(qualifyingWorkoutDays(data, since: since, now: now), maxDays: 5, calendar: cal))
        let meals = Set(limitedByWeek(journalDays(data, since: since, now: now, meals: true), maxDays: 5, calendar: cal))
        let checkins = Set(limitedByWeek(journalDays(data, since: since, now: now, meals: false), maxDays: 5, calendar: cal))
        let today = cal.startOfDay(for: now)'''
    models=replace_once(models,old,new,'Models.swift')

    screens=originals['BiluxIOS/BiluxScreens.swift']
    marker='''            SectionCaption(title: "Boss mensuel")\n'''
    start=screens.find(marker)
    if start<0 or screens.count(marker)!=1: raise ValueError('Section Boss mensuel absente ou répétée.')
    end_marker='''            if journal.heroLevel >= 100 {'''
    end=screens.find(end_marker,start)
    if end<0 or screens.count(end_marker)!=1: raise ValueError('Fin des sections de boss introuvable.')
    old_boss=screens[start:end]
    for fingerprint in ['"LE GARDIEN DU RÉACTEUR"','"LE SOUVERAIN DU NÉANT"','ProgressView(value: Double(min(quests.quarterWorkouts, 30)) / 30.0)']:
        if fingerprint not in old_boss: raise ValueError(f'Ancien bloc de boss non conforme: {fingerprint}')
    screens=screens[:start]+'            BILUXV56BossArena()\n'+screens[end:]
    screens=screens.rstrip()+'\n'+(here/'ARENE_V56.swift.txt').read_text(encoding='utf-8')
    outputs={'BiluxIOS/Models.swift':models,'BiluxIOS/BiluxScreens.swift':screens}
    for f,s in outputs.items():
        if any(conflict in s for conflict in ('<<<<<<< ','=======\n>>>>>>>','>>>>>>> ')):
            raise ValueError('Marqueur conflit détecté.')
        dest=stage/f
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_text(s,encoding='utf-8')
        print(f'✅ {f} ({len(s.splitlines())} lignes), original préservé')
    print('✅ BILUX V5.6 préparée en zone temporaire, aucun code original modifié.')
except (OSError, ValueError) as exc:
    print(f'❌ ARRÊT AVANT MODIFICATION : {exc}', file=sys.stderr)
    sys.exit(1)
