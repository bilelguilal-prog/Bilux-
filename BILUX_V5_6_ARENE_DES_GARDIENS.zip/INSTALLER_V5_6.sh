#!/usr/bin/env bash
set -euo pipefail
BASE='bilux-v5.5-long-ascension'
DEST='bilux-v5.6-arene-des-gardiens'
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail(){ echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Exécute le script à la racine du dépôt.'
[[ "$(git branch --show-current)" == "$BASE" ]] || fail "Branche attendue : $BASE"
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Fichiers suivis modifiés : sauvegarde ou commit avant installation.'
! git show-ref --verify --quiet "refs/heads/$DEST" || fail "La branche $DEST existe déjà."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
python3 "$HERE/APPLIQUER_V5_6.py" "$(pwd)" "$TMP/stage" || fail 'La base réelle est incompatible : aucun fichier modifié.'
FILES=(BiluxIOS/Models.swift BiluxIOS/BiluxScreens.swift)
if command -v swiftc >/dev/null 2>&1; then
  swiftc -frontend -parse "${FILES[@]/#/$TMP/stage/}" || fail 'Erreur de syntaxe Swift : aucune modification.'
  echo '✅ Analyse syntaxique Swift passée (compilation SwiftUI à valider sur Codemagic).'
else
  echo 'ℹ️ swiftc indisponible : compilation SwiftUI à faire sur Codemagic.'
fi
git switch -c "$DEST"
for f in "${FILES[@]}"; do cp "$TMP/stage/$f" "$f"; done
git add -- "${FILES[@]}"
git diff --cached --check || fail 'Contrôle du diff non passé : ne pas publier.'
git commit -m 'BILUX V5.6 - arena boss battles and XP-aligned progress'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
  git push -u origin "$DEST" || fail "Push échoué : exécute git push -u origin $DEST"
else
  echo '🧪 Simulation : aucune publication GitHub.'
fi
echo "✅ BILUX V5.6 intégrée sur $DEST"
echo '➡️ Lance les deux tests Codemagic avant de préparer le build 12.'
