#!/usr/bin/env bash
set -euo pipefail
BRANCH='bilux-v5.8.2-dossiers-combat'
fail(){ echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Lance depuis la racine du dépôt.'
[[ "$(git branch --show-current)" == "$BRANCH" ]] || fail "Branche $BRANCH attendue."
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications locales détectées.'
git diff --cached --quiet || fail 'Modifications indexées détectées.'
grep -q 'V5.8.2 : navigation directe par NavigationLink' BiluxIOS/BiluxScreens.swift || fail 'Patch V5.8.2 absent.'
python3 - <<'PYCODE'
from pathlib import Path
import plistlib
names=('BiluxIOS/Info.plist','BiluxWatch/Info.plist')
original={}
for name in names:
    raw=Path(name).read_bytes()
    pl=plistlib.loads(raw)
    if str(pl.get('CFBundleVersion'))!='15':
        raise SystemExit(f'❌ {name}: build 15 requis, obtenu {pl.get("CFBundleVersion")!r}. Aucun fichier modifié.')
    original[name]=pl
for name,pl in original.items():
    pl['CFBundleVersion']='16'
    Path(name).write_bytes(plistlib.dumps(pl,fmt=plistlib.FMT_XML,sort_keys=False))
    print(f'✅ {name}: build 15 → 16')
PYCODE
git add -- BiluxIOS/Info.plist BiluxWatch/Info.plist
git diff --cached --check || fail 'Diff invalide.'
git commit -m 'BILUX V5.8.2 - TestFlight build 16'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != 1 ]]; then
  git push -u origin "$BRANCH" || fail "Push échoué : lance git push -u origin $BRANCH"
else
  echo '🧪 Test local : push désactivé.'
fi
echo '✅ Build 16 préparé. Publier ensuite via le workflow TestFlight.'
