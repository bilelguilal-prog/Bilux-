# BILUX V5.8.2 — Dossiers de combat

Correctif de navigation Codex. Les boutons des **deux** boss passent de `.sheet(item:)` à `NavigationLink(value:)` et ouvrent une destination dans la pile de navigation du Codex. Permet de revenir au Codex avec « Retour ». Les écrans de combat, récompenses, nombres de jours et données personnelles restent inchangés.

## Étapes depuis iPhone
1. Sauvegarder le JSON BILUX en lieu privé.
2. Sur GitHub, branche `bilux-v5.8.1-codex-navigation`, téléverser le ZIP à la racine puis Commit.
3. Codespaces, depuis la racine :

```bash
git switch bilux-v5.8.1-codex-navigation && git pull --ff-only origin bilux-v5.8.1-codex-navigation && unzip -o BILUX_V5_8_2_DOSSIERS_COMBAT_FIX.zip -d /tmp/bilux-v582 && bash /tmp/bilux-v582/INSTALLER_V5_8_2.sh
```

4. Codemagic, branche `bilux-v5.8.2-dossiers-combat`: lancer vérification iOS puis Watch sans signature.
5. **Seulement si les deux sont vertes** :

```bash
bash /tmp/bilux-v582/PREPARER_BUILD_16.sh
```

6. Codemagic publier TestFlight → App Store Connect build 16.
7. Tester `Codex > Bestiaire > Gardien`, revenir puis `Souverain`, sans appuis multiples.

**Limitations :** tests locaux d'installation et syntaxe Swift, mais pas de compilation iOS/watchOS sur Linux, ni test de l'écran tactile iPhone. Le correctif change la navigation des deux dossiers, ce qui devrait résoudre le blocage lié à la présentation modale imbriquée, sans garantie avant TestFlight.
