#!/usr/bin/env bash
set -euo pipefail
BASE='bilux-v5.8.1-codex-navigation'
DEST='bilux-v5.8.2-dossiers-combat'
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail(){ echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Lance depuis la racine du dépôt BILUX.'
[[ "$(git branch --show-current)" == "$BASE" ]] || fail "Branche attendue : $BASE."
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications locales détectées : annulation.'
git diff --cached --quiet || fail 'Modifications indexées détectées.'
! git show-ref --quiet --verify "refs/heads/$DEST" || fail "La branche $DEST existe déjà."
[[ -f "$HERE/PATCHER_V5_8_2.py" ]] || fail 'ZIP incomplet.'
TEMP="$(mktemp -d)"; trap 'rm -rf "$TEMP"' EXIT
python3 "$HERE/PATCHER_V5_8_2.py" "$(pwd)" "$TEMP/staged" || fail 'Base incompatible — aucun fichier modifié.'
if command -v swiftc >/dev/null 2>&1; then
  swiftc -frontend -parse "$TEMP/staged/BiluxIOS/BiluxScreens.swift" || fail 'La syntaxe Swift a échoué : aucun fichier modifié.'
  echo '✅ Syntaxe Swift validée (compilation réelle à faire dans Codemagic).'
else
  echo 'ℹ️ swiftc absent : compilation réelle à vérifier dans Codemagic.'
fi
git switch -c "$DEST"
cp "$TEMP/staged/BiluxIOS/BiluxScreens.swift" BiluxIOS/BiluxScreens.swift
git add -- BiluxIOS/BiluxScreens.swift
git diff --cached --check || fail 'Contrôle Git échoué.'
git commit -m 'BILUX V5.8.2 - Reliable Codex combat dossier navigation'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != 1 ]]; then
  git push -u origin "$DEST" || fail "Push échoué : lance git push -u origin $DEST"
else
  echo '🧪 Test local : push désactivé.'
fi
echo "✅ Correctif V5.8.2 envoyé sur $DEST — deux vérifications Codemagic avant build 16."
