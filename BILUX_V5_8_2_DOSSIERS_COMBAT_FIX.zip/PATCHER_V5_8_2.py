#!/usr/bin/env python3
# BILUX V5.8.2 — reliable Codex dossier navigation patch
from pathlib import Path
import plistlib, sys
if len(sys.argv) != 3:
    raise SystemExit('Usage: PATCHER_V5_8_2.py <repo_root> <staging_dir>')
repo=Path(sys.argv[1]).resolve(); stage=Path(sys.argv[2]).resolve()
def stop(msg):
    print('❌ '+msg+' — aucun fichier du projet modifié.',file=sys.stderr)
    raise SystemExit(1)
for name in ('BiluxIOS/Info.plist','BiluxWatch/Info.plist'):
    try:
        data=plistlib.loads((repo/name).read_bytes())
    except Exception as exc: stop(f'Impossible de lire {name}: {exc}')
    if str(data.get('CFBundleVersion'))!='15': stop(f'Build 15 attendu : {name} contient {data.get("CFBundleVersion")}')
source=repo/'BiluxIOS/BiluxScreens.swift'
try: text=source.read_text(encoding='utf-8')
except Exception as exc: stop(str(exc))
marker='private struct BILUXV58Codex: View {'
if text.count(marker)!=1: stop('Codex V5.8.1 absent/ambigu')
prefix,codex=text.split(marker,1)
if 'V5.8.1 : aucun ScrollView horizontal' not in codex: stop('Navigation V5.8.1 absente')
if 'V5.8.2 : navigation directe par NavigationLink' in codex: stop('Patch V5.8.2 déjà installé')
changes=[
(
'''    @State private var selectedBoss: BILUXV56Boss?
    @State private var cinematicStage: NuclearStage?''',
'''    @State private var cinematicStage: NuclearStage?'''
),
(
'''            .navigationTitle("Codex")
            .navigationBarTitleDisplayMode(.inline)''',
'''            // V5.8.2 : navigation native dans le Codex, sans seconde sheet imbriquée.
            // Les deux dossiers (Gardien et Souverain) utilisent le même chemin.
            .navigationDestination(for: BILUXV56Boss.self) { boss in
                BILUXV56BossBattle(boss: boss).environmentObject(journal)
            }
            .navigationTitle("Codex")
            .navigationBarTitleDisplayMode(.inline)'''
),
(
'''        .sheet(item: $selectedBoss) { boss in
            NavigationStack {
                BILUXV56BossBattle(boss: boss)
                    .environmentObject(journal)
                    .toolbar {
                        ToolbarItem(placement: .topBarTrailing) {
                            Button("Fermer") { selectedBoss = nil }
                        }
                    }
            }
            .presentationDragIndicator(.visible)
        }
        .fullScreenCover(item: $cinematicStage)''',
'''        .fullScreenCover(item: $cinematicStage)'''
),
(
'''                    Button {
                        selectedBoss = boss
                    } label: {
                        Label("VOIR LE DOSSIER DE COMBAT", systemImage: "shield.lefthalf.filled")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent).tint(boss.accent)''',
'''                    // V5.8.2 : une destination native par boss, plus de sheet à déclencher.
                    NavigationLink(value: boss) {
                        Label("VOIR LE DOSSIER DE COMBAT", systemImage: "shield.lefthalf.filled")
                            .font(.subheadline.bold())
                            .frame(maxWidth: .infinity, minHeight: 50)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(boss.accent)
                    .accessibilityIdentifier("bilux.codex.dossier.\\(boss.id)")'''
)
]
for i,(before,after) in enumerate(changes,1):
    n=codex.count(before)
    if n!=1: stop(f'Ancre {i} attendue une fois, trouvée {n}')
    codex=codex.replace(before,after,1)
# no other Codex session sheet remains, no reference to previous state
if 'selectedBoss' in codex: stop('Référence selectedBoss non remplacée dans Codex')
if codex.count('NavigationLink(value: boss)')!=1: stop('NavigationLink absent ou multiple')
if codex.count('navigationDestination(for: BILUXV56Boss.self)')!=1: stop('destination manquante ou ambiguë')
if codex.count('V5.8.2 : navigation directe par NavigationLink') != 1:
    # invisible marker for installer identity
    codex=codex.replace('    private var bestiary: some View {','    // V5.8.2 : navigation directe par NavigationLink pour les deux dossiers.\n    private var bestiary: some View {',1)
modified=prefix+marker+codex
if any(x in modified for x in ('<<<<<<< ', '>>>>>>> ')): stop('Marqueurs de conflit')
out=stage/'BiluxIOS/BiluxScreens.swift'; out.parent.mkdir(parents=True,exist_ok=True)
out.write_text(modified,encoding='utf-8')
print('✅ Codex V5.8.1 (build 15) reconnu et patch 5.8.2 préparé en zone temporaire.')
print('✅ Deux NavigationLink natifs vers les dossiers, feuille modale imbriquée supprimée.')
print('✅ Aucun autre fichier modifié ; XP, Santé, Watch, séances intacts.')
