#!/usr/bin/env python3
"""BILUX V6.1.1: stage a true watchOS WidgetKit extension and a deep link, fail closed."""
from pathlib import Path
import hashlib
import plistlib
import re
import shutil
import sys

if len(sys.argv) != 3:
    raise SystemExit('Usage: APPLIQUER_V6_1_1.py <root_repo> <staging_dir>')
repo, stage = (Path(arg).resolve() for arg in sys.argv[1:])
here = Path(__file__).resolve().parent

def stop(message):
    raise SystemExit('❌ ' + message + ' — aucun fichier du projet modifié.')

def get(relative):
    p = repo / relative
    if not p.is_file():
        stop(f'Fichier manquant : {relative}')
    return p.read_text(encoding='utf-8')

def once(text, before, after, label):
    n = text.count(before)
    if n != 1:
        stop(f'Base inattendue ({label}) : {n} ancres trouvées, 1 attendue')
    return text.replace(before, after, 1)

def stage_text(rel, content):
    path = stage / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding='utf-8')

def section(text, title, lines):
    marker = f'/* End {title} section */'
    return once(text, marker, lines + '\n' + marker, f'section Xcode {title}')

def ident(s):
    return hashlib.sha1(('BILUX-V611:' + s).encode('utf8')).hexdigest()[:24].upper()

if (repo / 'BiluxWatchWidget').exists():
    stop('Une extension WidgetKit existe déjà. Installation manuelle requise')
for rel in ('BiluxIOS/Info.plist', 'BiluxWatch/Info.plist'):
    p = plistlib.loads((repo / rel).read_bytes())
    if str(p.get('CFBundleVersion')) != '20':
        stop(f'Build 20 requis dans {rel}, reçu {p.get("CFBundleVersion")}')

watch = get('BiluxWatch/WatchRootView.swift')
if 'V61LiveWorkoutView().tag(5)' not in watch or 'REBIRTH · WATCH 3.0' not in watch:
    stop('La base Watch 3.1 / Nuclear Live n’est pas reconnue')
if '.onOpenURL' in watch[watch.index('struct WatchRootView: View'):watch.index('    private var commandPage:', watch.index('struct WatchRootView: View'))]:
    stop('Le routage URL est déjà présent')
watch = once(watch,
    '''        .tint(V54ReactorTheme.gold)
        .task { bridge.refresh() }
    }

    private var commandPage: some View {''',
    '''        .tint(V54ReactorTheme.gold)
        .task { bridge.refresh() }
        // V6.1.1 : un appui sur le widget ouvre la page, sans lancer HKWorkoutSession.
        .onOpenURL { url in
            guard url.scheme?.lowercased() == "biluxwatch",
                  url.host?.lowercased() == "live" else { return }
            selectedPage = 5
            bridge.refresh()
        }
    }

    private var commandPage: some View {''',
    'ouverture Nuclear Live depuis une complication')
stage_text('BiluxWatch/WatchRootView.swift', watch)

watchplist = plistlib.loads((repo / 'BiluxWatch/Info.plist').read_bytes())
if watchplist.get('CFBundleURLTypes'):
    stop('Des URL schemes existent déjà sur la Watch, vérifier avant de fusionner')
watchplist['CFBundleURLTypes'] = [{
    'CFBundleURLName': 'com.bilux.nuclearascension.watchkitapp.nuclearlive',
    'CFBundleURLSchemes': ['biluxwatch']
}]
watchpath = stage / 'BiluxWatch/Info.plist'
watchpath.parent.mkdir(exist_ok=True, parents=True)
watchpath.write_bytes(plistlib.dumps(watchplist, sort_keys=False))

widgetfile = here/'NuclearLiveWidget.swift'
plistfile = here/'Info_Widget.plist'
if not widgetfile.is_file() or not plistfile.is_file():
    stop('Sources du widget absentes dans le ZIP')
widget = widgetfile.read_text(encoding='utf-8')
if 'widgetURL(URL(string: "biluxwatch://live"))' not in widget:
    stop('URL du widget incohérente')
widgetplist = plistlib.loads(plistfile.read_bytes())
if widgetplist.get('NSExtension', {}).get('NSExtensionPointIdentifier') != 'com.apple.widgetkit-extension':
    stop('Info.plist WidgetKit invalide')
(stage / 'BiluxWatchWidget').mkdir(parents=True, exist_ok=True)
shutil.copy2(widgetfile, stage / 'BiluxWatchWidget/NuclearLiveWidget.swift')
shutil.copy2(plistfile, stage / 'BiluxWatchWidget/Info.plist')

pbx = get('BiluxIOS.xcodeproj/project.pbxproj')
if 'BiluxWatchWidget' in pbx:
    stop('Un widget est déjà enregistré dans le projet Xcode')
I = {n: ident(n) for n in [
    'file.swift','file.plist','file.appex','build.swift','build.appex',
    'group','target','srcphase','frameworkphase','embedphase',
    'proxy','dependency','config.debug','config.release','configlist']}

pbx = section(pbx, 'PBXBuildFile', f'''\t\t{I['build.swift']} /* NuclearLiveWidget.swift in Sources */ = {{isa = PBXBuildFile; fileRef = {I['file.swift']} /* NuclearLiveWidget.swift */; }};
\t\t{I['build.appex']} /* BiluxWatchWidget.appex in Embed App Extensions */ = {{isa = PBXBuildFile; fileRef = {I['file.appex']} /* BiluxWatchWidget.appex */; settings = {{ATTRIBUTES = (CodeSignOnCopy, RemoveHeadersOnCopy, ); }}; }};''')

pbx = section(pbx, 'PBXContainerItemProxy', f'''\t\t{I['proxy']} /* Widget proxy */ = {{isa = PBXContainerItemProxy; containerPortal = 439A1489934641902C60A204; proxyType = 1; remoteGlobalIDString = {I['target']}; remoteInfo = BiluxWatchWidget; }};''')

pbx = section(pbx, 'PBXCopyFilesBuildPhase', f'''\t\t{I['embedphase']} /* Embed App Extensions */ = {{isa = PBXCopyFilesBuildPhase; buildActionMask = 2147483647; dstPath = ""; dstSubfolderSpec = 13; files = ({I['build.appex']} /* BiluxWatchWidget.appex */); name = "Embed App Extensions"; runOnlyForDeploymentPostprocessing = 0; }};''')

pbx = section(pbx, 'PBXFileReference', f'''\t\t{I['file.swift']} /* NuclearLiveWidget.swift */ = {{isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = NuclearLiveWidget.swift; sourceTree = "<group>"; }};
\t\t{I['file.plist']} /* Widget Info.plist */ = {{isa = PBXFileReference; lastKnownFileType = text.plist.xml; path = Info.plist; sourceTree = "<group>"; }};
\t\t{I['file.appex']} /* BiluxWatchWidget.appex */ = {{isa = PBXFileReference; explicitFileType = "wrapper.app-extension"; includeInIndex = 0; path = BiluxWatchWidget.appex; sourceTree = BUILT_PRODUCTS_DIR; }};''')

pbx = section(pbx, 'PBXFrameworksBuildPhase', f'''\t\t{I['frameworkphase']} /* Widget Frameworks */ = {{isa = PBXFrameworksBuildPhase; buildActionMask = 2147483647; files = (); runOnlyForDeploymentPostprocessing = 0; }};''')

pbx = section(pbx, 'PBXGroup', f'''\t\t{I['group']} /* BiluxWatchWidget */ = {{isa = PBXGroup; children = ({I['file.swift']} /* NuclearLiveWidget.swift */, {I['file.plist']} /* Info.plist */); path = BiluxWatchWidget; sourceTree = "<group>"; }};''')

pbx = once(pbx,
    '48494DDE09B6C9886443EFC0 /* BiluxShared */, 811A418E8A3EB06D20C111F0 /* Products */',
    f'48494DDE09B6C9886443EFC0 /* BiluxShared */, {I["group"]} /* BiluxWatchWidget */, 811A418E8A3EB06D20C111F0 /* Products */',
    'groupe racine projet')
pbx = once(pbx,
    '22F007B4F85553DFA1C3C42D /* BiluxWatch.app */); name = Products;',
    f'22F007B4F85553DFA1C3C42D /* BiluxWatch.app */, {I["file.appex"]} /* BiluxWatchWidget.appex */); name = Products;',
    'liste des produits')

pbx = section(pbx, 'PBXNativeTarget', f'''\t\t{I['target']} /* BiluxWatchWidget */ = {{isa = PBXNativeTarget; buildConfigurationList = {I['configlist']} /* Widget config list */; buildPhases = ({I['srcphase']} /* Sources */, {I['frameworkphase']} /* Frameworks */); buildRules = (); dependencies = (); name = BiluxWatchWidget; productName = BiluxWatchWidget; productReference = {I['file.appex']} /* BiluxWatchWidget.appex */; productType = "com.apple.product-type.app-extension"; }};''')

pbx = once(pbx,
    'buildPhases = (F3770905F93BD3B934392118 /* Sources */, 7BE01B7E031C4F038B4EEBCA /* Frameworks */, C3BC442ECB1E3A6F3E0EFA11 /* Resources */);',
    f'buildPhases = (F3770905F93BD3B934392118 /* Sources */, 7BE01B7E031C4F038B4EEBCA /* Frameworks */, C3BC442ECB1E3A6F3E0EFA11 /* Resources */, {I["embedphase"]} /* Embed App Extensions */);',
    'intégration de l’extension dans BiluxWatch')
pbx = once(pbx,
    'buildRules = (); dependencies = (); name = BiluxWatch; productName = BiluxWatch;',
    f'buildRules = (); dependencies = ({I["dependency"]} /* Widget dependency */, ); name = BiluxWatch; productName = BiluxWatch;',
    'dépendance du widget pour la montre')

pbx = once(pbx,
    '03E38C1235F9DA9063F4015E = {CreatedOnToolsVersion = 16.0; }; };',
    f'03E38C1235F9DA9063F4015E = {{CreatedOnToolsVersion = 16.0; }}; {I["target"]} = {{CreatedOnToolsVersion = 16.0; }}; }};',
    'TargetAttributes Xcode')
pbx = once(pbx,
    '03E38C1235F9DA9063F4015E /* BiluxWatch */); };',
    f'03E38C1235F9DA9063F4015E /* BiluxWatch */, {I["target"]} /* BiluxWatchWidget */); }};',
    'targets du projet')

pbx = section(pbx, 'PBXSourcesBuildPhase', f'''\t\t{I['srcphase']} /* Widget Sources */ = {{isa = PBXSourcesBuildPhase; buildActionMask = 2147483647; files = ({I['build.swift']} /* NuclearLiveWidget.swift */); runOnlyForDeploymentPostprocessing = 0; }};''')

pbx = section(pbx, 'PBXTargetDependency', f'''\t\t{I['dependency']} /* Widget dependency */ = {{isa = PBXTargetDependency; target = {I['target']} /* BiluxWatchWidget */; targetProxy = {I['proxy']} /* Widget proxy */; }};''')

configs = []
for label, key, release in [('Debug','config.debug',False),('Release','config.release',True)]:
    configs.append(f'''\t\t{I[key]} /* {label} Widget */ = {{isa = XCBuildConfiguration; buildSettings = {{
        APPLICATION_EXTENSION_API_ONLY = YES;
        CODE_SIGN_STYLE = Automatic;
        CURRENT_PROJECT_VERSION = 20;
        GENERATE_INFOPLIST_FILE = NO;
        INFOPLIST_FILE = BiluxWatchWidget/Info.plist;
        MARKETING_VERSION = 1.0;
        PRODUCT_BUNDLE_IDENTIFIER = com.bilux.nuclearascension.watchkitapp.nuclearlivewidget;
        PRODUCT_NAME = "$(TARGET_NAME)";
        SDKROOT = watchos;
        SKIP_INSTALL = YES;
        SUPPORTED_PLATFORMS = "watchos watchsimulator";
        SWIFT_VERSION = 5.0;
        TARGETED_DEVICE_FAMILY = 4;
        WATCHOS_DEPLOYMENT_TARGET = 11.0;
{'' if release else '        SWIFT_ACTIVE_COMPILATION_CONDITIONS = DEBUG;'+chr(10)}    }}; name = {label}; }};''')
pbx = section(pbx, 'XCBuildConfiguration', '\n'.join(configs))

pbx = section(pbx, 'XCConfigurationList', f'''\t\t{I['configlist']} /* Widget config list */ = {{isa = XCConfigurationList; buildConfigurations = ({I['config.debug']} /* Debug Widget */, {I['config.release']} /* Release Widget */); defaultConfigurationIsVisible = 0; defaultConfigurationName = Release; }};''')

# There is no extra iOS-side entitlement: this widget shows static launch content only.
if len(set(I.values())) != len(I):
    stop('Collision inattendue dans les identifiants du projet Xcode')
if pbx.count('/* BiluxWatchWidget */') < 3:
    stop('La cible WidgetKit semble incomplète')
stage_text('BiluxIOS.xcodeproj/project.pbxproj', pbx)

print('✅ BILUX V6.1 / build 20 reconnu. Extension WidgetKit et deep link préparés.')
print('✅ 5 fichiers préparés dans la zone de staging, aucune donnée BILUX modifiée.')
