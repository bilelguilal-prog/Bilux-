#!/usr/bin/env bash
set -euo pipefail
BRANCH='bilux-v6.1.1-watch-widget'
fail(){ printf '❌ %s\n' "$*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Place-toi à la racine de BILUX.'
[[ "$(git branch --show-current)" == "$BRANCH" ]] || fail "Branche attendue : $BRANCH"
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications suivies non commitées.'
git diff --cached --quiet || fail 'Index Git non vide.'
TEMP="$(mktemp -d)"
trap 'rm -rf "$TEMP"' EXIT
python3 - "$TEMP" <<'PY'
from pathlib import Path
import plistlib, sys
root=Path.cwd(); stage=Path(sys.argv[1]);
plist_files=['BiluxIOS/Info.plist','BiluxWatch/Info.plist','BiluxWatchWidget/Info.plist']
for rel in plist_files:
    p=root/rel
    d=plistlib.loads(p.read_bytes())
    if str(d.get('CFBundleVersion'))!='20':
        raise SystemExit(f'❌ Build 20 requis dans {rel} : reçu {d.get("CFBundleVersion")}')
    d['CFBundleVersion']='21'
    target=stage/rel; target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(plistlib.dumps(d, sort_keys=False))
project=root/'BiluxIOS.xcodeproj/project.pbxproj'
s=project.read_text(encoding='utf-8')
old='CURRENT_PROJECT_VERSION = 20;'
if s.count(old)!=2 or 'BiluxWatchWidget' not in s:
    raise SystemExit('❌ Configuration du widget inattendue. Ne pas modifier le projet.')
s=s.replace(old,'CURRENT_PROJECT_VERSION = 21;')
p=stage/'BiluxIOS.xcodeproj/project.pbxproj';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8')
print('✅ Trois bundles (iPhone, Watch et Widget) prêts pour le build 21.')
PY
if command -v plutil >/dev/null 2>&1; then
  plutil -lint "$TEMP/BiluxIOS.xcodeproj/project.pbxproj" || fail 'Projet Xcode invalide.'
fi
FILES=(BiluxIOS/Info.plist BiluxWatch/Info.plist BiluxWatchWidget/Info.plist BiluxIOS.xcodeproj/project.pbxproj)
for file in "${FILES[@]}"; do cp "$TEMP/$file" "$file"; done
git add -- "${FILES[@]}"
git diff --cached --check || fail 'Diff invalide.'
git commit -m 'BILUX V6.1.1 - Build 21 iPhone Watch and Widget'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
  git push origin "$BRANCH" || fail 'Commit local fait, push échoué. Relance git push.'
else
  echo '🧪 Test local : push désactivé.'
fi
printf '\n✅ Build 21 préparé : iPhone, Apple Watch et widget.\n'
