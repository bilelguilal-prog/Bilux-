# ☢️ BILUX V6.1.1 — NUCLEAR LIVE WIDGET (Apple Watch)

## Ce que fait ce widget

La **complication BILUX · Nuclear Live** permet d’ouvrir directement la page Nuclear Live depuis un cadran Apple Watch ou un widget de la pile intelligente (*Smart Stack*). Trois présentations WidgetKit :

- **Circulaire** : ⚡ + LIVE.
- **Rectangulaire** : BILUX · NUCLEAR LIVE · Ouvrir la séance.
- **En ligne** : ⚡ BILUX Live.

**Important :** toucher le widget **ouvre la page Nuclear Live**, mais **ne démarre pas l'enregistrement HealthKit**. Le démarrage reste une action volontaire dans BILUX Watch. Le widget n’affiche pas le pouls en direct ; pour les BPM et les calories en temps réel, ouvrir l’application. Les mises à jour des complications sont gérées par watchOS, pas continuellement.

La V6.1, le journal, les XP, les titres et les séances enregistrées restent inchangés.

## Préparatifs (depuis l’iPhone)

1. Conserver une sauvegarde JSON BILUX dans Fichiers, **jamais sur GitHub**.
2. Dans GitHub `bilelguilal-prog/Bilux-`, sélectionner la branche stable `bilux-v6.1-nuclear-live` (build **20**).
3. **Add file → Upload files** : ajouter `BILUX_V6_1_1_NUCLEAR_LIVE_WIDGET.zip` puis valider **Commit changes**.

## Installation Codespaces

Depuis la racine du projet :

```bash
git switch bilux-v6.1-nuclear-live && git pull --ff-only origin bilux-v6.1-nuclear-live && unzip -o BILUX_V6_1_1_NUCLEAR_LIVE_WIDGET.zip -d /tmp/bilux-v611 && bash /tmp/bilux-v611/INSTALLER_V6_1_1.sh
```

Le script valide la base **build 20**, prépare les changements dans un répertoire temporaire, vérifie la syntaxe Swift (lorsque `swiftc` est présent), crée la branche **`bilux-v6.1.1-watch-widget`** et la pousse sur GitHub. Il s’arrête si une extension WidgetKit existe déjà ou si le projet diverge.

## Codemagic — vérifications (OBLIGATOIRES)

Sur `bilux-v6.1.1-watch-widget`, lancer :

1. **BILUX — Vérifier le projet iOS (sans Apple Developer)**.
2. **BILUX V4.1 — Vérifier Apple Watch (sans signature)**.

Cette version ajoute une **troisième cible Xcode** : `BiluxWatchWidget`, incorporée dans `BiluxWatch.app`. La compilation Watch est indispensable ; le contrôle syntaxique Linux **ne valide pas** le framework WidgetKit ni les capacités Xcode.

## Signature Apple Developer : nouvel identifiant nécessaire

Pour publier sur TestFlight, l’extension watchOS doit être signée avec son **propre App ID et profil de distribution App Store**, en plus de ceux existants :

- iPhone : `com.bilux.nuclearascension`
- Watch : `com.bilux.nuclearascension.watchkitapp`
- **NOUVEAU widget : `com.bilux.nuclearascension.watchkitapp.nuclearlivewidget`**

Dans **Apple Developer → Certificates, Identifiers & Profiles → Identifiers**, créer un App ID explicite correspondant au nouveau bundle identifier (type extension d’application, sans capability HealthKit). Dans Codemagic, s’assurer qu’un profil App Store correspondant au widget est disponible dans les **Code signing identities** et que le workflow `distribution-testflight` le récupère. Selon le paramétrage, il peut être généré automatiquement ou nécessiter une création manuelle. Un test iOS/Watch *sans signature* au vert ne garantit pas la signature TestFlight de ce nouvel identifiant.

Documentation Codemagic : https://docs.codemagic.io/yaml-code-signing/signing-ios/

## Build 21 puis TestFlight

**Seulement lorsque les deux builds de vérification sont verts** :

```bash
bash /tmp/bilux-v611/PREPARER_BUILD_21.sh
```

Ce script passe **iPhone, Watch et Widget** de 20 à 21 (fichiers Info.plist, paramètres de la cible widget), refuse un second passage et pousse sur GitHub.

Lancer ensuite dans Codemagic le workflow **BILUX — Publier sur TestFlight**, branche `bilux-v6.1.1-watch-widget`, version prévue **1.0 (21)**. Si Codemagic signale une erreur de signature de `BiluxWatchWidget`, corriger d’abord le nouvel App ID / profil, et ne pas modifier les anciens bundles.

## Ajouter la complication sur Apple Watch Series 10

1. Installer le **build 21** depuis TestFlight sur l’iPhone puis vérifier l’installation de BILUX sur la Watch.
2. Sur la Watch, maintenir le doigt sur le cadran → **Modifier** → **Complications**.
3. Choisir un emplacement circulaire ou rectangulaire compatible puis sélectionner **BILUX · Nuclear Live**. Enregistrer le cadran.
4. Alternative : ouvrir la **pile intelligente** (Smart Stack), passer en modification, puis ajouter BILUX Nuclear Live si watchOS le propose.
5. Appuyer sur la complication : BILUX Watch doit s’ouvrir directement sur la page Nuclear Live. Choisir une activité et appuyer manuellement sur **DÉMARRER LIVE** pour enregistrer une séance HealthKit.

Si la complication ne se propose pas immédiatement, attendre la fin de l’installation de l’extension sur la montre, ouvrir une fois BILUX Watch, puis revenir à l’éditeur de cadran.

## Contrôles finaux

- L’appui ouvre l’onglet Nuclear Live **sans démarrer de séance**.
- Démarrer, mettre en pause, terminer : fonctionne comme en V6.1.
- L’entraînement est enregistré **une seule fois** dans Apple Santé et dans La Forge.
- L’Apple Watch continue de se synchroniser avec l’iPhone.
- Aucun changement des XP, rangs ou données du journal.

En cas d’échec de compilation, partager le **premier `error:`** des logs Xcode/Codemagic. En cas d’échec de signature, partager le message concernant le nouvel identifiant WidgetKit.

**Rollback :** garder V6.1 — Build 20 installable dans TestFlight jusqu’à validation du widget.
