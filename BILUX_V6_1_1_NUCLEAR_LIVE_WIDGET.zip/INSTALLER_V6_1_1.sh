#!/usr/bin/env bash
set -euo pipefail
BASE='bilux-v6.1-nuclear-live'
DEST='bilux-v6.1.1-watch-widget'
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail() { printf '❌ %s\n' "$*" >&2; exit 1; }

[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Ouvre le terminal à la racine du dépôt BILUX.'
[[ "$(git branch --show-current)" == "$BASE" ]] || fail "Branche attendue : $BASE"
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications locales suivies détectées. Arrêt.'
git diff --cached --quiet || fail 'Index Git non vide.'
! git show-ref --verify --quiet "refs/heads/$DEST" || fail 'La branche du widget existe déjà.'
command -v python3 >/dev/null || fail 'Python3 absent.'
git var GIT_AUTHOR_IDENT >/dev/null 2>&1 || fail 'Identité Git manquante.'

STAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE"' EXIT
python3 "$HERE/APPLIQUER_V6_1_1.py" "$(pwd)" "$STAGE" || fail 'Base incompatible ; aucun fichier du dépôt modifié.'
FILES=(
  BiluxWatch/WatchRootView.swift
  BiluxWatch/Info.plist
  BiluxWatchWidget/NuclearLiveWidget.swift
  BiluxWatchWidget/Info.plist
  BiluxIOS.xcodeproj/project.pbxproj
)
for file in "${FILES[@]}"; do
  [[ -s "$STAGE/$file" ]] || fail "Fichier attendu manquant : $file"
done
if command -v swiftc >/dev/null 2>&1; then
  swiftc -frontend -parse "$STAGE/BiluxWatchWidget/NuclearLiveWidget.swift" "$STAGE/BiluxWatch/WatchRootView.swift" || fail 'Syntaxe Swift invalide : aucun fichier modifié.'
  echo '✅ Swift : vérification syntaxique réussie (la compilation watchOS reste à faire sur Codemagic).'
fi
python3 - "$STAGE" <<'PY'
import plistlib, sys
from pathlib import Path
s=Path(sys.argv[1])
w=plistlib.loads((s/'BiluxWatch/Info.plist').read_bytes())
p=plistlib.loads((s/'BiluxWatchWidget/Info.plist').read_bytes())
assert w['CFBundleVersion']=='20' and 'biluxwatch' in w['CFBundleURLTypes'][0]['CFBundleURLSchemes']
assert p['CFBundleVersion']=='20' and p['NSExtension']['NSExtensionPointIdentifier']=='com.apple.widgetkit-extension'
print('✅ Plist Watch et Widget : valides.')
PY
if command -v plutil >/dev/null 2>&1; then
  plutil -lint "$STAGE/BiluxIOS.xcodeproj/project.pbxproj" || fail 'Format Xcode non valide.'
fi

git switch -c "$DEST"
for file in "${FILES[@]}"; do
  mkdir -p "$(dirname "$file")"
  cp "$STAGE/$file" "$file"
done
git add -- "${FILES[@]}"
git diff --cached --check || fail 'Git diff invalide : ne pas publier.'
git commit -m 'BILUX V6.1.1 - WidgetKit Nuclear Live watch complication'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
  git push -u origin "$DEST" || fail "Commit local créé, push interrompu. Relance git push -u origin $DEST"
else
  echo '🧪 Test local : push désactivé.'
fi
printf '\n✅ BILUX V6.1.1 installée : %s\n' "$DEST"
echo '➡️ Vérifier iPhone ET Watch sur Codemagic. Ne pas passer au build 21 avant deux compilations vertes.'
echo '➡️ Le widget requiert son propre bundle ID et profil App Store pour TestFlight.'
