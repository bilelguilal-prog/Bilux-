#!/usr/bin/env python3
"""BILUX 7.0: strict, additive UI-only patch of validated V6.9 build29.

Patch in a staging folder; never modify the user's repo on precondition failure.
"""
from pathlib import Path
import plistlib
import sys
import re

if len(sys.argv) != 3:
    raise SystemExit('Usage: python3 APPLIQUER_V7_0.py <repo> <staging>')
repo = Path(sys.argv[1]).resolve()
stage = Path(sys.argv[2]).resolve()
here = Path(__file__).resolve().parent

def abort(message):
    raise SystemExit('❌ ' + message + ' — aucun fichier du projet modifié.')

def read(rel):
    p = repo / rel
    if not p.is_file(): abort('Fichier manquant : ' + rel)
    return p.read_text(encoding='utf-8')

def exactly(source, old, new, label):
    if source.count(old) != 1:
        abort(f'Base V6.9 incompatible ({label} : {source.count(old)} occurrence(s))')
    return source.replace(old, new, 1)

for rel in ('BiluxIOS/Info.plist','BiluxWatch/Info.plist','BiluxWatchWidget/Info.plist'):
    try: value = str(plistlib.loads((repo/rel).read_bytes())['CFBundleVersion'])
    except Exception as ex: abort(f'Plist indisponible : {rel}: {ex}')
    if value != '29': abort(f'Build 29 attendu dans {rel}, trouvé {value}')
for rel in ('BiluxIOS/WatchPhoneBridge.swift', 'BiluxWatch/WatchRootView.swift',
            'BiluxWatchWidget/NuclearLiveWidget.swift', 'scripts/assign_widget_signing.py'):
    if not (repo / rel).is_file(): abort('Base Watch / signature manquante : ' + rel)
watch = read('BiluxWatch/WatchRootView.swift')
widget = read('BiluxWatchWidget/NuclearLiveWidget.swift')
if 'V69WatchQuestsPage' not in watch or 'V69WatchGuardiansPage' not in watch:
    abort('Watch 4.1 non reconnue')
if 'BILUXWatchWidgetPack: WidgetBundle' not in widget:
    abort('Complications Watch 4.1 non reconnues')
if 'V61LiveWorkoutView().tag(5)' not in watch:
    abort('Nuclear Live manquant')
models = read('BiluxIOS/Models.swift')
store = read('BiluxIOS/BiluxStore.swift')
for symbol in ('struct WorkoutSet:', 'struct WorkoutExercise:', 'struct WorkoutSession:', 'struct NuclearLiveReport:', 'struct V63MasterySnapshot'):
    if symbol not in models: abort('Modèle requis absent : ' + symbol)
if 'func add(_ session: WorkoutSession)' not in store:
    abort('Méthode de sauvegarde des séances non reconnue')
for field in ('var reps: Int', 'var weight: Double', 'var activity: String', 'var durationMinutes: Int',
              'var notes: String', 'var rpe: Int?', 'var exercises: [WorkoutExercise]'):
    if field not in models: abort('Propriété requise absente : '+field)

s = read('BiluxIOS/BiluxScreens.swift')
for marker in ('struct HomeScreen: View', 'struct SportScreen: View',
               'private struct BILUXV67Contemplation: View',
               'private struct V63NuclearMasteryView: View',
               'private struct V62NuclearDebrief: View'):
    if marker not in s: abort('Écran validé non retrouvé : ' + marker)
if 'V70RebirthCommandDeck' in s or 'NUCLEAR REBIRTH · V7.0' in s:
    abort('La V7.0 semble déjà présente')

home_start = s.index('struct HomeScreen: View')
sport_start = s.index('struct SportScreen: View', home_start)
home = s[home_start:sport_start]
needle = '                    heroPanel\n                    Button { showImmersion = true } label: {'
home = exactly(home, needle,
    '                    heroPanel\n                    V70RebirthCommandDeck().environmentObject(journal)\n'
    '                    Button { showImmersion = true } label: {', 'QG V6.7 / portrait animé')
s = s[:home_start] + home + s[sport_start:]

sport_start = s.index('struct SportScreen: View')
# SportScreen must be a sibling of NutritionScreen, never insert into another view.
sport_end = s.index('\nstruct NutritionScreen: View', sport_start)
sport = s[sport_start:sport_end]
if sport.count('V70ForgeSportEntry'):
    abort('Carte Forge déjà présente')
# Insert before the history so old journal, edit & delete remain unchanged.
match = list(re.finditer(r'(?m)^(\s*)SectionCaption\(title:\s*"Historique[^"\n]*"\)\s*$', sport))
if len(match) == 1:
    m = match[0]
    # Newline-safe insertion using indentation of existing caption.
    line_start = sport.rfind('\n', 0, m.start()) + 1
    indent = re.match(r'[ \t]*', sport[line_start:]).group(0)
    sport = sport[:line_start] + indent + 'V70ForgeSportEntry().environmentObject(journal)\n' + sport[line_start:]
else:
    # Newer Sport layout: insert at start of first content VStack if exactly one.
    matches = list(re.finditer(r'(?m)^(\s*)VStack\(alignment: \.leading, spacing: \d+\) \{\s*$', sport))
    if len(matches) < 1:
        abort('Insertion Sport ambiguë (historique introuvable)')
    m = matches[0]
    end = sport.find('\n', m.end())
    indent = m.group(1) + '    '
    sport = sport[:end + 1] + indent + 'V70ForgeSportEntry().environmentObject(journal)\n' + sport[end + 1:]
s = s[:sport_start] + sport + s[sport_end:]

module = (here / 'V70_NUCLEAR_REBIRTH.swift.txt').read_text(encoding='utf-8')
for marker in ('private struct V70RebirthCommandDeck: View',
               'private struct V70NuclearForge: View',
               'private struct V70NuclearAnalytics: View'):
    if module.count(marker) != 1: abort('Moteur V7.0 incomplet : '+marker)
s = s.rstrip() + '\n' + module.rstrip() + '\n'
out = stage / 'BiluxIOS/BiluxScreens.swift'
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(s, encoding='utf-8')
print('✅ BILUX V7.0 : nouveau QG, Forge et statistiques préparés.')
print('✅ Sources modifiées : BiluxIOS/BiluxScreens.swift uniquement.')
print('✅ Modèles JSON, moteur XP, Apple Santé, Watch, WidgetKit et signature : inchangés.')
