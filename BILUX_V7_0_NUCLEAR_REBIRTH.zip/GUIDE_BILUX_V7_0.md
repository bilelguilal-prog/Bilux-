# ☢️ BILUX V7.0 — NUCLEAR REBIRTH

**Version stable de départ** : BILUX V6.9 / Nuclear Watch 4.1, build **29**, validée par l'utilisateur.  
**Branche source** : `bilux-v6.9-nuclear-watch41`  
**Branche V7.0** : `bilux-v7.0-nuclear-rebirth`  
**Prochain TestFlight** : build **30**, seulement après deux compilations Codemagic vertes.

## 1. Nouveautés de la V7.0

### QG nucléaire enrichi
- Une **carte Centre de commandement V7.0** intégrée après le portrait animé actuel ; aucun remplacement risqué des effets de foudre ou des transformations.
- Résumé des séances et minutes des 7 derniers jours, volume sur 30 jours, nombre de records historiques.
- Deux raccourcis vers la **Forge** et **Nuclear Analytics**.
- Le QG, le réacteur cinématique, les missions, les XP et le personnage restent disponibles.

### Forge du combattant
- Saisie d'une séance de musculation (date, durée, effort perçu, notes).
- Plusieurs exercices par séance, plusieurs séries par exercice, avec répétitions et charges en kg ; 0 kg accepté pour des mouvements au poids du corps.
- Comparaison avec la charge maximale **déjà déclarée** pour chaque exercice, et affichage « Record brisé ⚡ » après enregistrement d'une charge supérieure.
- Minuteur **indicatif** de récupération de 90 secondes dans la Forge, en premier plan.
- Une pression sur **Enregistrer la séance** ajoute **une seule** `WorkoutSession` au `BiluxStore` actuel. L'écran bloque un deuxième enregistrement jusqu'à sa fermeture. L'XP reste calculé par le moteur existant, sans récompense spéciale pour un record.
- L'ancienne saisie « Nouvelle séance libre » est toujours accessible, sans modification.

### Nuclear Analytics
- Périodes glissantes de 7 / 30 / 90 jours.
- Séances, minutes, volume déclaré (répétitions × charge), jours actifs, séances de musculation.
- Histogramme de la fréquence d'entraînement (jours ou regroupements de 5 ou 10 jours).
- Records personnels de charge (max déclaré, historique complet), avec date et répétitions du record.
- **Limite** : les entraînements Watch sans détail de séries ne produisent pas de volume de musculation fictif. Les statistiques ne sont pas des mesures médicales et ne jugent pas la santé.

## 2. Intégrité et compatibilité

Le correctif **ne modifie que** `BiluxIOS/BiluxScreens.swift` (interface iPhone). Il **n'altère pas** :
- `BiluxIOS/Models.swift`, `BiluxIOS/BiluxStore.swift` et le format de sauvegarde JSON ;
- les mécanismes d'XP/rangs/niveaux, quêtes, maîtrises, boss ou transformations ;
- HealthKit, la synchronisation Watch/iPhone, Nuclear Live et le débrief V6.2 ;
- WidgetKit, les profils de signature Apple et Codemagic.

Le script vérifie explicitement le **build 29** sur iPhone, Watch et WidgetKit ainsi que la présence des fonctions V6.9, prépare les fichiers hors dépôt et refuse une base inconnue. **Ne pas forcer si la vérification échoue.**

**Avant de commencer :** dans BILUX, exporte une sauvegarde JSON privée et conserve-la dans Fichiers/iCloud. **Ne la mets pas sur GitHub**, elle contient des données personnelles.

## 3. Ajouter le ZIP sur GitHub

1. Ouvre `https://github.com/bilelguilal-prog/Bilux-` depuis l'iPhone.
2. Sélectionne `bilux-v6.9-nuclear-watch41`.
3. **Add file → Upload files**, ajoute `BILUX_V7_0_NUCLEAR_REBIRTH.zip` à la racine du dépôt.
4. **Commit changes**.

## 4. Installer dans Codespaces

À la racine du dépôt, exécute cette seule commande :

```bash
git switch bilux-v6.9-nuclear-watch41 && git pull --ff-only origin bilux-v6.9-nuclear-watch41 && unzip -o BILUX_V7_0_NUCLEAR_REBIRTH.zip -d /tmp/bilux-v70 && bash /tmp/bilux-v70/INSTALLER_V7_0.sh
```

Résultat attendu : `✅ V7.0 installée sur bilux-v7.0-nuclear-rebirth`.

L'installateur crée un commit et pousse la **nouvelle branche**. Aucune modification des anciens fichiers JSON, et l'ancienne branche V6.9 reste inchangée.

Si le terminal affiche une erreur, transmets la première ligne `❌` avant de relancer : l'installateur s'arrête sans modification si la base n'est pas reconnue.

## 5. Deux tests Codemagic avant TestFlight

Sur la branche `bilux-v7.0-nuclear-rebirth`, lance :

1. **BILUX — Vérifier le projet iOS** (sans signature) ;
2. **BILUX V4.1 — Vérifier Apple Watch** (sans signature).

**Les deux doivent finir au vert.** La syntaxe Swift a été vérifiée localement ; seul Xcode peut valider la résolution complète des types SwiftUI.

Pour économiser les minutes Codemagic gratuites, n'enchaîne pas des rebuilds en cas de statut `Queued` ou `Waiting` : cela indique une machine encore indisponible, pas nécessairement une erreur de code.

## 6. Préparer le build 30

Après deux tests verts, depuis la **nouvelle branche**, exécute :

```bash
unzip -o BILUX_V7_0_NUCLEAR_REBIRTH.zip -d /tmp/bilux-v70 && bash /tmp/bilux-v70/PREPARER_BUILD_30.sh
```

Le script passe les versions iPhone, Watch, WidgetKit et projet Xcode de **29 à 30**, crée un commit et pousse la branche. Il ne modifie aucun certificat.

Puis, dans Codemagic :
- Branche `bilux-v7.0-nuclear-rebirth` ;
- Workflow **BILUX — Publier sur TestFlight** ;
- Installer **1.0 (30)** après disponibilité dans TestFlight.

## 7. Vérification sur iPhone / Watch

1. **QG** : ouvre BILUX → Accueil ; sous le portrait cinématique, découvre « NUCLEAR REBIRTH · V7.0 », avec les indicateurs réels et les accès Forge/Analytics.
2. **Forge** : ouvre « Entrer dans la Forge ». Renseigne un exercice, deux séries (ex. 10 × 20 kg et 8 × 22 kg), une durée et sauvegarde **une seule fois**. Un nouveau record doit être affiché si la charge dépasse l'ancien maximum.
3. **Journal** : vérifie que la séance vient d'apparaître une fois dans Sport ; compare XP/quête avec le comportement habituel (aucun bonus « record »).
4. **Statistiques** : utilise 7 / 30 / 90 jours ; vérifie qu'elles reprennent les séances précédentes et que le volume nouvellement enregistré apparaît.
5. **Données** : vérifie que tes anciennes séances, nutrition, suivi santé, XP, titres, maîtrises et transformations sont toujours là. Ferme et relance BILUX ; tes données doivent persister.
6. **Watch** : vérifie les quêtes, gardiens, maîtrise, la complication et une séance Nuclear Live courte. Le débrief reste disponible sur iPhone.

Si les tests échouent, **ne réinstalle pas une ancienne version à l'aveugle**. Conserve le build 29/TestFlight et le JSON de sauvegarde ; fais-nous parvenir le journal du premier échec.

## 8. Contrôles effectués avant livraison

- Analyse syntaxique Swift des fichiers ajoutés et du fichier d'interface assemblé sur base de test.
- Exécution simulée de l'installateur (branche et commit) et du script de préparation du build 30 (trois versions et Xcode).
- Vérification des garde-fous : script à arrêt sécurisé, et aucune écriture sur le stockage médical ou les XP.
- **Limite explicite** : les véritables compilations Xcode iOS/watchOS et le rendu sur iPhone/Watch doivent être validés chez Codemagic et sur appareil ; le dépôt GitHub privé en version V6.9 n'a pas été ouvert directement dans l'environnement local.
