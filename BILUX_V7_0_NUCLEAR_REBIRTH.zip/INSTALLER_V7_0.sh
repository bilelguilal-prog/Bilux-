#!/usr/bin/env bash
set -euo pipefail
BASE='bilux-v6.9-nuclear-watch41'
NEW='bilux-v7.0-nuclear-rebirth'
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail() { printf '❌ %s\n' "$*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Lancer depuis la racine du dépôt BILUX.'
[[ "$(git branch --show-current)" == "$BASE" ]] || fail "Branche de départ attendue : $BASE"
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Sauvegarder les modifications suivies non commitées avant installation.'
git diff --cached --quiet || fail 'Index Git non vide.'
! git show-ref --verify --quiet "refs/heads/$NEW" || fail "La branche $NEW existe déjà."
command -v python3 >/dev/null || fail 'Python 3 manquant.'
git var GIT_AUTHOR_IDENT >/dev/null 2>&1 || fail 'Identité Git absente.'
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
python3 "$HERE/APPLIQUER_V7_0.py" "$(pwd)" "$TMP" || fail 'Validation de base échouée ; dépôt inchangé.'
[[ -s "$TMP/BiluxIOS/BiluxScreens.swift" ]] || fail 'Source Swift générée manquante.'
if command -v swiftc >/dev/null 2>&1; then
    swiftc -frontend -parse "$TMP/BiluxIOS/BiluxScreens.swift" BiluxIOS/Models.swift || fail 'Erreur de syntaxe Swift : dépôt inchangé.'
    echo '✅ Syntaxe Swift validée. Vérification de typage/Xcode requise sur Codemagic.'
else
    echo 'ℹ️ swiftc absent de Codespaces : compilation Xcode obligatoire.'
fi
git switch -c "$NEW"
cp "$TMP/BiluxIOS/BiluxScreens.swift" BiluxIOS/BiluxScreens.swift
git add -- BiluxIOS/BiluxScreens.swift
git diff --cached --check || fail 'Diff Git invalide.'
git commit -m 'BILUX V7.0 - Nuclear Rebirth QG Forge and analytics'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
  git push -u origin "$NEW" || fail "Commit local créé : réessayer git push -u origin $NEW"
else
  echo '🧪 Simulation : aucun push.'
fi
echo "✅ V7.0 installée sur $NEW. Compiler iPhone + Watch AVANT build 30."
