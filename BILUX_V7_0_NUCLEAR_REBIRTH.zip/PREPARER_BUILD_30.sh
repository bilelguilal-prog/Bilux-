#!/usr/bin/env bash
set -euo pipefail
BRANCH='bilux-v7.0-nuclear-rebirth'
fail() { echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Se placer à la racine du dépôt.'
[[ "$(git branch --show-current)" == "$BRANCH" ]] || fail "Branche attendue : $BRANCH"
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications locales non commitées.'
git diff --cached --quiet || fail 'Index Git non vide.'
grep -q 'private struct V70NuclearForge: View' BiluxIOS/BiluxScreens.swift || fail 'La Forge V7.0 est absente.'
grep -q 'private struct V70NuclearAnalytics: View' BiluxIOS/BiluxScreens.swift || fail 'Les statistiques V7.0 sont absentes.'
grep -q 'V69WatchQuestsPage' BiluxWatch/WatchRootView.swift || fail 'Watch 4.1 absente.'
grep -q 'V61LiveWorkoutView().tag(5)' BiluxWatch/WatchRootView.swift || fail 'Nuclear Live absent.'
grep -q 'BILUXWatchWidgetPack' BiluxWatchWidget/NuclearLiveWidget.swift || fail 'WidgetKit Watch 4.1 absent.'
[[ -f scripts/assign_widget_signing.py ]] || fail 'Signature widget absente.'
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
python3 - "$TMP" <<'PY'
import plistlib, sys
from pathlib import Path
root=Path.cwd(); stage=Path(sys.argv[1]); out=[]
for rel in ('BiluxIOS/Info.plist','BiluxWatch/Info.plist','BiluxWatchWidget/Info.plist'):
    try: payload=plistlib.loads((root/rel).read_bytes())
    except Exception as ex: raise SystemExit(f'❌ Plist invalide : {rel}: {ex}')
    if str(payload.get('CFBundleVersion'))!='29':
        raise SystemExit(f'❌ {rel}: build 29 attendu (aucune modification).')
    payload['CFBundleVersion']='30'
    target=stage/rel; target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(plistlib.dumps(payload,sort_keys=False))
    out.append(rel)
rel='BiluxIOS.xcodeproj/project.pbxproj'
source=(root/rel).read_text(encoding='utf-8')
if source.count('CURRENT_PROJECT_VERSION = 29;') != 2:
    raise SystemExit('❌ Xcode : deux références CURRENT_PROJECT_VERSION=29 attendues.')
if 'BiluxWatchWidget' not in source:
    raise SystemExit('❌ Projet Xcode sans widget.')
target=stage/rel; target.parent.mkdir(parents=True,exist_ok=True)
target.write_text(source.replace('CURRENT_PROJECT_VERSION = 29;', 'CURRENT_PROJECT_VERSION = 30;'),encoding='utf-8')
print('✅ Build 30 préparé : iPhone, Watch, WidgetKit (profils de signature conservés).')
PY
FILES=(BiluxIOS/Info.plist BiluxWatch/Info.plist BiluxWatchWidget/Info.plist BiluxIOS.xcodeproj/project.pbxproj)
for rel in "${FILES[@]}"; do cp "$TMP/$rel" "$rel"; done
git add -- "${FILES[@]}"
git diff --cached --check || fail 'Diff Git invalide.'
git commit -m 'BILUX V7.0 - Build 30 iPhone Watch WidgetKit'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
    git push origin "$BRANCH" || fail "Commit local créé : relancer git push origin $BRANCH"
else
    echo '🧪 Simulation : aucun push.'
fi
echo '✅ Build 30 prêt. Publier sur TestFlight seulement après deux compilations vertes.'
