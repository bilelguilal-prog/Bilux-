#!/usr/bin/env python3
from pathlib import Path
import sys, plistlib
if len(sys.argv)!=3: raise SystemExit('Usage: APPLIQUER_V7_6.py ROOT STAGING')
root,stage=map(lambda s: Path(s).resolve(),sys.argv[1:]);here=Path(__file__).resolve().parent

def fail(s): raise SystemExit('❌ '+s+' — dépôt inchangé.')
def read(rel): return (root/rel).read_text(encoding='utf8')
def txt(name): return (here/name).read_text(encoding='utf8')
def once(s,a,b):
 if s.count(a)!=1: fail('Ancre V7.5 inattendue : '+repr(a[:150]))
 return s.replace(a,b,1)
files={}
for rel in ('BiluxIOS/Info.plist','BiluxWatch/Info.plist','BiluxWatchWidget/Info.plist'):
 if str(plistlib.loads((root/rel).read_bytes())['CFBundleVersion'])!='35': fail('Build 35 requis : '+rel)
if not (root/'scripts/assign_widget_signing.py').is_file(): fail('Signature WidgetKit absente')
rel='BiluxShared/WatchSnapshot.swift';s=read(rel)
s=once(s,'    var masteryPaths: [WatchMasteryPath]? = nil\n','''    var masteryPaths: [WatchMasteryPath]? = nil
    var forgeDays: [V76PlanDay]? = nil
    var forgeDayCount: Int? = nil
    var treatmentRecords: [V76TreatmentRecord]? = nil
''');files[rel]=s.rstrip()+txt('SHARED.swift.txt')
rel='BiluxIOS/WatchPhoneBridge.swift';s=read(rel)
s=once(s,'final class WatchPhoneBridge: NSObject, WCSessionDelegate {','final class WatchPhoneBridge: NSObject, ObservableObject, WCSessionDelegate {')
s=once(s,'    private override init() { super.init() }','    private override init() { super.init() }\n'+txt('PHONE_BRIDGE.swift.txt'))
s=once(s,'        if WCSession.isSupported() {\n            WCSession.default.delegate = self','''        NotificationCenter.default.publisher(for: Notification.Name("bilux.v73.eternalforge.changed"))
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in self?.sendSnapshot() }
            .store(in: &subscriptions)
        if WCSession.isSupported() {
            WCSession.default.delegate = self''')
s=once(s,'let payload = try? JSONEncoder().encode(snapshot) else { return }','let payload = encodedSnapshot() else { return }')
s=once(s,'        guard !journal.data.workouts.contains(where: { $0.id == id }) else { return }','''        let forge = (message["forgePayload"] as? Data).flatMap { raw -> V76ForgePayload? in
            guard raw.count <= 100_000, let parsed = try? JSONDecoder().decode(V76ForgePayload.self, from: raw), parsed.valid else { return nil }
            return parsed
        }
        if let old = journal.data.workouts.first(where: { $0.id == id }) {
            if let forge { V76LinkWatchWorkout(forge, workout: old) }
            return
        }''')
s=once(s,'        if isLive {\n            let count = max(0, min(25_000','''        if let forge, isLive {
            entry.exercises = forge.exercises.map { exercise in
                WorkoutExercise(name: exercise.name, sets: exercise.sets.map { set in
                    WorkoutSet(id: set.id, reps: set.reps, weight: set.weight)
                })
            }
        }
        if isLive {
            let count = max(0, min(25_000''')
s=once(s,'        journal.add(entry)\n','''        journal.add(entry)
        if let forge, isLive { V76LinkWatchWorkout(forge, workout: entry) }
''')
s=once(s,'        Task { @MainActor in receiveWorkout(userInfo) }','''        Task { @MainActor in
            if !receiveV76Event(userInfo) { receiveWorkout(userInfo) }
        }''')
s=once(s,'''            if message["type"] == nil { replyHandler([:]); return }
            if message["type"] as? String == "requestSnapshot",
               let data = try? JSONEncoder().encode(snapshot) {''','''            if message["type"] == nil { replyHandler([:]); return }
            let handled = receiveV76Event(message)
            if (handled || message["type"] as? String == "requestSnapshot"),
               let data = encodedSnapshot() {''')
files[rel]=s
rel='BiluxWatch/WatchBridge.swift';s=read(rel)
s=once(s,'    override init() {',txt('WATCH_BRIDGE.swift.txt')+'\n    override init() {')
s=once(s,'        flushWorkouts()\n    }\n\n    func finishWorkout','        flushWorkouts()\n        flushTreatment()\n    }\n\n    func finishWorkout')
s=once(s,'                           sampleCount: Int) {','                           sampleCount: Int, forgePayload: V76ForgePayload? = nil) {')
s=once(s,'        event["sampleCount"] = sampleCount','''        event["sampleCount"] = sampleCount
        if let forgePayload, forgePayload.valid, let encoded = try? JSONEncoder().encode(forgePayload) {
            event["forgePayload"] = encoded
        }''')
s=once(s,'        snapshot = value\n','''        if let rows = value.treatmentRecords { acceptTreatment(rows) }
        // Never replace a newer cached plan/RPG snapshot with an older direct reply.
        // Treatment merges separately, even when the snapshot itself is older.
        guard value.updatedAt >= snapshot.updatedAt else { return }
        snapshot = value
''')
files[rel]=s
rel='BiluxWatch/WatchRootView.swift';s=read(rel)
s=once(s,'            V68WatchMasteryPage().tag(6)\n','            V68WatchMasteryPage().tag(6)\n            V76WatchForge().tag(7)\n')
s=once(s,'Text("WATCH 4.1")','Text("WATCH 5.0")')
s=once(s,'                V54ReactorCard(accent: V54ReactorTheme.gold) {\n                    HStack(alignment: .center, spacing: 10) {\n                        V68ReactorCore', '                V76WatchTreatment()\n\n                V54ReactorCard(accent: V54ReactorTheme.gold) {\n                    HStack(alignment: .center, spacing: 10) {\n                        V68ReactorCore')
s=once(s,'                // Quêtes uniquement depuis le résumé Watch envoyé par l\'iPhone.','''                Button { selectedPage = 7 } label: {
                    Label("FORGE LIVE", systemImage: "dumbbell.fill").font(.caption.bold()).frame(maxWidth: .infinity)
                }.buttonStyle(.borderedProminent).tint(V54ReactorTheme.gold)

                // Quêtes uniquement depuis le résumé Watch envoyé par l'iPhone.''')
s=once(s,'    var inProgress: Bool { phase == .requesting',txt('LIVE_METHODS.swift.txt')+'\n    var inProgress: Bool { phase == .requesting')
s=once(s,'               referenceMaxBPM: Int, enableHaptics: Bool) async {','               referenceMaxBPM: Int, enableHaptics: Bool, forgeDay: V76PlanDay? = nil) async {')
s=once(s,'        self.bridge = bridge\n        phase = .requesting','''        self.bridge = bridge
        if let day = forgeDay { forgeDraft = V76ForgeDraft(day: day) } else { forgeDraft = nil }
        phase = .requesting''')
s=once(s,'        let seconds = elapsed()\n        guard seconds >= 60 else {','''        if let draft = forgeDraft, !draft.payload.valid {
            message = "Valide au moins une série réellement effectuée dans Forge Live."
            return
        }
        let seconds = elapsed()
        guard seconds >= 60 else {''')
s=once(s,'            try await store.requestAuthorization(toShare: share, read: read)\n','            try await store.requestAuthorization(toShare: share, read: read)\n            guard phase == .requesting else { return }\n')
s=once(s,'        didFinish = true\n        finishDuration = seconds','        stopForgeRest()\n        didFinish = true\n        finishDuration = seconds')
s=once(s,'                        sampleCount: self.heartSamples\n','                        sampleCount: self.heartSamples, forgePayload: self.forgeDraft?.payload\n')
s=once(s,'    private func clearReferences() {\n','    private func clearReferences() {\n        stopForgeRest()\n        forgeDraft = nil\n')
files[rel]=s.rstrip()+txt('WATCH_UI.swift.txt')
rel='BiluxIOS/BiluxScreens.swift';s=read(rel)
if 'private struct V75WeeklyChroniclesView: View' not in s: fail('Chroniques V7.5 absentes')
s=once(s,'            V73EternalForgeEntry().environmentObject(journal)\n            V72AwakeningEntry().environmentObject(journal)\n','            V76TreatmentCard()\n            V73EternalForgeEntry().environmentObject(journal)\n            V72AwakeningEntry().environmentObject(journal)\n')
s=once(s,'                    SectionCaption(title: "Journal post-thyroïdectomie")','                    V76TreatmentHistory()\n                    SectionCaption(title: "Journal post-thyroïdectomie")')
files[rel]=s.rstrip()+txt('PHONE_UI.swift.txt')
for rel,s in files.items():
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf8');print('✅ Préparé',rel)
