# BILUX V7.6 — NUCLEAR WATCH 5.0 · FORGE LIVE

Base : `bilux-v7.5-nuclear-chronicles`, build 35. Nouvelle branche : `bilux-v7.6-nuclear-watch5`, build 36.

## Installation
1. Sauvegarder le journal BILUX et les programmes Eternal Forge en JSON privé. Ne pas publier les sauvegardes sur GitHub.
2. Ajouter BILUX_V7_6_NUCLEAR_WATCH_5.zip à la racine de la branche V7.5 sur GitHub et commiter le ZIP.
3. Dans Codespaces, à la racine du dépôt :

```bash
git switch bilux-v7.5-nuclear-chronicles && git pull --ff-only origin bilux-v7.5-nuclear-chronicles && unzip -o BILUX_V7_6_NUCLEAR_WATCH_5.zip -d /tmp/bilux-watch5 && bash /tmp/bilux-watch5/INSTALLER_V7_6.sh && bash /tmp/bilux-watch5/PREPARER_BUILD_36.sh
```

4. Codemagic : sélectionner `bilux-v7.6-nuclear-watch5`, workflow **BILUX — Publier sur TestFlight** uniquement. Aucun test simulateur séparé prévu. Installer le build 36 sur iPhone ET Watch. Si un script refuse les ancres ou le numéro de build, ne pas le remplacer par une commande de force : transmettre le message exact.

## Traitement quotidien
- QG iPhone et accueil Watch : sélectionner **CONFIRMER MA PRISE** après une prise réelle. Une confirmation est une déclaration, pas une preuve médicale, ni une consigne de prise.
- Date locale (jour civil), heure de confirmation, identifiant de révision. Une journée = un état ; le bouton reprend quotidiennement l'état non confirmé, sans effacer les jours précédents. Appuyer sur « Prise confirmée » propose une annulation explicite de la confirmation du jour.
- Synchronisation via WatchConnectivity : mise à jour immédiate lorsque joignable, sinon transmission différée. La Watch garde localement les confirmations non acquittées par l'iPhone. Un événement ancien ou dupliqué ne remplace pas un état plus récent. En cas d'actions concurrentes le dernier événement horodaté l'emporte (correction prioritaire en cas d'égalité). Horloges des deux appareils à garder à l'heure.
- Santé → Traitement : historique des confirmations et annulations, export/import privé séparé du JSON historique BILUX et de celui des programmes. L'import fusionne les dates sans dupliquer les entrées. L'export contient des données sensibles : conserver dans Fichiers privé, pas sur le dépôt.
- Aucun calcul de dose, aucune modification de traitement ou écriture dans Médicaments d'Apple Santé. Aucun XP attribué. Un état non confirmé ou non synchronisé ne veut pas dire que le traitement a été oublié ; ne pas s'y fier pour décider de reprendre une dose.
- Test : après une vraie prise, confirmer sur un appareil et vérifier le second ; effectuer les tests d'annulation uniquement si l'état correct est rétabli ensuite. Si déconnecté, l'indication « synchro iPhone en attente » doit disparaître après réception effective. Ne pas créer de confirmations fictives pour tester.

## Forge Live
- Créer un programme dans Eternal Forge sur iPhone. Le résumé transmet jusqu'aux 20 premières journées actives sur Watch ; les autres restent sur iPhone. Actualiser les programmes si nécessaire.
- Sur la Watch : accueil → FORGE LIVE, choisir une journée, démarrer. Le moteur Nuclear Live unique lance une séance de musculation HealthKit ; il refuse un second démarrage simultané.
- Toucher la charge ou les répétitions puis tourner la Digital Crown. Valider chaque série effectivement réalisée. Aucun objectif prérempli n'est automatiquement enregistré. Le prochain exercice arrive après la dernière série prévue. Repos réglable (30–300 s, 90 s initialement), vibration à la fin lorsque watchOS permet l'exécution, bouton pour passer le repos. Tu peux passer à l'écran LIVE pendant le même entraînement.
- Arrêter avec « Terminer » après au moins une minute effective et au moins une série validée ; seule la séance réelle est enregistrée. Après succès HealthKit, le même UUID sert au journal iPhone, les séries et le rapport cardiaque sont transmis. L'association au programme existant alimente la campagne si les critères habituels sont satisfaits. La transmission dépend de WatchConnectivity ; ne pas recréer manuellement une séance pendant une attente de synchronisation.
- Le brouillon des séries est conservé pendant la session en mémoire (navigation possible), mais pas conçu pour récupérer un entraînement interrompu par une fermeture forcée ou un redémarrage. L'ancienne limite de réception des séances (7 jours / durée 1–240 min) est conservée. Une récupération plus robuste est prévue dans Absolute Sync. La confirmation du traitement, elle, est persistée localement indépendamment.

## Vérifications après TestFlight
1. Vérifier les versions installées et l'accueil Watch 5.0, les complications historiques, les niveaux et les programmes.
2. Confirmer la prise réellement effectuée et constater la synchronisation bidirectionnelle. Vérifier la date et l'heure dans Santé et l'export privé.
3. Avec une vraie séance, sélectionner une journée, modifier poids/reps, valider une série et tester repos/vibration et pause/reprise. Terminer et contrôler une seule séance, avec ses séries, dans le journal iPhone et une seule séance dans Apple Santé.
4. Contrôler les XP, la progression de campagne (uniquement si éligible) et l'ancienne page Nuclear Live.

## Tests exécutés et limites
Correctif appliqué sur une reconstruction V7.5 à partir des archives, pas sur le dépôt GitHub distant réel. Scripts Git simulés sans push, numéros de build des trois cibles vérifiés. Analyse syntaxique des cinq fichiers Swift et typage des modèles partagés sous Swift Linux réussis. Tests du moteur de fusion (réception dans le désordre, annulations, dates distinctes et doublons), brouillon de séries, encodage et décodage des anciens snapshots réussis. Xcode/SwiftUI, HealthKit réel, Digital Crown, vibrations et transport WatchConnectivity sur les appareils jumelés restent à valider. Les fichiers de signature, widget et règles XP ne changent pas. V7.5/build 35 reste le retour de secours.
