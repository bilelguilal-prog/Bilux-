#!/usr/bin/env bash
set -euo pipefail
BASE='bilux-v7.5-nuclear-chronicles'
TARGET='bilux-v7.6-nuclear-watch5'
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail(){ echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Se placer à la racine de BILUX.'
[[ "$(git branch --show-current)" == "$BASE" ]] || fail "Branche de base attendue : $BASE"
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications suivies non validées ; commit ou stash nécessaire.'
git diff --cached --quiet || fail 'Index Git non vide.'
! git show-ref --verify --quiet "refs/heads/$TARGET" || fail "La branche $TARGET existe déjà. Ne pas écraser."
command -v python3 >/dev/null || fail 'Python 3 requis.'
git var GIT_AUTHOR_IDENT >/dev/null 2>&1 || fail 'Configure ton identité Git.'
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
python3 "$HERE/APPLIQUER_V7_6.py" "$(pwd)" "$TMP" || fail 'Base V7.5 incompatible ; aucune source changée.'
FILES=(BiluxShared/WatchSnapshot.swift BiluxIOS/WatchPhoneBridge.swift BiluxIOS/BiluxScreens.swift BiluxWatch/WatchBridge.swift BiluxWatch/WatchRootView.swift)
for rel in "${FILES[@]}"; do [[ -s "$TMP/$rel" ]] || fail "Fichier absent : $rel"; done
if command -v swiftc >/dev/null 2>&1; then
  for rel in "${FILES[@]}"; do swiftc -frontend -parse "$TMP/$rel" || fail "Analyse syntaxique en échec : $rel"; done
  swiftc -typecheck "$TMP/BiluxShared/WatchSnapshot.swift" || fail 'Modèles partagés invalides.'
  echo '✅ Syntaxe Swift et typage des modèles partagés contrôlés (pas SwiftUI Xcode).'
fi
git switch -c "$TARGET"
for rel in "${FILES[@]}"; do cp "$TMP/$rel" "$rel"; done
git add -- "${FILES[@]}"
git diff --cached --check || fail 'Diff Git invalide.'
git commit -m 'BILUX V7.6 - Forge Live et traitement synchronisé'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
  git push -u origin "$TARGET" || fail 'Commit local créé ; réessayer le push sur la nouvelle branche.'
else
  echo '🧪 Test local : pas de push.'
fi
echo "✅ V7.6 installée sur $TARGET. Préparer le build 36."
