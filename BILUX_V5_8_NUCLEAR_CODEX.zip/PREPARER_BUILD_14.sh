#!/usr/bin/env bash
set -euo pipefail
BRANCH='bilux-v5.8-nuclear-codex'
fail(){ echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Lance le script à la racine du dépôt.'
[[ "$(git branch --show-current)" == "$BRANCH" ]] || fail "Branche $BRANCH attendue."
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Des fichiers suivis ont des modifications locales.'
git diff --cached --quiet || fail 'Des changements sont déjà indexés.'
grep -q 'BILUX V5.8 · THE NUCLEAR CODEX' BiluxIOS/BiluxScreens.swift || fail 'Code V5.8 non trouvé.'
python3 - <<'PY'
from pathlib import Path
import plistlib,sys
paths=[Path('BiluxIOS/Info.plist'),Path('BiluxWatch/Info.plist')]
original={}
for path in paths:
    if not path.is_file(): raise SystemExit(f'❌ {path} absent. Aucun fichier modifié.')
    original[path] = path.read_bytes()
    build=plistlib.loads(original[path]).get('CFBundleVersion')
    if str(build)!='13': raise SystemExit(f'❌ {path} : build 13 requis, reçu {build}. Aucun fichier modifié.')
for path in paths:
    obj=plistlib.loads(original[path])
    obj['CFBundleVersion']='14'
    path.write_bytes(plistlib.dumps(obj, fmt=plistlib.FMT_XML, sort_keys=False))
    print(f'✅ {path}: build 13 → 14')
PY
git add -- BiluxIOS/Info.plist BiluxWatch/Info.plist
git diff --cached --check || fail 'Diff de préparation non valide.'
git commit -m 'BILUX V5.8 - TestFlight build 14'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != 1 ]]; then
  git push -u origin "$BRANCH" || fail "Push interrompu : relance git push -u origin $BRANCH"
else
  echo '🧪 Test local : aucun push vers GitHub.'
fi
echo '✅ Build 14 préparé. Tu peux lancer le workflow TestFlight sur la branche V5.8.'
