#!/usr/bin/env bash
set -euo pipefail
BASE='bilux-v5.7-nuclear-awakening'
DEST='bilux-v5.8-nuclear-codex'
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail() { echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Exécute ce script depuis la racine du dépôt BILUX.'
[[ "$(git branch --show-current)" == "$BASE" ]] || fail "Branche attendue : $BASE"
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications locales déjà présentes sur des fichiers suivis. Arrêt par sécurité.'
git diff --cached --quiet || fail 'Des changements sont indexés : arrête avant de les mélanger.'
! git show-ref --verify --quiet "refs/heads/$DEST" || fail "La branche locale $DEST existe déjà."
[[ -f "$HERE/APPLIQUER_V5_8.py" && -f "$HERE/CODEX_V58.swift.txt" ]] || fail 'ZIP incomplet.'
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
python3 "$HERE/APPLIQUER_V5_8.py" "$(pwd)" "$TMP/staged" || fail 'Base V5.7 non reconnue. Aucun fichier modifié.'
if command -v swiftc >/dev/null 2>&1; then
  swiftc -frontend -parse "$TMP/staged/BiluxIOS/BiluxScreens.swift" || fail 'Syntaxe Swift invalide. Aucun fichier modifié.'
  echo '✅ Analyse syntaxique Swift réussie (compilation iOS réelle à faire dans Codemagic).'
else
  echo 'ℹ️ swiftc indisponible. La compilation réelle sera vérifiée dans Codemagic.'
fi
git switch -c "$DEST"
cp "$TMP/staged/BiluxIOS/BiluxScreens.swift" BiluxIOS/BiluxScreens.swift
git add -- BiluxIOS/BiluxScreens.swift
git diff --cached --check || fail 'Contrôle des modifications échoué : publication interrompue.'
git commit -m 'BILUX V5.8 - Nuclear Codex, bestiary, trophies, chronicles and secrets'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != 1 ]]; then
  git push -u origin "$DEST" || fail "Push interrompu : vérifie le réseau puis lance git push -u origin $DEST"
else
  echo '🧪 Test local : aucun push vers GitHub.'
fi
echo "✅ BILUX V5.8 créée sur la branche $DEST"
echo '➡️ Lance les deux workflows iPhone et Watch sans signature sur Codemagic.'
echo '➡️ Après les deux validations, utilise PREPARER_BUILD_14.sh.'
