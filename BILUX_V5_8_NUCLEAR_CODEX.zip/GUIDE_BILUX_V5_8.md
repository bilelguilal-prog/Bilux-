# BILUX V5.8 — THE NUCLEAR CODEX

## Ce qui change

- Un bouton **OUVRIR LE GRIMOIRE** dans **Ascension** ouvre le Nuclear Codex.
- **Bestiaire** : deux boss illustrés, progression de la période en cours, phase de combat et nombre de victoires depuis l'activation V5.5. Les mêmes règles que le moteur d'XP s'appliquent : séance d'au moins 10 min, un jour maximum par jour, cinq jours maximum par semaine.
- **Salle des trophées** : les six trophées historiques, six badges de prestige supplémentaires, et leur statut calculé à partir du journal.
- **Chroniques** : les 20 dernières séances présentées comme des chapitres avec activité, date, durée et volume déclaré ; pas de notes médicales.
- **Galerie** : les cinq portraits existants ; possibilité de rejouer une cinématique sur un rang déjà acquis.
- **Secrets** : six fragments narratifs et titres qui se révèlent selon le niveau, les séances ou les victoires.
- Suppression de l'ancien texte de version V5.6 dans les dossiers de combat.

**Important :** Aucune donnée supplémentaire n'est enregistrée, aucun XP ajouté par le Codex, aucun changement de règle de progression, aucun changement sur la Watch. Les anciennes victoires d'avant la V5.5 ne sont pas reconstructibles et ne sont pas affichées comme acquises.

## Installation (iPhone + GitHub + Codespaces)

1. Dans BILUX V5.7, sauvegarder le journal JSON dans Fichiers. **Ne jamais télécharger ce journal personnel sur GitHub.**
2. Sur https://github.com/bilelguilal-prog/Bilux- sélectionner la branche `bilux-v5.7-nuclear-awakening`.
3. `Add file` > `Upload files` > ajouter `BILUX_V5_8_NUCLEAR_CODEX.zip` > Commit.
4. Dans Codespaces, coller :

```bash
git switch bilux-v5.7-nuclear-awakening && git pull --ff-only origin bilux-v5.7-nuclear-awakening && unzip -o BILUX_V5_8_NUCLEAR_CODEX.zip -d /tmp/bilux-v58 && bash /tmp/bilux-v58/INSTALLER_V5_8.sh
```

Le script doit créer la branche `bilux-v5.8-nuclear-codex`, vérifier la compatibilité du code et pousser la modification sur GitHub.

## Vérifications Codemagic

Sur la branche `bilux-v5.8-nuclear-codex` :

1. **BILUX — Vérifier le projet iOS (sans Apple Developer)**
2. **BILUX V4.1 — Vérifier Apple Watch (sans signature)**

**Attendre deux validations vertes avant de préparer le build 14.**

## Préparer TestFlight (uniquement après les deux compilations vertes)

Dans Codespaces :

```bash
bash /tmp/bilux-v58/PREPARER_BUILD_14.sh
```

Dans Codemagic, sélectionner `bilux-v5.8-nuclear-codex` puis **BILUX — Publier sur TestFlight**. Le build attendu est **1.0 (14)**.

## Checklist sur iPhone

- V5.8 > Ascension > Ouvrir le grimoire.
- Ouvrir successivement les cinq rubriques, puis les deux dossiers de boss.
- Vérifier les compteurs : les « victoires » historiques ne comptent que les périodes éligibles depuis V5.5.
- Depuis Formes, rejouer une cinématique d'un rang débloqué.
- Vérifier que tes séances, total d'XP, rang et synchronisation Watch sont inchangés.

## Limites et sécurité

Le correctif a été appliqué et analysé syntaxiquement sur une **copie reconstruite** de V5.7. La branche GitHub réelle peut avoir des écarts non présents dans les archives : dans ce cas, le script arrête sans modifier les fichiers. L'absence de conflit de script ne remplace pas les vraies compilations SwiftUI de Codemagic. La branche V5.7 et le build 13 restent la base de secours.
