#!/usr/bin/env python3
"""BILUX V5.8: strict V5.7 UI-only additive install, all staging before any write."""
from pathlib import Path
import plistlib, sys

if len(sys.argv) != 3:
    raise SystemExit('Usage: APPLIQUER_V5_8.py <repo_root> <stage_dir>')
root, stage = (Path(a).resolve() for a in sys.argv[1:])
here = Path(__file__).resolve().parent

def once(text, old, new, description):
    count = text.count(old)
    if count != 1:
        raise ValueError(f'{description}: ancre attendue une fois, trouvée {count}. Rien modifié.')
    return text.replace(old, new, 1)

try:
    for path in ('BiluxIOS/Info.plist', 'BiluxWatch/Info.plist'):
        with (root/path).open('rb') as stream: info = plistlib.load(stream)
        if str(info.get('CFBundleVersion')) != '13':
            raise ValueError(f'{path}: build 13 attendu, reçu {info.get("CFBundleVersion")!r}.')
    target = root/'BiluxIOS/BiluxScreens.swift'
    text = target.read_text(encoding='utf-8')
    required = ['// MARK: - BILUX V5.7 · NUCLEAR AWAKENING',
                'struct AscensionScreen: View {',
                'private struct BILUXV56BossBattle: View {',
                'BILUXV57RankCinema(stage: stage, effectsEnabled: effectsEnabled)',
                'private enum BILUXV56Boss: String, Identifiable, CaseIterable']
    if not all(needle in text for needle in required):
        raise ValueError('Base V5.7 exacte non reconnue : annulation avant modification.')
    if 'BILUX V5.8 · THE NUCLEAR CODEX' in text or 'BILUXV58Codex:' in text:
        raise ValueError('V5.8 déjà installée. Ne pas appliquer deux fois.')

    text = once(text,
      '''    @State private var showingImporter = false
    @State private var exportFile: URL?''',
      '''    @State private var showingImporter = false
    @State private var showCodex = false
    @State private var exportFile: URL?''',
      'Ascension state')
    text = once(text,
      '''                    LongAscensionQuestBoard()
                    SectionCaption(title: "Les cinq transformations")''',
      '''                    LongAscensionQuestBoard()
                    SectionCaption(title: "Le Nuclear Codex")
                    NuclearCard {
                        HStack(alignment: .center, spacing: 13) {
                            Image(systemName: "books.vertical.fill")
                                .font(.system(size: 33)).foregroundStyle(Nuclear.gold)
                            VStack(alignment: .leading, spacing: 5) {
                                Text("THE NUCLEAR CODEX")
                                    .font(.headline.bold()).foregroundStyle(Nuclear.paleGold)
                                Text("Bestiaire · Trophées · Chroniques · Formes · Secrets")
                                    .font(.caption).foregroundStyle(Nuclear.muted)
                            }
                        }
                        Button { showCodex = true } label: {
                            Label("OUVRIR LE GRIMOIRE", systemImage: "book.closed.fill")
                                .font(.headline.bold()).frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.borderedProminent).tint(Nuclear.gold)
                    }
                    SectionCaption(title: "Les cinq transformations")''',
      'Codex entry')
    text = once(text,
      '''            .fullScreenCover(item: $cinematicStage) { stage in
                BILUXV57RankCinema(stage: stage, effectsEnabled: effectsEnabled) {
                    cinematicStage = nil
                }
            }
            .fileImporter(isPresented: $showingImporter, allowedContentTypes: [.json])''',
      '''            .sheet(isPresented: $showCodex) {
                BILUXV58Codex().environmentObject(journal)
            }
            .fullScreenCover(item: $cinematicStage) { stage in
                BILUXV57RankCinema(stage: stage, effectsEnabled: effectsEnabled) {
                    cinematicStage = nil
                }
            }
            .fileImporter(isPresented: $showingImporter, allowedContentTypes: [.json])''',
      'Ascension Codex sheet')
    text = once(text,
        'Text("DOSSIER DE COMBAT · BILUX V5.6")',
        'Text("DOSSIER DE COMBAT · ARÈNE DES GARDIENS")',
        'Remove stale version from battle')
    text = text.rstrip()+'\n'+(here/'CODEX_V58.swift.txt').read_text(encoding='utf-8')
    if any(m in text for m in ('<<<<<<< ', '>>>>>>> ')):
        raise ValueError('Marqueur de conflit repéré. Aucune modification.')
    output = stage/'BiluxIOS/BiluxScreens.swift'
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(text,encoding='utf-8')
    print('✅ BILUX V5.7 reconnue : 5 rubriques du Codex préparées en zone temporaire.')
    print('✅ Ancien code, données, cinématiques, Watch et XP préservés.')
    print('✅ Ancienne mention V5.6 dans le dossier de combat remplacée.')
except (ValueError, OSError) as error:
    print(f'❌ ARRÊT AVANT MODIFICATION : {error}', file=sys.stderr)
    sys.exit(1)
