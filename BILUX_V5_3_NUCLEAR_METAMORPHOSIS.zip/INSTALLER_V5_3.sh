#!/usr/bin/env bash
set -euo pipefail
BASE='bilux-v5.2-awakening'
DEST='bilux-v5.3-metamorphosis'
TARGET='BiluxIOS/BiluxScreens.swift'
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH="$HERE/BILUX_V5_3_NUCLEAR_METAMORPHOSIS.patch"
abort() { printf '❌ %s\n' "$*" >&2; exit 1; }
[[ -d .git && -f "$TARGET" && -f "$PATCH" ]] || abort 'Lance le script depuis la racine du depot BILUX.'
[[ "$(git branch --show-current)" == "$BASE" ]] || abort "Branche actuelle incorrecte, choisir $BASE."
[[ -z "$(git status --porcelain -- "$TARGET" BiluxIOS/Assets.xcassets)" ]] || abort 'SwiftUI ou assets deja modifies. Rien ne sera ecrase.'
git diff --cached --quiet || abort 'Modifications indexees detectees, arret par securite.'
! git show-ref --verify --quiet "refs/heads/$DEST" || abort "La branche locale $DEST existe deja."
if git ls-remote --exit-code --heads origin "$DEST" >/dev/null 2>&1; then abort "La branche distante $DEST existe deja."; fi
for folder in "$HERE"/assets/BiluxForm*.imageset; do
    name="$(basename "$folder")"
    [[ -f "$folder/Contents.json" && -f "$folder/hero.jpg" ]] || abort "Archive incomplete : $name"
    [[ ! -e "BiluxIOS/Assets.xcassets/$name" ]] || abort "L'asset $name existe deja."
done
git apply --check "$PATCH" || abort 'Patch incompatible avec le code V5.2. Ne force rien.'
git switch -c "$DEST"
git apply "$PATCH"
for folder in "$HERE"/assets/BiluxForm*.imageset; do
    cp -R "$folder" 'BiluxIOS/Assets.xcassets/'
done
git diff --check || abort 'Probleme de formatage dans le diff.'
if command -v swiftc >/dev/null 2>&1; then
    swiftc -frontend -parse BiluxIOS/*.swift BiluxWatch/*.swift BiluxShared/*.swift || abort 'Erreur syntaxique Swift.'
fi
git add -- "$TARGET" BiluxIOS/Assets.xcassets/BiluxForm*.imageset
git commit -m 'BILUX V5.3 - Portraits evolutifs et arbre de maitrise interactif'
git push -u origin "$DEST"
printf '\n✅ BILUX V5.3 sur GitHub : %s\n' "$DEST"
printf '➡️ Compiler sur Codemagic avec le workflow simulateur de la branche %s\n' "$DEST"
printf '⚠️ Ne pas publier sur TestFlight avant une validation simulateur et le passage au build 7.\n'
