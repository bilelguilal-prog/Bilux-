#!/usr/bin/env bash
set -euo pipefail
[[ "$(git branch --show-current)" == 'bilux-v5.3-metamorphosis' ]] || { echo 'Mauvaise branche : bilux-v5.3-metamorphosis requise.' >&2; exit 1; }
python3 - <<'EOF_PY_7'
from pathlib import Path
import plistlib, re
files = [Path('BiluxIOS/Info.plist'), Path('BiluxWatch/Info.plist')]
pattern = re.compile(r'(<key>CFBundleVersion</key>\s*<string>)6(</string>)')
replacements=[]
for path in files:
    text=path.read_text()
    data=plistlib.loads(path.read_bytes())
    if str(data.get('CFBundleVersion'))!='6':
        raise SystemExit(f'{path}: build 6 attendu, trouve {data.get("CFBundleVersion")!r}. Aucun changement.')
    updated,count=pattern.subn(r'\g<1>7\g<2>',text)
    if count!=1 or str(plistlib.loads(updated.encode())['CFBundleVersion'])!='7':
        raise SystemExit(f'{path}: structure inattendue. Aucun changement.')
    replacements.append((path,updated))
for path,updated in replacements:
    path.write_text(updated)
    print(f'✅ {path}: build 6 → 7')
EOF_PY_7
git diff --check
git add -- BiluxIOS/Info.plist BiluxWatch/Info.plist
git commit -m 'BILUX V5.3 - Build 7 iPhone et Watch'
git push origin bilux-v5.3-metamorphosis
