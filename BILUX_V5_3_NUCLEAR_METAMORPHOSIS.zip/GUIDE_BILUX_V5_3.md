# BILUX V5.3 — Nuclear Metamorphosis

## Nouveautés

- **Cinq portraits** : Survivant, Éveil (illustration originale inchangée), Réacteur, Nucléaire et Ascension. Seuils inchangés : niveaux 1, 3, 6, 10, 15.
- **Équiper une transformation** : seules les formes acquises sont équipables. Le choix est stocké dans les préférences de l'iPhone (`bilux.equippedTransformationID`), pas dans la sauvegarde JSON.
- **Arbre de maîtrise interactif** : quatre voies et trois nœuds reliés par voie, avec conditions et valeurs calculées depuis les vraies séances, séries, exercices et jours de saisie. Aucune dépense de points fictifs.
- **Écran cinématique de passage de niveau** : nouvel habillage du rang atteint, apparition d'un message spécifique si une transformation est débloquée.
- **Animations optionnelles** : le réglage existant et l'option « Réduire les animations » d'iOS sont respectés.

## Installation iPhone / GitHub

1. Sur GitHub, sélectionner **`bilux-v5.2-awakening`** puis `Add file → Upload files` : importer `BILUX_V5_3_NUCLEAR_METAMORPHOSIS.zip`, puis `Commit changes`.
2. Dans Codespaces, terminal ouvert à la racine du dépôt :

```bash
git switch bilux-v5.2-awakening && git pull --ff-only origin bilux-v5.2-awakening && unzip -o BILUX_V5_3_NUCLEAR_METAMORPHOSIS.zip -d /tmp/bilux-v53 && bash /tmp/bilux-v53/INSTALLER_V5_3.sh
```

3. Le script vérifie les fichiers et crée **`bilux-v5.3-metamorphosis`**. Il installe le patch, ajoute les ressources et effectue le push sur GitHub.
4. Codemagic → branche **`bilux-v5.3-metamorphosis`** → workflow **Vérifier le projet iOS (sans Apple Developer)**. **Ne pas lancer TestFlight avant que ce build simulateur soit vert.**
5. Seulement après validation : dans Codespaces `bash /tmp/bilux-v53/PREPARER_BUILD_7.sh`, puis workflow Codemagic **Publier sur TestFlight** sur la même branche. Vérifier la version **1.0 (7)** dans App Store Connect.

## Données et limites

- Le correctif modifie uniquement **`BiluxIOS/BiluxScreens.swift`** et ajoute **quatre dossiers d'images**. Il n'écrit pas dans le JSON, n'altère pas les calculs d'XP, ne modifie pas HealthKit, les séances, le code Apple Watch, les certificats et les Bundle IDs.
- Les formes futures apparaissent en aperçu, mais ne peuvent pas être équipées avant déverrouillage.
- Les visuels générés sont de nouvelles interprétations de l'avatar et peuvent différer légèrement du portrait d'origine ; l'image **Éveil** est conservée.
- Les nœuds ne sont que des jalons ludiques, sans « bonus » physique ou médical.
- `swiftc -frontend -parse` confirme la **syntaxe**, pas une compilation Apple SwiftUI. Le workflow simulateur Codemagic est indispensable.
- Avant chaque installation TestFlight, conserver le JSON actuel hors de l'application.

## Tests sur iPhone

1. Vérifier que le niveau, les XP, les séances et l'historique sont identiques à V5.2.
2. Dans Ascension, sélectionner et équiper **Survivant**, puis **Éveil** ; revenir à l'accueil et constater le changement de portrait.
3. Sélectionner **Réacteur** : aperçu mais aucun bouton « Équiper » avant le niveau 6.
4. Toucher quelques nœuds de l'arbre, vérifier le nombre de séries, séances et exercices.
5. Désactiver les animations, puis vérifier l'Apple Watch et le menu Sport.
6. Lors d'une vraie montée de niveau, vérifier l'écran cinématique ; aucune montée fictive au premier lancement.
