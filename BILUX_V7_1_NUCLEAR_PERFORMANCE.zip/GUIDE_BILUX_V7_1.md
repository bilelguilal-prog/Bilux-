# ☢️ BILUX V7.1 — NUCLEAR PERFORMANCE

**Base validée :** BILUX V7.0.1 / build **30** (QG, Forge et Nuclear Analytics).  
**Branche source :** `bilux-v7.0-nuclear-rebirth`  
**Nouvelle branche :** `bilux-v7.1-nuclear-performance`  
**Version TestFlight :** **1.0 (31)**

## Nouveautés

1. **Progression par exercice** : sélection de l'exercice, graphiques par charge maximale déclarée, répétitions totales ou volume (répétitions × kg). Périodes 30 j / 90 j / 1 an / complet, huit dernières séances représentées. Les saisies portant plusieurs fois le même nom d'exercice dans une même séance sont regroupées pour le graphique.
2. **Comparaison des deux dernières séances** pour chaque exercice : charge max, total de répétitions, volume déclaré, avec écarts en unités. Ce sont des relevés du journal, **pas** une évaluation de performance médicale ou une force maximale estimée.
3. **Célébration d'un vrai nouveau record de charge** depuis la Forge : ouverture automatique d'une petite cinématique RPG en cas d'amélioration du maximum enregistré. Bouton de fermeture et respect du réglage iOS *Réduire les animations*. Aucun nouveau bonus d'XP.
4. **Journal de l'Ascension** : première séance, jalons de nombre de séances, records de charge, victoires des boss reconstituées selon les règles du moteur V5.5 (journées de séance d'au moins 10 min, au plus 5 jours par semaine, objectifs de 12 journées/mois et 30/trimestre). Les dates de transformation **postérieures à l'ancre V5.5** sont reconstituées à partir du moteur XP existant. Les transformations obtenues avant la migration ne reçoivent pas de fausses dates.

Les nouveaux écrans sont accessibles depuis **Accueil → QG** ou **Sport → La Forge**.

## Conservation des acquis

Le correctif **ne change que** `BiluxIOS/BiluxScreens.swift`. Sont laissés intacts :

- `Models.swift`, `BiluxStore.swift`, structure du JSON, historique sportif, santé et nutrition.
- Moteur de niveaux, XP, rangs, quêtes, boss, maitrises et titres.
- HealthKit, Nuclear Live, synchronisation Watch et les complications LIVE / XP / QUÊTES.
- Le rendu de foudre cinématique V6.6 et les réglages immersifs V6.7.
- La signature Apple dans `codemagic.yaml` et les profils de distribution.

**L'historique est recalculé depuis les données actuelles**, il ne crée pas de nouvelles entrées. Modifier une ancienne séance peut donc modifier les dates de records ou de victoires **affichées** sans modifier les récompenses existantes.

**Avant installation :** dans BILUX, exporte une sauvegarde JSON vers Fichiers/iCloud privé. Ne mets jamais ce JSON sur GitHub.

## Installation depuis l'iPhone

1. Ouvre ton dépôt : https://github.com/bilelguilal-prog/Bilux-
2. Choisis `bilux-v7.0-nuclear-rebirth`.
3. **Add file → Upload files**, ajoute le fichier `BILUX_V7_1_NUCLEAR_PERFORMANCE.zip` à la racine et valide le commit.
4. Dans ton terminal Codespaces, depuis la racine du projet, colle cette commande complète :

```bash
git switch bilux-v7.0-nuclear-rebirth && git pull --ff-only origin bilux-v7.0-nuclear-rebirth && unzip -o BILUX_V7_1_NUCLEAR_PERFORMANCE.zip -d /tmp/bilux-v71 && bash /tmp/bilux-v71/INSTALLER_V7_1.sh && bash /tmp/bilux-v71/PREPARER_BUILD_31.sh
```

**Résultat :** nouvelle branche `bilux-v7.1-nuclear-performance` poussée sur GitHub, avec build **31** sur iPhone, Watch et widget. Le script refuse une base inconnue et ne remplace aucun fichier s'il ne reconnaît pas le build 30 + correctif d'initialisation V7.0.1.

### Quota Codemagic : un seul build

**N'exécute pas les deux workflows de simulateur en plus.** Nous conservons la procédure optimisée : après les vérifications locales, lancer directement **BILUX — Publier sur TestFlight**, sur `bilux-v7.1-nuclear-performance`, build 31.

Si Codemagic échoue, récupère le premier message d'erreur Xcode et corrigeons précisément le point bloquant. Ne relance pas plusieurs compilations identiques en file d'attente. Le code a passé `swiftc -frontend -parse` en local, **mais un Mac Codemagic reste nécessaire pour vérifier le typage SwiftUI**.

## Vérifications après TestFlight

- [ ] **Accueil → QG → Progression par exercice** : choisir un exercice connu, tester 30/90 jours, charge / répétitions / volume.
- [ ] Vérifier que **Dernière / Précédente** correspond aux données de deux séances réellement enregistrées pour l'exercice. Une séance avec charge 0 kg (poids de corps) compte dans les répétitions mais n'est pas un nouveau record de charge.
- [ ] **Journal de l'Ascension** : consulter événements et filtres *Tout / Records / Boss / Formes*. Les victoires passées sont reconstituées, sans XP ajouté.
- [ ] Après une vraie séance dépassant une charge de référence, vérifier la **célébration RECORD BRISÉ** et son bouton de fermeture. Ne fabrique pas de séance fictive pour la tester.
- [ ] Valider que les XP, compétences, données santé, séances historiques et sauvegardes JSON sont inchangés.
- [ ] Apple Watch : cockpit, Nuclear Live, quêtes et complications fonctionnent toujours.

**Secours :** le build 30 de la V7.0 stable reste disponible sur TestFlight. Ne supprime pas l'application iPhone pour changer de version, afin de préserver les données locales.
