#!/usr/bin/env bash
set -euo pipefail
BRANCH='bilux-v7.1-nuclear-performance'
fail(){ echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Se placer à la racine du dépôt.'
[[ "$(git branch --show-current)" == "$BRANCH" ]] || fail "Branche attendue : $BRANCH"
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications locales non commitées.'
git diff --cached --quiet || fail 'Index Git non vide.'
for marker in 'private struct V71ExercisePerformance: View' 'private struct V71AscensionChronicleView: View' 'private struct V71RecordCelebration: View'; do
  grep -qF "$marker" BiluxIOS/BiluxScreens.swift || fail "V7.1 incomplète : $marker"
done
grep -q 'V69WatchQuestsPage' BiluxWatch/WatchRootView.swift || fail 'Watch 4.1 absente.'
grep -q 'V61LiveWorkoutView().tag(5)' BiluxWatch/WatchRootView.swift || fail 'Nuclear Live absent.'
grep -q 'BILUXWatchWidgetPack' BiluxWatchWidget/NuclearLiveWidget.swift || fail 'WidgetKit absent.'
[[ -f scripts/assign_widget_signing.py ]] || fail 'Script de signature WidgetKit absent.'
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
python3 - "$TMP" <<'PY'
import sys,plistlib
from pathlib import Path
root=Path.cwd(); dest=Path(sys.argv[1]); out=[]
for rel in ('BiluxIOS/Info.plist','BiluxWatch/Info.plist','BiluxWatchWidget/Info.plist'):
    try: obj=plistlib.loads((root/rel).read_bytes())
    except Exception as exc: raise SystemExit(f'❌ Plist manquant/invalide : {rel} - {exc}')
    value=str(obj.get('CFBundleVersion'))
    if value!='30': raise SystemExit(f'❌ Build 30 attendu dans {rel}, obtenu {value}. Aucun fichier changé.')
    obj['CFBundleVersion']='31'
    p=dest/rel; p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(plistlib.dumps(obj,sort_keys=False))
rel='BiluxIOS.xcodeproj/project.pbxproj'
p=root/rel; source=p.read_text(encoding='utf-8')
if source.count('CURRENT_PROJECT_VERSION = 30;') != 2:
    raise SystemExit('❌ Xcode : exactement deux CURRENT_PROJECT_VERSION=30 attendus. Aucun fichier changé.')
if 'BiluxWatchWidget' not in source:
    raise SystemExit('❌ Extension WidgetKit introuvable dans Xcode. Aucun fichier changé.')
p=dest/rel; p.parent.mkdir(parents=True,exist_ok=True)
p.write_text(source.replace('CURRENT_PROJECT_VERSION = 30;', 'CURRENT_PROJECT_VERSION = 31;'),encoding='utf-8')
print('✅ Build 31 préparé : iPhone, Watch et widget.')
PY
FILES=(BiluxIOS/Info.plist BiluxWatch/Info.plist BiluxWatchWidget/Info.plist BiluxIOS.xcodeproj/project.pbxproj)
for rel in "${FILES[@]}"; do cp "$TMP/$rel" "$rel"; done
git add -- "${FILES[@]}"
git diff --cached --check || fail 'Diff Git invalide.'
git commit -m 'BILUX V7.1 - Build 31 iPhone Watch WidgetKit'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
  git push origin "$BRANCH" || fail "Commit local créé : relancer git push origin $BRANCH"
else
  echo '🧪 Mode test : aucun push.'
fi
echo '✅ Build 31 prêt pour un seul workflow Codemagic TestFlight.'
