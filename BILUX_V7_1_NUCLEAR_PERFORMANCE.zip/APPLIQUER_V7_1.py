#!/usr/bin/env python3
"""BILUX V7.1: additive, read-only performance screens over validated V7.0.1.

Do not modify the source repo; write one staged SwiftUI source after validation.
"""
from pathlib import Path
import sys, re, plistlib

if len(sys.argv) != 3:
    raise SystemExit('Usage: APPLIQUER_V7_1.py <repository> <staging>')
root = Path(sys.argv[1]).resolve()
stage = Path(sys.argv[2]).resolve()
base = Path(__file__).resolve().parent

def fail(reason):
    raise SystemExit('❌ ' + reason + ' ; aucun fichier du projet modifié.')

def require_once(src, old, label):
    count = src.count(old)
    if count != 1: fail(f'Base V7.0 inattendue ({label}, occurrences: {count})')
    return old

for rel in ('BiluxIOS/Info.plist', 'BiluxWatch/Info.plist', 'BiluxWatchWidget/Info.plist'):
    try:
        build = str(plistlib.loads((root/rel).read_bytes())['CFBundleVersion'])
    except Exception as e: fail(f'Plist absent/invalide {rel}: {e}')
    if build != '30': fail(f'{rel}: build 30 attendu, trouvé {build}')

# Architecture V7.0 validée : détecter la présence de tous les composants à préserver.
for rel, symbols in {
    'BiluxIOS/Models.swift': ['struct WorkoutSet:', 'struct WorkoutExercise:', 'struct WorkoutSession:', 'struct BiluxData:', 'enum BILUXV55Progression'],
    'BiluxIOS/BiluxStore.swift': ['func add(_ session: WorkoutSession)', 'var totalXP:', 'var heroLevel:'],
    'BiluxWatch/WatchRootView.swift': ['V69WatchQuestsPage', 'V61LiveWorkoutView().tag(5)'],
    'BiluxWatchWidget/NuclearLiveWidget.swift': ['BILUXWatchWidgetPack: WidgetBundle'],
}.items():
    try: content = (root/rel).read_text(encoding='utf-8')
    except Exception as e: fail(f'{rel} absent: {e}')
    for symbol in symbols:
        if symbol not in content: fail(f'{symbol} introuvable dans {rel}')
if not (root/'scripts/assign_widget_signing.py').is_file():
    fail('Script de signature du widget non trouvé')

file = root/'BiluxIOS/BiluxScreens.swift'
if not file.is_file(): fail('BiluxScreens.swift absent')
s = file.read_text(encoding='utf-8')
for symbol in ['private struct V70NuclearForge: View', 'private struct V70NuclearAnalytics: View',
               'private struct V70RebirthCommandDeck: View', 'private struct V70ForgeSportEntry: View',
               'V70PerformanceSnapshot', 'private struct BILUXV67Contemplation: View']:
    if symbol not in s: fail('Composant V7.0 / V6.7 absent : '+symbol)
if 'private struct V71ExercisePerformance: View' in s or 'NUCLEAR PERFORMANCE · V7.1' in s:
    fail('V7.1 déjà installée')
# Require verified hotfix V7.0.1 to avoid relying on the broken analytics initialization.
if 'let periodStart = calendar.date(byAdding:' not in s or 'self.sessions = workouts.filter { $0.date >= periodStart' not in s:
    fail('Correctif V7.0.1 (initialisation Analytics) non retrouvé')

# 1) Two clear entry points in existing Forge and QG, preserving their layout.
qg_start = s.index('private struct V70RebirthCommandDeck: View')
qg_end = s.index('private struct V70ForgeSportEntry: View', qg_start)
qg = s[qg_start:qg_end]
needle = '                .accessibilityIdentifier("bilux.v70.analytics.home")\n'
require_once(qg, needle, 'raccourci Analytics du QG')
qg = qg.replace(needle, needle + '''
                NavigationLink {
                    V71ExercisePerformance().environmentObject(journal)
                } label: {
                    Label("PROGRESSION PAR EXERCICE", systemImage: "chart.line.uptrend.xyaxis")
                        .font(.subheadline.weight(.heavy))
                        .frame(maxWidth: .infinity, minHeight: 42)
                }
                .buttonStyle(.bordered).tint(Nuclear.gold)

                NavigationLink {
                    V71AscensionChronicleView().environmentObject(journal)
                } label: {
                    Label("JOURNAL DE L'ASCENSION", systemImage: "book.closed.fill")
                        .font(.subheadline.weight(.heavy))
                        .frame(maxWidth: .infinity, minHeight: 42)
                }
                .buttonStyle(.bordered).tint(Nuclear.purple)
''', 1)
s = s[:qg_start] + qg + s[qg_end:]

entry_start = s.index('private struct V70ForgeSportEntry: View')
entry_end = s.index('private struct V70DraftSet:', entry_start)
entry = s[entry_start:entry_end]
needle = '                Label("VOIR LES STATISTIQUES", systemImage: "chart.bar.fill")\n'
require_once(entry, needle, 'raccourci statistiques du Sport')
anchor = '            .buttonStyle(.bordered).tint(Nuclear.purple)\n'
require_once(entry, anchor, 'bouton statistiques du Sport')
entry = entry.replace(anchor, anchor + '''            NavigationLink {
                V71ExercisePerformance().environmentObject(journal)
            } label: {
                Label("PROGRESSION PAR EXERCICE", systemImage: "chart.line.uptrend.xyaxis")
                    .font(.subheadline.bold()).frame(maxWidth: .infinity, minHeight: 42)
            }.buttonStyle(.bordered).tint(Nuclear.gold)
            NavigationLink {
                V71AscensionChronicleView().environmentObject(journal)
            } label: {
                Label("JOURNAL DE L'ASCENSION", systemImage: "book.closed.fill")
                    .font(.subheadline.bold()).frame(maxWidth: .infinity, minHeight: 42)
            }.buttonStyle(.bordered).tint(Nuclear.purple)
''', 1)
s = s[:entry_start] + entry + s[entry_end:]

# 2) Record celebration in the existing Forge only after a genuine new recorded best.
forge_start = s.index('private struct V70NuclearForge: View')
forge_end = s.index('private struct V70NuclearAnalytics: View', forge_start)
forge = s[forge_start:forge_end]
state = '    @State private var achievedRecords: [String] = []\n'
require_once(forge, state, 'records de la Forge')
forge = forge.replace(state, state + '    @State private var showRecordCelebration = false\n', 1)
anchor = '        .navigationTitle("La Forge")\n'
require_once(forge, anchor, 'navigation Forge')
forge = forge.replace(anchor, anchor + '''        .sheet(isPresented: $showRecordCelebration) {
            V71RecordCelebration(records: achievedRecords)
        }
''', 1)
anchor = '        achievedRecords = Array(Set(newRecords)).sorted()\n        saved = true\n'
require_once(forge, anchor, 'enregistrement unique des records')
forge = forge.replace(anchor, anchor + '        showRecordCelebration = !achievedRecords.isEmpty\n', 1)
s = s[:forge_start] + forge + s[forge_end:]

module = (base/'V71_NUCLEAR_PERFORMANCE.swift.txt').read_text(encoding='utf-8')
for symbol in ['private struct V71ExercisePerformance: View', 'private struct V71AscensionChronicleView: View',
               'private struct V71RecordCelebration: View']:
    require_once(module, symbol, symbol)
s = s.rstrip() + '\n' + module.rstrip() + '\n'
out = stage/'BiluxIOS/BiluxScreens.swift'
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(s, encoding='utf-8')
print('✅ BILUX V7.1 : progression, comparaisons, journal et célébration ajoutés.')
print('✅ Un seul fichier SwiftUI modifié : BiluxIOS/BiluxScreens.swift.')
print('✅ Stockage, moteur XP, Santé, Watch, WidgetKit et signatures inchangés.')
