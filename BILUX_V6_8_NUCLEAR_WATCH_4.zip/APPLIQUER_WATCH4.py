#!/usr/bin/env python3
"""BILUX V6.8 / Nuclear Watch 4.0: fail-closed staged patch on the validated build 27."""
from pathlib import Path
import plistlib
import sys

if len(sys.argv) != 3:
    raise SystemExit('Usage: python3 APPLIQUER_WATCH4.py REPO STAGING')
root = Path(sys.argv[1]).resolve()
stage = Path(sys.argv[2]).resolve()
here = Path(__file__).resolve().parent

def stop(note):
    raise SystemExit('❌ ' + note + ' ; aucune source du projet n’a été modifiée.')

def read(rel):
    p = root / rel
    if not p.is_file():
        stop('Fichier absent : ' + rel)
    return p.read_text(encoding='utf-8')

def once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        stop(f'Base inattendue ({label}) : {count} marqueur(s), 1 attendu')
    return text.replace(old, new, 1)

def output(rel, text):
    p = stage / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding='utf-8')
    print(f'✅ Préparé : {rel} ({len(text.splitlines())} lignes)')

for rel in ('BiluxIOS/Info.plist','BiluxWatch/Info.plist','BiluxWatchWidget/Info.plist'):
    try:
        version = str(plistlib.loads((root/rel).read_bytes()).get('CFBundleVersion'))
    except Exception:
        stop('Info.plist absent ou invalide : ' + rel)
    if version != '27':
        stop(f'{rel} : build 27 attendu, reçu {version}')

if not (root / 'scripts/assign_widget_signing.py').is_file():
    stop('Signature WidgetKit absente : scripts/assign_widget_signing.py')
if not (root / 'BiluxWatchWidget/NuclearLiveWidget.swift').is_file():
    stop('Extension Nuclear Live WidgetKit absente')
if 'private struct BILUXV67Contemplation: View' not in read('BiluxIOS/BiluxScreens.swift'):
    stop('Base iPhone V6.7 Nuclear Immersion introuvable')
if 'struct V63MasterySnapshot' not in read('BiluxIOS/Models.swift'):
    stop('Moteur de maîtrise V6.3 absent : ne pas dériver une progression différente')

# 1. Contract iPhone -> Watch : données RPG uniquement, tous champs optionnels.
rel = 'BiluxShared/WatchSnapshot.swift'
s = read(rel)
if 'struct WatchMasteryPath:' in s or 'masteryPaths:' in s:
    stop('Le résumé Watch Mastery existe déjà')
s = once(s, 'struct WatchSnapshot: Codable {', '''// Résumé compact, calculé exclusivement depuis le moteur V6.3 sur l'iPhone.
// Aucun dossier médical, aucune séance individuelle et aucune donnée HealthKit ajoutés.
struct WatchMasteryPath: Codable, Identifiable {
    var id: String
    var title: String
    var symbol: String
    var current: Int
    var target: Int
    var unlocked: Int
    var total: Int
    var nextTitle: String?
    var remaining: Int?
    var unit: String
}

struct WatchSnapshot: Codable {''', 'type WatchSnapshot')
s = once(s, '    var equippedAura: String? = nil\n', '''    var equippedAura: String? = nil
    // Optionnel pour relire sans migration les snapshots des anciennes versions.
    var masteryPaths: [WatchMasteryPath]? = nil
''', 'nouveau champ facultatif')
output(rel, s)

# 2. Le pont de synchronisation déjà fiable produit les 4 voies : pas de calcul d’XP Watch.
rel = 'BiluxIOS/WatchPhoneBridge.swift'
s = read(rel)
if 'masteryPaths: ' in s:
    stop('Le pont iPhone transmet déjà des voies de maîtrise')
s = once(s,
    '        let appearance = journal.map { BILUXV60WatchAppearance($0) }\n',
    '''        let appearance = journal.map { BILUXV60WatchAppearance($0) }
        let mastery = V63MasterySnapshot.evaluate(data)
        let masteryPaths: [WatchMasteryPath] = mastery.branches.map { branch in
            WatchMasteryPath(
                id: branch.id, title: branch.title, symbol: branch.icon,
                current: branch.current, target: branch.ultimateTarget,
                unlocked: branch.unlockedCount, total: branch.nodes.count,
                nextTitle: branch.next?.title, remaining: branch.next?.remaining,
                unit: branch.unit
            )
        }
''', 'évaluation des compétences iPhone')
s = once(s,
    '            equippedAura: appearance?.aura\n',
    '            equippedAura: appearance?.aura,\n            masteryPaths: masteryPaths\n',
    'ajout aux champs du résumé Watch')
output(rel, s)

# 3. Interface Watch : aucune modification du moteur Nuclear Live ni des tags existants.
rel = 'BiluxWatch/WatchRootView.swift'
s = read(rel)
if 'V68WatchDashboard' in s:
    stop('Interface Watch 4.0 déjà installée')
for marker in ('REBIRTH · WATCH 3.0',
               'V61LiveWorkoutView().tag(5)',
               'V62CardiacZone',
               '.onOpenURL { url in',
               'selectedPage = 5'):
    if marker not in s:
        stop('Base Watch V6.2 / widget incompatible : ' + marker)
s = once(s,
    '            commandPage.tag(0)\n',
    '            V68WatchDashboard(selectedPage: $selectedPage).tag(0)\n',
    'nouvel écran principal Watch 4.0')
s = once(s,
    '            V61LiveWorkoutView().tag(5)\n',
    '            V61LiveWorkoutView().tag(5)\n            V68WatchMasteryPage().tag(6)\n',
    'onglet maîtrise après Nuclear Live (conservation tag 5)')
ui = (here / 'WATCH4_UI.swift.txt').read_text(encoding='utf-8')
for marker in ('private struct V68WatchDashboard: View',
               'private struct V68WatchMasteryPage: View',
               'private struct V68ReactorCore: View'):
    if marker not in ui: stop('Fichier d’interface incomplet : ' + marker)
s = s.rstrip() + '\n' + ui.rstrip() + '\n'
output(rel, s)
print('✅ V6.8 préparée hors dépôt : XP, Live, widget, signature, Santé inchangés.')
