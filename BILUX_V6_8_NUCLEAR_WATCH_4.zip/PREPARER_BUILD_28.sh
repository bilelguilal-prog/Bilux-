#!/usr/bin/env bash
set -euo pipefail
BRANCH='bilux-v6.8-nuclear-watch4'
fail() { echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Se placer à la racine du dépôt.'
[[ "$(git branch --show-current)" == "$BRANCH" ]] || fail "Branche attendue : $BRANCH"
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Fichiers suivis modifiés.'
git diff --cached --quiet || fail 'Index Git non vide.'
grep -q 'private struct V68WatchDashboard: View' BiluxWatch/WatchRootView.swift || fail 'Interface Watch 4.0 absente.'
grep -q 'private struct V68WatchMasteryPage: View' BiluxWatch/WatchRootView.swift || fail 'Page de maîtrise absente.'
grep -q 'V61LiveWorkoutView().tag(5)' BiluxWatch/WatchRootView.swift || fail 'Nuclear Live absent.'
grep -q 'masteryPaths: masteryPaths' BiluxIOS/WatchPhoneBridge.swift || fail 'Synchronisation RPG absente.'
[[ -f scripts/assign_widget_signing.py ]] || fail 'Signature WidgetKit absente.'
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
python3 - "$TMP" <<'PY'
from pathlib import Path
import plistlib,sys
root=Path.cwd();dest=Path(sys.argv[1])
for rel in ('BiluxIOS/Info.plist','BiluxWatch/Info.plist','BiluxWatchWidget/Info.plist'):
    try: p=plistlib.loads((root/rel).read_bytes())
    except Exception as exc:raise SystemExit(f'❌ Plist invalide {rel}: {exc}')
    if str(p.get('CFBundleVersion'))!='27':
        raise SystemExit(f'❌ Version 27 requise dans {rel}, aucune modification.')
    p['CFBundleVersion']='28'
    out=dest/rel;out.parent.mkdir(parents=True,exist_ok=True)
    out.write_bytes(plistlib.dumps(p,sort_keys=False))
p=(root/'BiluxIOS.xcodeproj/project.pbxproj')
s=p.read_text()
if s.count('CURRENT_PROJECT_VERSION = 27;')!=2 or 'BiluxWatchWidget' not in s:
    raise SystemExit('❌ Configuration Xcode inattendue ; aucune modification.')
out=dest/'BiluxIOS.xcodeproj/project.pbxproj';out.parent.mkdir(parents=True,exist_ok=True)
out.write_text(s.replace('CURRENT_PROJECT_VERSION = 27;','CURRENT_PROJECT_VERSION = 28;'))
print('✅ Build 28 préparé : iPhone + Watch + Widget, sans changer les profils Apple.')
PY
FILES=(BiluxIOS/Info.plist BiluxWatch/Info.plist BiluxWatchWidget/Info.plist BiluxIOS.xcodeproj/project.pbxproj)
for rel in "${FILES[@]}"; do cp "$TMP/$rel" "$rel"; done
git add -- "${FILES[@]}"
git diff --cached --check || fail 'Diff invalide.'
git commit -m 'BILUX V6.8 - Build 28 iPhone Watch WidgetKit'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
  git push origin "$BRANCH" || fail 'Commit local enregistré ; relancer git push.'
else
  echo '🧪 Simulation : push désactivé.'
fi
echo '✅ Build 28 prêt. Publication TestFlight après validations Codemagic.'
