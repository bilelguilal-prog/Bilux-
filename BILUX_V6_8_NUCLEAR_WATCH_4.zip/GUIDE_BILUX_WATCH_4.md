# ☢️ BILUX V6.8 — NUCLEAR WATCH 4.0

**Base de départ :** `bilux-v6.7-nuclear-immersion` — **build 27**, validé sur TestFlight.  
**Nouvelle branche créée :** `bilux-v6.8-nuclear-watch4`.  
**Prochain TestFlight :** **build 28**, après les deux compilations Codemagic de vérification.

## Nouveautés

1. **Accueil Watch 4.0** : réacteur RPG vectoriel à progression XP, niveau, rang, total XP et XP restants ; titre équipé et progression de maîtrise. Une animation discrète du réacteur respecte **Réduire les animations**.
2. **Accès direct aux fonctions existantes** : **NUCLEAR LIVE**, **MAÎTRISES**, **GARDIENS** et **FORGE MANUELLE**. Le widget ⚡ LIVE garde son lien profond vers la **page 5** de Nuclear Live ; aucun lancement automatique d'une séance HealthKit.
3. **Page des quatre voies** : Force, Endurance, Régularité, Maîtrise. Pour chacune : jauge, capacités acquises (sur trois), progression vers le prochain objectif. Les 12 capacités sont calculées sur l'iPhone avec le moteur V6.3 **déjà installé**.
4. **Compatibilité des anciennes données** : le résumé Watch reçoit un champ optionnel `masteryPaths`, sans nouvelle permission ni modification du journal JSON. Les caches Watch existants restent décodables.

**Inchangés :** iPhone, XP et niveau, séances HealthKit, alertes de zones cardiaques, rapports Nuclear Live, widget, profils de signature et progression des boss. Aucune donnée de santé sensible ajoutée au résumé RPG de la montre.

## Étape 0 — Sauvegarde

Dans BILUX iPhone, exporte ta sauvegarde JSON dans Fichiers/iCloud privé. **Ne publie pas** ce fichier sur GitHub : il contient des informations personnelles.

## Étape 1 — Déposer le ZIP depuis ton iPhone

1. Va sur https://github.com/bilelguilal-prog/Bilux-
2. Choisis la branche **`bilux-v6.7-nuclear-immersion`**.
3. **Add file → Upload files** : envoie **`BILUX_V6_8_NUCLEAR_WATCH_4.zip`** à la racine du dépôt.
4. Valide le commit GitHub.

## Étape 2 — Installer depuis Codespaces

Sur https://glorious-bassoon-xr4p9p5w4wwjfqx.github.dev, ouvre le terminal à la racine du projet et colle :

```bash
git switch bilux-v6.7-nuclear-immersion && git pull --ff-only origin bilux-v6.7-nuclear-immersion && unzip -o BILUX_V6_8_NUCLEAR_WATCH_4.zip -d /tmp/bilux-watch4 && bash /tmp/bilux-watch4/INSTALLER_WATCH4.sh
```

L'installateur :
- Vérifie la branche, la version 27 sur iPhone/Watch/widget, les moteurs V6.3/V6.7, les fichiers du widget et les profils existants.
- Prépare en mémoire temporaire uniquement :
  - `BiluxShared/WatchSnapshot.swift` ;
  - `BiluxIOS/WatchPhoneBridge.swift` ;
  - `BiluxWatch/WatchRootView.swift`.
- Vérifie la syntaxe Swift si `swiftc` est disponible.
- Crée la branche **`bilux-v6.8-nuclear-watch4`**, commit et pousse les changements.

Si un message rouge apparaît, **ne force pas le script** : transmets la première erreur.

## Étape 3 — Vérifier iPhone et Apple Watch dans Codemagic

Sur la branche `bilux-v6.8-nuclear-watch4`, lance les workflows existants sans signature :

1. **BILUX — Vérifier le projet iOS** ;
2. **BILUX V4.1 — Vérifier Apple Watch**.

**Il faut deux résultats verts avant de préparer TestFlight.** L'analyse syntaxique locale ne remplace pas la compilation et le typage Xcode (SwiftUI, WatchConnectivity, watchOS).

## Étape 4 — Préparer le build 28

Quand les deux tests sont verts, dans Codespaces colle :

```bash
bash /tmp/bilux-watch4/PREPARER_BUILD_28.sh
```

Cette commande contrôle à nouveau la branche puis prépare les trois cibles iPhone/Watch/WidgetKit **27 → 28**, et les deux valeurs `CURRENT_PROJECT_VERSION` du projet Xcode. La configuration des certificats n'est pas changée.

Dans Codemagic, sélectionne ensuite **BILUX — Publier sur TestFlight** et la branche `bilux-v6.8-nuclear-watch4`. Après traitement par Apple, installe la version **1.0 (28)** depuis TestFlight, puis vérifie que l'app Watch a également été mise à jour.

## Étape 5 — Tests sur Apple Watch Series 10

1. Ouvre BILUX sur la Watch. L'accueil doit montrer **WATCH 4.0**, le réacteur animé, le niveau et les XP **identiques à l'iPhone**.
2. Touche **MAÎTRISES** : les quatre voies sont affichées. Compare au moins une capacité débloquée et son prochain seuil avec **BILUX iPhone → Ascension → Arbre de maîtrise**.
3. Touche **NUCLEAR LIVE** : l'écran d'entraînement apparaît mais **aucune séance ne démarre automatiquement**. Vérifie les réglages de zones cardiaques, puis reviens.
4. Touche **GARDIENS** et **FORGE MANUELLE**, puis reviens à l'accueil.
5. Touche **Actualiser**, après avoir ouvert BILUX sur l'iPhone. Si les maîtrises affichent « en attente », laisse les deux appareils connectés et relance une synchronisation.
6. Teste la complication **⚡ LIVE** depuis le cadran : elle doit encore ouvrir la **page Nuclear Live**.
7. Ferme puis rouvre les deux apps : les XP, les capacités, le widget et Nuclear Live doivent rester cohérents. Le nouveau tableau de bord ne doit créer **ni séance ni XP**.
8. Dans les réglages d'accessibilité watchOS, active **Réduire les animations** : le réacteur reste lisible et cesse de pulser.

## Sécurité et limitations

- Pas de nouveau transfert d'images, ni de dossiers médicaux vers la montre.
- Les valeurs RPG reflètent **des entrées consignées**, pas la force ou l'endurance médicale réelle.
- L'accalmie visuelle sur la montre est volontaire pour préserver la lisibilité et la batterie ; les effets d'orage cinématiques restent sur l'iPhone.
- Garde le **build 27 V6.7** comme version de secours tant que le build 28 n'a pas été validé.

**Tests effectués localement** : installation sur dépôt test, création branche/commit, vérification syntaxique Swift, typecheck Foundation des modèles, test Codable ancien/nouveau snapshot, préparation cohérente des trois numéros de build. **Non effectué** : compilation Xcode sur macOS, exécution réelle sur Apple Watch (à confirmer sur Codemagic/TestFlight).
