#!/usr/bin/env bash
set -euo pipefail
BASE='bilux-v6.7-nuclear-immersion'
BRANCH='bilux-v6.8-nuclear-watch4'
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail() { echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Se placer à la racine de BILUX.'
[[ "$(git branch --show-current)" == "$BASE" ]] || fail "Branche attendue : $BASE"
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Fichiers suivis modifiés : sauvegarder avant de continuer.'
git diff --cached --quiet || fail 'Index Git non vide.'
! git show-ref --quiet --verify "refs/heads/$BRANCH" || fail "Branche $BRANCH déjà présente."
command -v python3 >/dev/null || fail 'Python 3 absent.'
git var GIT_AUTHOR_IDENT >/dev/null 2>&1 || fail 'Identité Git non configurée.'
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
python3 "$HERE/APPLIQUER_WATCH4.py" "$(pwd)" "$TMP" || fail 'Base inattendue ; rien modifié.'
FILES=(BiluxShared/WatchSnapshot.swift BiluxIOS/WatchPhoneBridge.swift BiluxWatch/WatchRootView.swift)
for path in "${FILES[@]}"; do [[ -s "$TMP/$path" ]] || fail "Fichier préparé absent : $path"; done
if command -v swiftc >/dev/null 2>&1; then
  swiftc -frontend -parse "${FILES[@]/#/$TMP/}" || fail 'Analyse syntaxique Swift échouée ; aucun fichier original modifié.'
  echo '✅ Syntaxe Swift validée (compilation Xcode requise sur Codemagic).'
else
  echo 'ℹ️ Swift non disponible dans Codespaces : compilations Codemagic obligatoires.'
fi
git switch -c "$BRANCH"
for path in "${FILES[@]}"; do cp "$TMP/$path" "$path"; done
git add -- "${FILES[@]}"
git diff --cached --check || fail 'Diff Git invalide.'
git commit -m 'BILUX V6.8 - Nuclear Watch 4.0 RPG dashboard and mastery'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
  git push -u origin "$BRANCH" || fail "Commit local enregistré ; reprendre : git push -u origin $BRANCH"
else
  echo '🧪 Simulation : push désactivé.'
fi
echo "✅ Nuclear Watch 4.0 installée sur $BRANCH. Tester iOS et watchOS avant le build 28."
