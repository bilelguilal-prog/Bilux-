#!/usr/bin/env bash
set -euo pipefail
BASE='bilux-v5.3.2-slow-aura'
[[ "$(git branch --show-current)" == "$BASE" ]] || { echo '❌ La branche V5.3.2 est requise.' >&2; exit 1; }
git diff --cached --quiet || { echo '❌ Modifications indexees : arret de securite.' >&2; exit 1; }
[[ -z "$(git status --porcelain -- BiluxIOS/Info.plist BiluxWatch/Info.plist)" ]] || { echo '❌ Info.plist modifie : arret de securite.' >&2; exit 1; }
python3 - <<'PYPLIST'
from pathlib import Path
import re, plistlib
files=[Path('BiluxIOS/Info.plist'),Path('BiluxWatch/Info.plist')]
updates=[]
pat=re.compile(r'(<key>CFBundleVersion</key>\s*<string>)8(</string>)')
for path in files:
    src=path.read_text()
    info=plistlib.loads(src.encode())
    if str(info.get('CFBundleVersion'))!='8':
        raise SystemExit(f"❌ {path}: build 8 attendu, trouve {info.get('CFBundleVersion')}. Aucun fichier modifie.")
    result,count=pat.subn(r'\g<1>9\g<2>',src)
    if count!=1 or str(plistlib.loads(result.encode())['CFBundleVersion'])!='9':
        raise SystemExit(f'❌ Structure inattendue : {path}. Aucun fichier modifie.')
    updates.append((path,result))
for path,result in updates:
    path.write_text(result)
    print(f'✅ {path}: build 8 → 9')
PYPLIST
git diff --check
git add -- BiluxIOS/Info.plist BiluxWatch/Info.plist
git commit -m 'BILUX V5.3.2 - Build 9 iPhone et Watch'
git push origin "$BASE"
