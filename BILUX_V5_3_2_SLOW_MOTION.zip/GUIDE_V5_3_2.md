# BILUX V5.3.2 — Nuclear Slow Motion

## Pourquoi ce correctif ?

L'enregistrement du 14 novembre 2026 montre que l'avatar reste au rang **Éveil**, tandis que la luminosité de l'aura varie trop rapidement. Il s'agit surtout de l'effet pulsant, et non d'un changement de rang. La correction conserve les dimensions fixes introduites en V5.3.1.

## Changements exacts

- Pulsation du halo : **2,6 → 6,5 s** par aller (cycle complet environ 13 s).
- Arc lumineux : **3,2 → 8,0 s** par aller (cycle complet environ 16 s).
- Pulsation de la vignette d'accueil : **2,5 → 6,5 s** par aller.
- Fondu entre deux portraits de rang : **0,55 → 1,8 s**.
- Nettoyage de la couche sortante après **2,0 s** (au lieu de 0,65 s).

Les effets restent inactifs si « Animations nucléaires » est désactivé ou si « Réduire les animations » d'iOS est activé. Aucun changement aux sauvegardes, aux XP, au modèle de données, aux statistiques ou à watchOS.

## Installation depuis l'iPhone

1. Dans GitHub, sur la branche `bilux-v5.3.1-avatar-fix`, importer le ZIP `BILUX_V5_3_2_SLOW_MOTION.zip` via **Add file → Upload files** puis **Commit changes**.
2. Dans Codespaces, lancer depuis la racine du dépôt :

```bash
git switch bilux-v5.3.1-avatar-fix && git pull --ff-only origin bilux-v5.3.1-avatar-fix && unzip -o BILUX_V5_3_2_SLOW_MOTION.zip -d /tmp/bilux-v532 && bash /tmp/bilux-v532/INSTALLER_V5_3_2.sh
```

3. Codemagic → `bilux-v5.3.2-slow-aura` → **BILUX — Vérifier le projet iOS (sans Apple Developer)**.
4. Si le build est vert, Codespaces :

```bash
bash /tmp/bilux-v532/PREPARER_BUILD_9.sh
```

5. Codemagic → même branche → **Publier sur TestFlight** → vérifier la version `1.0 (9)` dans App Store Connect.

Ne pas lancer directement TestFlight avant le test simulateur.
