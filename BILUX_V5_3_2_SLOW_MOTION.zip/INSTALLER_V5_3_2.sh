#!/usr/bin/env bash
set -euo pipefail
BASE='bilux-v5.3.1-avatar-fix'
DEST='bilux-v5.3.2-slow-aura'
TARGET='BiluxIOS/BiluxScreens.swift'
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH="$HERE/BILUX_V5_3_2_SLOW_AURA.patch"
abort() { printf '❌ %s\n' "$*" >&2; exit 1; }
[[ -d .git && -f "$TARGET" && -f "$PATCH" ]] || abort 'Lance le script depuis la racine du dépôt BILUX.'
[[ "$(git branch --show-current)" == "$BASE" ]] || abort "Branche attendue : $BASE."
[[ -z "$(git status --porcelain -- "$TARGET")" ]] || abort "Modifications locales sur $TARGET : arret sans ecraser."
git diff --cached --quiet || abort 'Modifications indexées détectées : arret de securite.'
! git show-ref --verify --quiet "refs/heads/$DEST" || abort "Branche locale $DEST deja existante."
if git ls-remote --exit-code --heads origin "$DEST" >/dev/null 2>&1; then
    abort "Branche distante $DEST deja existante."
fi
git apply --check "$PATCH" || abort 'Le fichier source ne correspond pas au build 8 de la V5.3.1. Aucune modification effectuee.'
git switch -c "$DEST"
git apply "$PATCH"
git diff --check || abort 'Format du correctif invalide.'
if command -v swiftc >/dev/null 2>&1; then
    swiftc -frontend -parse "$TARGET" || abort 'Erreur de syntaxe Swift.'
fi
git add -- "$TARGET"
git commit -m 'BILUX V5.3.2 - Slow down avatar aura and transitions'
git push -u origin "$DEST"
printf '\n✅ V5.3.2 appliquee sur GitHub, branche : %s\n' "$DEST"
printf '➡️ Codemagic : verifier le projet iOS sans signature. Puis preparer le build 9.\n'
