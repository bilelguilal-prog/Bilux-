# ⚡ BILUX V6.6 — CINEMATIC STORM

**Objectif :** ralentir et clarifier la foudre du mode **Épique ⚡**. Cette version est un correctif ciblé de la V6.5 *Thunder Depth*, pas un nouveau rendu 3D et pas un changement du modèle de données.

**Base requise :** branche `bilux-v6.5-thunder-depth` **build 25**.

**Nouvelle branche :** `bilux-v6.6-cinematic-storm`.

**Prochain build TestFlight :** **26**, seulement après deux compilations Codemagic vertes.

## 1. Ce que change cette version

- En mode **Épique**, une rafale dure environ **2,18 secondes**. Elle contient **trois décharges principales maximum au total** (deux derrière et une devant), réparties dans le temps. Les décharges durent environ **0,73 seconde** et laissent une accalmie notable après la rafale.
- Chaque éclair conserve sa trajectoire pendant sa durée de vie : fin du clignotement permanent et des changements de forme trop rapides.
- Plus de branches limitées à deux par éclair principal et une onde de réacteur faible et **rare** (environ toutes les cinq rafales), plutôt que des cercles permanents.
- Le mode **Équilibré** reste disponible et plus calme : deux décharges principales par cycle d'environ 3,05 secondes.
- Les deux plans avant/arrière, le détourage **Apple Vision**, les couleurs liées aux maîtrises et la désactivation des effets restent en place. L'option iOS « Réduire les animations » reste respectée.
- **Aucun changement** à la progression niveau/XP, l'arbre de maîtrise, le suivi des séances, Apple Santé, Nuclear Live, les données JSON, la Watch ou son widget.

**Important :** les valeurs sont les paramètres programmés du moteur d'animation et non une fréquence d'éclairs mesurée dans une compilation iOS. Les effets restent simulés en 2D avec occlusion de silhouette, pas en 3D réelle.

## 2. Sauvegarde avant mise à jour

Dans BILUX, exporte ton journal au format JSON et garde-le en privé dans Fichiers ou iCloud. Ne téléverse jamais les données de Santé personnelles dans le dépôt GitHub.

## 3. Déposer le correctif sur GitHub depuis l'iPhone

1. Ouvre : https://github.com/bilelguilal-prog/Bilux-
2. Sélectionne la branche **`bilux-v6.5-thunder-depth`**.
3. Appuie sur **Add file → Upload files** et dépose **`BILUX_V6_6_CINEMATIC_STORM.zip`** à la racine du dépôt.
4. Valide le commit de ce ZIP.

## 4. Installation depuis Codespaces

Dans le terminal **à la racine du dépôt**, colle cette commande :

```bash
git switch bilux-v6.5-thunder-depth && git pull --ff-only origin bilux-v6.5-thunder-depth && unzip -o BILUX_V6_6_CINEMATIC_STORM.zip -d /tmp/bilux-v66 && bash /tmp/bilux-v66/INSTALLER_V6_6.sh
```

L'installateur :
- vérifie le **build 25** dans les trois `Info.plist` ;
- vérifie les moteurs V6.5 et V6.3 et la signature du widget ;
- prépare la modification dans un dossier temporaire et passe une vérification de syntaxe Swift si `swiftc` est installé ;
- crée **`bilux-v6.6-cinematic-storm`**, ne modifie que `BiluxIOS/BiluxScreens.swift`, valide le commit puis tente de pousser la branche sur GitHub.

Si le script refuse de s'exécuter, **lis le message d'erreur au lieu de forcer les modifications**. Ne lance pas les scripts d'une ancienne version.

## 5. Les deux tests Codemagic obligatoires

Sur **`bilux-v6.6-cinematic-storm`**, lance ces workflows en compilation *sans signature* :

1. **BILUX — Vérifier le projet iOS**.
2. **BILUX V4.1 — Vérifier Apple Watch**.

Les deux doivent être verts avant de préparer le build. La vérification syntaxique locale n'est **pas** une compilation Xcode.

## 6. Préparer le build 26 et publier sur TestFlight

Si et **seulement si** les deux compilations sont vertes, exécute dans Codespaces :

```bash
bash /tmp/bilux-v66/PREPARER_BUILD_26.sh
```

Cette commande met à jour les trois `Info.plist` et les deux réglages `CURRENT_PROJECT_VERSION` du projet Xcode de **25 à 26**, puis crée/pousse un commit sur la branche V6.6.

Dans Codemagic, lance ensuite **BILUX — Publier sur TestFlight** sur `bilux-v6.6-cinematic-storm`. Vérifie la présence de la version **1.0 (26)** dans TestFlight après traitement par Apple.

## 7. Validation artistique sur iPhone

Après la mise à jour via TestFlight :

1. Va dans **Ascension**, ouvre les **réglages des effets**, sélectionne **Épique ⚡**.
2. Regarde le portrait pendant **15 à 20 secondes**. Les décharges doivent être **identifiables individuellement**, non dessinées partout en continu.
3. Observe **un enchaînement de trois frappes principales**, puis un temps d'accalmie. Une décharge doit conserver sa forme le temps de son apparition.
4. Vérifie que la silhouette n'est pas masquée et que le rendu avant/arrière de la V6.5 est conservé quand Vision arrive à détourer le sujet.
5. Compare avec **Équilibré**, puis coupe/réactive **Animations nucléaires**.
6. Vérifie que ton **XP, niveau, arbre de maîtrise, Nuclear Live, journal et complication Watch** sont toujours présents.
7. Envoie une courte vidéo du mode **Épique** pour ajuster la puissance et la profondeur si nécessaire.

## Base de secours

Garde **V6.5 — Build 25** accessible dans TestFlight jusqu'à validation du build 26. La V6.6 ne modifie pas le format du journal, et le script n'a aucune instruction qui efface des données, mais une sauvegarde privée reste prudente.
