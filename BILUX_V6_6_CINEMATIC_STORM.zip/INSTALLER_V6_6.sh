#!/usr/bin/env bash
set -euo pipefail
BASE='bilux-v6.5-thunder-depth'
NEW='bilux-v6.6-cinematic-storm'
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail() { echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Se placer à la racine du dépôt BILUX.'
[[ "$(git branch --show-current)" == "$BASE" ]] || fail "Branche de départ attendue : $BASE"
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications Git suivies non enregistrées : sauvegarder avant de continuer.'
git diff --cached --quiet || fail 'Index Git non vide.'
! git show-ref --quiet --verify "refs/heads/$NEW" || fail "La branche $NEW existe déjà."
command -v python3 >/dev/null || fail 'Python 3 introuvable.'
git var GIT_AUTHOR_IDENT >/dev/null 2>&1 || fail 'Identité Git non configurée.'
TEMP="$(mktemp -d)"; trap 'rm -rf "$TEMP"' EXIT
python3 "$HERE/APPLIQUER_V6_6.py" "$(pwd)" "$TEMP" || fail 'Source incompatible, aucune modification appliquée.'
[[ -s "$TEMP/BiluxIOS/BiluxScreens.swift" ]] || fail 'Source V6.6 générée absente.'
if command -v swiftc >/dev/null 2>&1; then
    swiftc -frontend -parse "$TEMP/BiluxIOS/BiluxScreens.swift" BiluxIOS/Models.swift || fail 'Syntaxe Swift invalide : aucun fichier du projet modifié.'
    echo '✅ Syntaxe Swift vérifiée. Compilation Xcode réelle requise sur Codemagic.'
else
    echo 'ℹ️ Swift non installé ici. Vérification Xcode obligatoire sur Codemagic.'
fi
git switch -c "$NEW"
cp "$TEMP/BiluxIOS/BiluxScreens.swift" BiluxIOS/BiluxScreens.swift
git add -- BiluxIOS/BiluxScreens.swift
git diff --cached --check || fail 'Diff Git invalide.'
git commit -m 'BILUX V6.6 - cinematic lightning rhythm and legibility'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
    git push -u origin "$NEW" || fail "Commit local enregistré. Réessayer : git push -u origin $NEW"
else
    echo '🧪 Test local : push désactivé.'
fi
echo "✅ V6.6 installée sur $NEW. Lancer deux compilations Codemagic AVANT le build 26."
