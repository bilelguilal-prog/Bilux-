#!/usr/bin/env python3
"""Stage BILUX V6.5 build 25 -> V6.6 cinematic storm without changing user data."""
from pathlib import Path
import plistlib
import sys

if len(sys.argv) != 3:
    raise SystemExit('Usage: APPLIQUER_V6_6.py REPO TEMP')
repo, dest = [Path(x).resolve() for x in sys.argv[1:]]
here = Path(__file__).resolve().parent

def fail(message):
    raise SystemExit('❌ ' + message + ' — aucun fichier source modifié')

def replace_exact(source, before, after, name):
    count = source.count(before)
    if count != 1:
        fail(f'{name}: 1 occurrence attendue, {count} trouvée(s)')
    return source.replace(before, after, 1)

# Fail closed against the wrong branch, older builds, or a half-applied fix.
for relative in ('BiluxIOS/Info.plist', 'BiluxWatch/Info.plist',
                 'BiluxWatchWidget/Info.plist'):
    try:
        version = plistlib.loads((repo / relative).read_bytes())['CFBundleVersion']
    except Exception as error:
        fail(f'{relative} indisponible : {error}')
    if str(version) != '25':
        fail(f'Build 25 attendu pour {relative}, reçu {version}')
if not (repo/'scripts/assign_widget_signing.py').is_file():
    fail('Correctif de signature WidgetKit absent')
if not (repo/'BiluxWatchWidget/NuclearLiveWidget.swift').is_file():
    fail('Widget Apple Watch absent')
source_file = repo/'BiluxIOS/BiluxScreens.swift'
model_file = repo/'BiluxIOS/Models.swift'
if not (source_file.is_file() and model_file.is_file()):
    fail('Sources iPhone absentes')
source = source_file.read_text('utf-8')
if 'private static func cinematicEnvelope(' in source:
    fail('V6.6 déjà appliquée')
for marker in ('private enum V65ThunderRenderer {',
               'private struct V65DepthCompositing: View',
               'private struct V63NuclearMasteryView: View',
               'private struct V65DepthLightning: View',
               'Text("THUNDER DEPTH · V6.5")'):
    if source.count(marker) != 1:
        fail(f'Version de départ incompatible : {marker}')
if 'struct NuclearLiveReport:' not in model_file.read_text('utf-8'):
    fail('Nuclear Live absent du modèle')

start = source.index('    static func draw(', source.index('private enum V65ThunderRenderer {'))
end_marker = '\n}\n\n// Composite in ORIGINAL artwork coordinates;'
end = source.index(end_marker, start)
original_method = source[start:end]
for marker in ('let cadence = epic ? 2.4 : 1.7',
               'for index in 0..<count {',
               'let waveTime = time * (epic ? 1.38 : 0.94)'):
    if marker not in original_method:
        fail(f'Ancien moteur V6.5 incompatible : {marker}')
replacement = (here/'CINEMATIC_ENGINE_V66.swift.txt').read_text('utf-8').rstrip('\n')
source = source[:start] + replacement + source[end:]
source = replace_exact(source, 'Text("THUNDER DEPTH · V6.5")',
                       'Text("CINEMATIC STORM · V6.6")', 'Libellé de version')
source = replace_exact(
    source,
    'Text("Foudre d\'orage en profondeur : derrière la silhouette, autour du réacteur, puis quelques décharges devant. Détourage automatique sur l\'iPhone avec Apple Vision (si détectable), sans transfert de photo. Mode Épique par défaut. Aucun effet sur les XP.")',
    'Text("Mode Épique cinématique : trois décharges principales au maximum par rafale, environ 0,7 seconde de présence et de vraies accalmies. La foudre reste derrière ou devant la silhouette grâce au détourage Apple Vision lorsque disponible. Aucun bonus d’XP.")',
    'Texte des réglages')

dest_file = dest/'BiluxIOS/BiluxScreens.swift'
dest_file.parent.mkdir(parents=True, exist_ok=True)
dest_file.write_text(source, 'utf-8')
print('✅ BILUX V6.6 : rafales cinématiques, trajectoires stables, pauses visibles.')
print('✅ Détourage Vision V6.5, progression, Watch, HealthKit et JSON préservés.')
