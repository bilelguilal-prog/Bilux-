#!/usr/bin/env bash
set -euo pipefail
BRANCH='bilux-v5.7-nuclear-awakening'
[[ "$(git branch --show-current)" == "$BRANCH" ]] || { echo "❌ Branche $BRANCH attendue." >&2; exit 1; }
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || { echo '❌ Des fichiers suivis sont modifiés.' >&2; exit 1; }
python3 - <<'PY'
from pathlib import Path
import plistlib
files=[Path('BiluxIOS/Info.plist'),Path('BiluxWatch/Info.plist')]
originals={}
for f in files:
    if not f.is_file(): raise SystemExit(f'❌ {f} introuvable')
    originals[f]=f.read_bytes()
    old=plistlib.loads(originals[f]).get('CFBundleVersion')
    if str(old) != '12': raise SystemExit(f'❌ {f} : build 12 attendu, trouvé {old}. Aucun fichier modifié.')
for f in files:
    obj=plistlib.loads(originals[f])
    obj['CFBundleVersion']='13'
    f.write_bytes(plistlib.dumps(obj,fmt=plistlib.FMT_XML,sort_keys=False))
    print(f'✅ {f}: build 12 → 13')
PY
git add -- BiluxIOS/Info.plist BiluxWatch/Info.plist
git diff --cached --check
git commit -m 'BILUX V5.7 - TestFlight build 13'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
  git push -u origin "$BRANCH"
else
  echo '🧪 Mode test : aucun push vers GitHub.'
fi
echo '✅ Build 13 préparé. Workflow TestFlight disponible.'
