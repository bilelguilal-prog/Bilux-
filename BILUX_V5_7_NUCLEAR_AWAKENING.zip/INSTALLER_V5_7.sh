#!/usr/bin/env bash
set -euo pipefail
BASE='bilux-v5.6-arene-des-gardiens'
DEST='bilux-v5.7-nuclear-awakening'
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail(){ echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Exécute ce script à la racine du dépôt BILUX.'
[[ "$(git branch --show-current)" == "$BASE" ]] || fail "Branche attendue : $BASE"
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Des fichiers suivis sont modifiés : commit ou sauvegarde avant installation.'
! git show-ref --verify --quiet "refs/heads/$DEST" || fail "La branche $DEST existe déjà."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
python3 "$HERE/APPLIQUER_V5_7.py" "$(pwd)" "$TMP/staged" || fail 'Base incompatible : aucun fichier BILUX modifié.'
if command -v swiftc >/dev/null 2>&1; then
  swiftc -frontend -parse "$TMP/staged/BiluxIOS/BiluxScreens.swift" || fail 'Syntaxe Swift invalide : projet non modifié.'
  echo '✅ Syntaxe Swift validée (vraie compilation SwiftUI à faire dans Codemagic).'
else
  echo 'ℹ️ swiftc absent : validation du code prévue dans Codemagic.'
fi
python3 - "$TMP/staged" <<'PY'
import json,sys
from pathlib import Path
stage=Path(sys.argv[1]); assets=stage/'BiluxIOS/Assets.xcassets'
for name in ('BILUXBossGuardian','BILUXBossSovereign'):
    d=assets/f'{name}.imageset'
    manifest=json.loads((d/'Contents.json').read_text())
    assert (d/manifest['images'][0]['filename']).stat().st_size>50_000
print('✅ Deux images de boss valides et référencées dans le catalogue iOS.')
PY
# The only modified sources are a single UI file and two new imagesets.
git switch -c "$DEST"
cp "$TMP/staged/BiluxIOS/BiluxScreens.swift" BiluxIOS/BiluxScreens.swift
for name in BILUXBossGuardian BILUXBossSovereign; do
    cp -R "$TMP/staged/BiluxIOS/Assets.xcassets/$name.imageset" "BiluxIOS/Assets.xcassets/$name.imageset"
done
git add -- BiluxIOS/BiluxScreens.swift BiluxIOS/Assets.xcassets/BILUXBossGuardian.imageset BiluxIOS/Assets.xcassets/BILUXBossSovereign.imageset
git diff --cached --check || fail 'Problème de diff : ne pas publier.'
git commit -m 'BILUX V5.7 - cinematic boss portraits and rank awakening'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
  git push -u origin "$DEST" || fail "Push refusé : utiliser git push -u origin $DEST"
else
  echo '🧪 Mode test : aucun push vers GitHub.'
fi
echo "✅ BILUX V5.7 intégrée sur la branche $DEST"
echo '➡️ Lancer les workflows iOS et Watch sans signature dans Codemagic.'
echo '➡️ Si les deux sont au vert, exécuter PREPARER_BUILD_13.sh.'
