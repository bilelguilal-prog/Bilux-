#!/usr/bin/env python3
"""BILUX V5.7: strict V5.6-based additive patch, stage first, never edit on failure."""
from pathlib import Path
import json, plistlib, sys, shutil

if len(sys.argv) != 3:
    raise SystemExit('Usage: APPLIQUER_V5_7.py <repo> <stage>')
root = Path(sys.argv[1]).resolve()
stage = Path(sys.argv[2]).resolve()
here = Path(__file__).resolve().parent
src = root/'BiluxIOS/BiluxScreens.swift'

def replace_one(text, old, new, label):
    n = text.count(old)
    if n != 1:
        raise ValueError(f'{label}: ancre V5.6 attendue 1 fois, trouvée {n}. Aucun changement effectué.')
    return text.replace(old,new,1)

try:
    for info in ('BiluxIOS/Info.plist', 'BiluxWatch/Info.plist'):
        with (root/info).open('rb') as f: obj = plistlib.load(f)
        if str(obj.get('CFBundleVersion')) != '12':
            raise ValueError(f'{info}: build 12 requis, trouvé {obj.get("CFBundleVersion")}')
    s=src.read_text(encoding='utf-8')
    if 'BILUX V5.6 · L\'ARÈNE DES GARDIENS' not in s or 'BILUX V5.5' not in s:
        raise ValueError('La base V5.6 réelle est absente.')
    if 'BILUX V5.7' in s:
        raise ValueError('V5.7 déjà installée.')

    # 1. Cinematics available from the profile; rank cinematic on a *future* unlock only.
    s=replace_one(s,
      '''    @State private var showLevelUp = false

    private var homeStage:''',
      '''    @State private var showLevelUp = false
    @State private var cinematicStage: NuclearStage? = nil

    private var homeStage:''', 'HomeScreen state')
    s=replace_one(s,
      '''            .alert("BILUX", isPresented: Binding(get: { health.message != nil }, set: { if !$0 { health.message = nil } })) {''',
      '''            .fullScreenCover(item: $cinematicStage) { stage in
                BILUXV57RankCinema(stage: stage, effectsEnabled: effectsEnabled) {
                    lastCelebratedLevel = max(lastCelebratedLevel, journal.heroLevel)
                    cinematicStage = nil
                }
            }
            .alert("BILUX", isPresented: Binding(get: { health.message != nil }, set: { if !$0 { health.message = nil } })) {''',
      'HomeScreen cinema cover')
    s=replace_one(s,
      '''    private func checkForLevelUp() {
        let level = journal.heroLevel
        if lastCelebratedLevel == 0 {
            // La premiere ouverture apres mise a jour ne declenche pas une fausse recompense.
            lastCelebratedLevel = level
        } else if level > lastCelebratedLevel {
            showLevelUp = true
        }
    }
''',
      '''    private func checkForLevelUp() {
        let level = journal.heroLevel
        guard !showLevelUp && cinematicStage == nil else { return }
        if lastCelebratedLevel == 0 {
            // Première ouverture : pas de cinématique artificielle pour les rangs déjà acquis.
            lastCelebratedLevel = level
        } else if level > lastCelebratedLevel {
            let legacy = journal.data.longAscensionAnchor?.legacyStage ?? 0
            let previousStage = max(NuclearStage.current(level: lastCelebratedLevel).id, legacy)
            let currentStage = journal.unlockedStageIndex
            if currentStage > previousStage {
                cinematicStage = NuclearStage.all[currentStage]
            } else {
                showLevelUp = true
            }
        }
    }
''', 'HomeScreen rank triggering')

    s=replace_one(s,
      '''    @State private var selectedStage = 0
    var body: some View {''',
      '''    @State private var selectedStage = 0
    @State private var cinematicStage: NuclearStage? = nil
    var body: some View {''', 'AscensionScreen cinematic state')
    s=replace_one(s,
      '''                            .disabled(equippedTransformationID == stage.id)
                        } else {
                            Label("Déblocage automatique au niveau''',
      '''                            .disabled(equippedTransformationID == stage.id)
                            Button {
                                cinematicStage = stage
                            } label: {
                                Label("REVOIR LA CINÉMATIQUE", systemImage: "film.stack.fill")
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(.bordered).tint(stage.accent)
                        } else {
                            Label("Déblocage automatique au niveau''',
      'Ascension replay button')
    s=replace_one(s,
      '''            .fileImporter(isPresented: $showingImporter, allowedContentTypes: [.json]) { result in''',
      '''            .fullScreenCover(item: $cinematicStage) { stage in
                BILUXV57RankCinema(stage: stage, effectsEnabled: effectsEnabled) {
                    cinematicStage = nil
                }
            }
            .fileImporter(isPresented: $showingImporter, allowedContentTypes: [.json]) { result in''',
      'Ascension cinema cover')

    # 2. Existing arena gains two original portraits and a cinematic victory scene.
    s=replace_one(s,
      '''    var symbol: String { self == .guardian ? "shield.lefthalf.filled" : "crown.fill" }
    var accent: Color''',
      '''    var symbol: String { self == .guardian ? "shield.lefthalf.filled" : "crown.fill" }
    var artwork: String { self == .guardian ? "BILUXBossGuardian" : "BILUXBossSovereign" }
    var accent: Color''', 'Boss art asset lookup')
    s=replace_one(s,
      '''                            ZStack {
                                Circle().fill(boss.accent.opacity(0.15))
                                Image(systemName: defeated ? "checkmark.shield.fill" : boss.symbol)
                                    .font(.system(size: 31, weight: .semibold))
                                    .foregroundStyle(boss.accent)
                            }.frame(width: 66, height: 66)
''',
      '''                            Image(boss.artwork)
                                .resizable().scaledToFill()
                                .frame(width: 79, height: 91)
                                .clipped()
                                .clipShape(RoundedRectangle(cornerRadius: 12))
                                .overlay(RoundedRectangle(cornerRadius: 12)
                                    .stroke(boss.accent.opacity(0.62), lineWidth: 1))
                                .accessibilityHidden(true)
''', 'Boss arena list portraits')

    s=replace_one(s,
      '''    @State private var charged = false
    @State private var revealed = false

    private var count:''',
      '''    @State private var charged = false
    @State private var revealed = false
    @State private var showVictory = false
    @AppStorage("bilux.v57.guardianVictoryPeriod") private var guardianVictoryPeriod = ""
    @AppStorage("bilux.v57.sovereignVictoryPeriod") private var sovereignVictoryPeriod = ""

    private var periodID: String {
        let parts = Calendar.current.dateComponents([.year, .month], from: .now)
        let year = parts.year ?? 0
        let month = parts.month ?? 1
        return boss == .guardian ? "\\(year)-\\(month)" : "\\(year)-Q\\((month - 1) / 3 + 1)"
    }

    private var count:''', 'Boss Battle victory state')
    # Unescape interpolated Swift strings from Python multi-lines (written with backslashes preserved).
    s=s.replace('"\\\\(year)-\\\\(month)"', '"\\(year)-\\(month)"')
    s=s.replace('"\\\\(year)-Q\\\\((month - 1) / 3 + 1)"', '"\\(year)-Q\\((month - 1) / 3 + 1)"')

    # Replace the ORIGINAL icon block only. A staged copy of the source never changes if invalid.
    battle_start=s.index('private struct BILUXV56BossBattle: View {')
    art_start=s.index('''                ZStack {
                    RoundedRectangle(cornerRadius: 24)''',battle_start)
    art_end=s.index('''                NuclearCard {
                    HStack {''',art_start)
    original_art=s[art_start:art_end]
    if 'Circle()' not in original_art or '.frame(height: 268)' not in original_art:
        raise ValueError('Le portrait V5.6 attendu a changé : annulation avant modification.')
    s=s[:art_start]+'''                BILUXV57BossPortrait(boss: boss, defeated: defeated, charged: charged)

'''+s[art_end:]
    s=replace_one(s,
      '''                    if !defeated {
                        Text("Encore \\(remaining) journée\\(remaining > 1 ? "s" : "") de séance pour vaincre ce boss, sans limite de séries consécutives.")
                            .font(.caption).foregroundStyle(boss.accent)
                    }
                }
                Text("Aucune action''',
      '''                    if !defeated {
                        Text("Encore \\(remaining) journée\\(remaining > 1 ? "s" : "") de séance pour vaincre ce boss, sans limite de séries consécutives.")
                            .font(.caption).foregroundStyle(boss.accent)
                    } else {
                        Button { showVictory = true } label: {
                            Label("REVOIR LA VICTOIRE", systemImage: "crown.fill")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.borderedProminent).tint(boss.accent)
                    }
                }
                Text("Aucune action''', 'Replay victory button')
    s=replace_one(s,
      '''        .onChange(of: effectsEnabled) { _, enabled in
            if !enabled { charged = false; revealed = true }
        }
    }
}
''',
      '''        .onChange(of: effectsEnabled) { _, enabled in
            if !enabled { charged = false; revealed = true }
        }
        .task(id: defeated) {
            guard defeated else { return }
            let alreadyPlayed = boss == .guardian ? guardianVictoryPeriod : sovereignVictoryPeriod
            guard alreadyPlayed != periodID else { return }
            if boss == .guardian { guardianVictoryPeriod = periodID }
            else { sovereignVictoryPeriod = periodID }
            await Task.yield()
            guard !Task.isCancelled else { return }
            showVictory = true
        }
        .fullScreenCover(isPresented: $showVictory) {
            BILUXV57VictoryCinema(boss: boss) { showVictory = false }
        }
    }
}
''', 'Boss victory presentation')
    s=s.rstrip()+'\n'+(here/'SCENES_V57.swift.txt').read_text(encoding='utf-8')

    out=stage/'BiluxIOS/BiluxScreens.swift'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(s,encoding='utf-8')
    for boss,file in [('BILUXBossGuardian','BossGuardian.jpg'),('BILUXBossSovereign','BossSovereign.jpg')]:
        existing=root/f'BiluxIOS/Assets.xcassets/{boss}.imageset'
        if existing.exists(): raise ValueError(f'L asset {boss} existe déjà, arrêt sans modification.')
        newdir=stage/'BiluxIOS/Assets.xcassets'/f'{boss}.imageset'
        newdir.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(here/'assets'/file,newdir/file)
        (newdir/'Contents.json').write_text(json.dumps({'images':[{'filename':file,'idiom':'universal'}],'info':{'author':'xcode','version':1}},indent=2)+'\n',encoding='utf-8')
    print('✅ Sources V5.6 reconnues. V5.7 ajoutée en zone temporaire.')
    print('✅ Deux portraits intégrés aux Assets.xcassets existants (sans changer le projet Xcode).')
    print('✅ Aucune modification du modèle, des XP, du suivi Santé ou de Watch 2.0.')
except (OSError, ValueError) as exc:
    print(f'❌ ARRÊT AVANT MODIFICATION : {exc}',file=sys.stderr)
    sys.exit(1)
