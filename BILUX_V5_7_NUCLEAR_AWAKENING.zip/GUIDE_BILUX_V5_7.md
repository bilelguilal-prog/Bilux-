# ☢️ BILUX V5.7 — NUCLEAR AWAKENING

**Base :** V5.6, branche `bilux-v5.6-arene-des-gardiens`, **build 12** validé sur iPhone et Apple Watch. 
**Nouvelle branche :** `bilux-v5.7-nuclear-awakening`.
**Prochaine version TestFlight :** build 13 (iPhone + Watch).

## Changements

- Portraits originaux pour Le Gardien du Réacteur et Le Souverain du Néant dans le tableau de l'arène et le dossier de combat.
- Cinématiques de transformation des cinq rangs, **rejouables uniquement pour les formes déjà débloquées** depuis Ascension → Les cinq transformations → Revoir la cinématique.
- La cinématique se lance également au prochain **nouveau rang** gagné (pas à la première ouverture de cette version).
- Scène de victoire de chaque boss : automatique une seule fois par période lorsqu'on consulte le boss vaincu, puis rejouable depuis le dossier de combat.
- Respect de l'option « Animations nucléaires » et du réglage iOS « Réduire les animations ».
- Aucune modification du modèle de données, du total d'XP, des séances, du rythme de 6 à 12 mois, des fichiers Santé ou du compagnon Apple Watch.

**Important :** les illustrations sont des assets intégrés à l'application, sans requête réseau. Les scènes sont des animations SwiftUI et non des vidéos préenregistrées. 

## Avant de commencer

Depuis la V5.6, exporte ton JSON depuis Ascension et conserve-le dans Fichiers (privé) ; ne le publie pas sur GitHub.

## 1. Ajouter le ZIP au dépôt

Sur GitHub, sélectionne la branche `bilux-v5.6-arene-des-gardiens` et ajoute `BILUX_V5_7_NUCLEAR_AWAKENING.zip` avec **Add file → Upload files → Commit changes**.

## 2. Installer depuis Codespaces

Dans le terminal à la racine du dépôt :

```bash
git switch bilux-v5.6-arene-des-gardiens && git pull --ff-only origin bilux-v5.6-arene-des-gardiens && unzip -o BILUX_V5_7_NUCLEAR_AWAKENING.zip -d /tmp/bilux-v57 && bash /tmp/bilux-v57/INSTALLER_V5_7.sh
```

Le programme vérifie le build 12, la structure de la V5.6 et les noms des ressources **avant** de créer la branche. Un décalage arrête la procédure : ne pas forcer.

## 3. Codemagic : deux vérifications

Sur `bilux-v5.7-nuclear-awakening`, exécute :

1. `BILUX — Vérifier le projet iOS (sans Apple Developer)`
2. `BILUX V4.1 — Vérifier Apple Watch (sans signature)`

Les deux doivent être verts avant la suite.

## 4. Préparer le build 13

```bash
bash /tmp/bilux-v57/PREPARER_BUILD_13.sh
```

Puis dans Codemagic, lance `BILUX — Publier sur TestFlight`, branche `bilux-v5.7-nuclear-awakening`.

## 5. TestFlight

Vérifie les nouveaux visuels depuis Ascension → Arène, la cinématique **Revoir** d'un rang déjà débloqué, la fermeture des scènes, les boss à 0 jour comme à jour comptabilisé, le fonctionnement des séances Apple Watch. Vérifie également qu'aucune nouvelle entrée n'a été ajoutée au journal en regardant une cinématique.

### Si une compilation échoue

**Ne lance pas TestFlight.** Envoie le log contenant la première erreur Swift. La branche stable V5.6 et le build 12 restent disponibles.

### Validation technique

Le script effectue une vérification de syntaxe Swift si `swiftc` est disponible dans Codespaces. Cela ne garantit pas à lui seul que la compilation SwiftUI iOS passe ; seule la compilation Codemagic peut la confirmer.
