#!/usr/bin/env bash
set -euo pipefail
BRANCH='bilux-v6.5-thunder-depth'
fail(){ echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Se placer à la racine du dépôt.'
[[ "$(git branch --show-current)" == "$BRANCH" ]] || fail "Branche attendue : $BRANCH"
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications locales suivies.'
git diff --cached --quiet || fail 'Index Git non vide.'
grep -q 'private struct V65DepthCompositing: View' BiluxIOS/BiluxScreens.swift || fail 'Thunder Depth V6.5 absent.'
grep -q 'private struct V63NuclearMasteryView: View' BiluxIOS/BiluxScreens.swift || fail 'V6.3 arbre de maîtrise absent.'
[[ -f scripts/assign_widget_signing.py ]] || fail 'Signature WidgetKit absente.'
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
python3 - "$TMP" <<'PY'
from pathlib import Path
import plistlib,sys
repo=Path.cwd();tmp=Path(sys.argv[1]); old='24'; new='25'
paths=('BiluxIOS/Info.plist','BiluxWatch/Info.plist','BiluxWatchWidget/Info.plist')
for relative in paths:
    try: data=plistlib.loads((repo/relative).read_bytes())
    except Exception as exc: raise SystemExit(f'❌ {relative} invalide : {exc}')
    if str(data.get('CFBundleVersion'))!=old:
        raise SystemExit(f'❌ Build {old} attendu dans {relative}; aucun fichier modifié.')
    data['CFBundleVersion']=new
    p=tmp/relative;p.parent.mkdir(parents=True,exist_ok=True)
    p.write_bytes(plistlib.dumps(data,sort_keys=False))
project=repo/'BiluxIOS.xcodeproj/project.pbxproj'
s=project.read_text(encoding='utf-8')
if s.count('CURRENT_PROJECT_VERSION = 24;')!=2 or 'BiluxWatchWidget' not in s:
    raise SystemExit('❌ Versions WidgetKit inattendues. Aucun fichier modifié.')
p=tmp/'BiluxIOS.xcodeproj/project.pbxproj';p.parent.mkdir(parents=True,exist_ok=True)
p.write_text(s.replace('CURRENT_PROJECT_VERSION = 24;', 'CURRENT_PROJECT_VERSION = 25;'),encoding='utf-8')
print('✅ Build 25 préparé pour iPhone, Apple Watch et WidgetKit.')
PY
FILES=(BiluxIOS/Info.plist BiluxWatch/Info.plist BiluxWatchWidget/Info.plist BiluxIOS.xcodeproj/project.pbxproj)
for relative in "${FILES[@]}"; do cp "$TMP/$relative" "$relative"; done
git add -- "${FILES[@]}"
git diff --cached --check || fail 'Diff Git invalide.'
git commit -m 'BILUX V6.5 - Build 25 iPhone Watch WidgetKit'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
    git push origin "$BRANCH" || fail 'Commit local créé : relancer git push.'
else
    echo '🧪 Test local : push désactivé.'
fi
echo '✅ Build 25 prêt. Publier sur TestFlight après les deux compilations vertes.'
