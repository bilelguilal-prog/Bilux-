#!/usr/bin/env python3
"""Strict staged transformation for BILUX V6.4 (24) => V6.5 Thunder Depth."""
from pathlib import Path
import plistlib
import sys

if len(sys.argv) != 3:
    raise SystemExit('Usage: APPLIQUER_V6_5.py REPO TEMP')
repo, temp = [Path(x).resolve() for x in sys.argv[1:]]
here = Path(__file__).resolve().parent

def fail(text):
    raise SystemExit('❌ ' + text + ' — aucun fichier source modifié')

def replace_once(code, old, new, label):
    matches = code.count(old)
    if matches != 1:
        fail(f'{label}: exactement 1 occurrence attendue, reçu {matches}')
    return code.replace(old, new, 1)

for name in ('BiluxIOS/Info.plist', 'BiluxWatch/Info.plist', 'BiluxWatchWidget/Info.plist'):
    try:
        build = plistlib.loads((repo/name).read_bytes()).get('CFBundleVersion')
    except Exception as exc:
        fail(f'{name} illisible ({exc})')
    if str(build) != '24':
        fail(f'Build 24 attendu dans {name} (reçu {build})')

source = repo/'BiluxIOS/BiluxScreens.swift'
model = repo/'BiluxIOS/Models.swift'
if not (source.is_file() and model.is_file()):
    fail('Sources iPhone absentes')
if not (repo/'scripts/assign_widget_signing.py').is_file():
    fail('Correctif signature WidgetKit introuvable')
if not (repo/'BiluxWatchWidget/NuclearLiveWidget.swift').is_file():
    fail('Complication Apple Watch introuvable')
original = source.read_text('utf-8')
if 'private struct V65DepthCompositing: View' in original:
    fail('V6.5 déjà appliquée')
for marker in ('private enum V64StormMastery {', 'private struct V64StormLightning: View',
               'private struct NuclearHeroAura: View',
               'private struct V63NuclearMasteryView: View',
               'struct NuclearLiveReport:'):
    if marker == 'struct NuclearLiveReport:':
        if marker not in model.read_text('utf-8'):
            fail('Modèle Nuclear Live absent')
    elif marker not in original:
        fail('Source V6.4/V6.3 manquante : '+marker)

s = original
s = replace_once(s, 'import UniformTypeIdentifiers\n',
                 'import UniformTypeIdentifiers\nimport UIKit\nimport Vision\nimport CoreImage\n',
                 'Imports Vision/CoreImage')
engine = (here/'DEPTH_ENGINE_V65.swift.txt').read_text('utf-8')
s = replace_once(s, 'private struct NuclearHeroAura: View {',
                 engine + '\nprivate struct NuclearHeroAura: View {',
                 'Injection moteur profondeur')

old_overlay = '''                // V6.4 : éclairs vectoriels réellement mouvants, sans bouger ni recadrer l'avatar.
                // Contrôlés par le toggle existant + Réduire les animations d'iOS.
                if animate && stormIsVisible {
                    V64StormLightning(stage: stage.id, masteryCount: masteryCount,
                                     dominantPath: dominantPath,
                                     epic: stormIntensity != "balanced")
                        .blendMode(.screen)
                        .allowsHitTesting(false)
                }
'''
new_overlay = '''                // V6.5 : foudre arrière OCCULTÉE par le personnage détou ré automatiquement
                // (Vision, sur l'iPhone), puis décharges rares au premier plan.
                // Aucune animation de la taille/cadre du portrait et aucun recalcul d'XP.
                if animate && stormIsVisible && outgoingArtwork == nil {
                    V65DepthCompositing(artwork: stage.artwork, stage: stage.id,
                                        masteryCount: masteryCount,
                                        dominantPath: dominantPath,
                                        epic: stormIntensity != "balanced",
                                        width: width, height: height)
                }
'''.replace('détou ré', 'détouré')
s = replace_once(s, old_overlay, new_overlay, 'Composition portrait Accueil/Ascension')

old_cinema = '''                if animated {
                    V64StormLightning(stage: stage.id, masteryCount: 0,
                                     dominantPath: "core", epic: true)
                        .blendMode(.screen)
                        .allowsHitTesting(false)
                }
'''
new_cinema = '''                if animated {
                    V65DepthCompositing(artwork: stage.artwork, stage: stage.id,
                                        masteryCount: 0, dominantPath: "core",
                                        epic: true,
                                        width: geometry.size.width,
                                        height: geometry.size.height)
                }
'''
s = replace_once(s, old_cinema, new_cinema, 'Composition cinématique')

s = replace_once(s, 'Text("TEMPÊTE ÉLECTRIQUE · V6.4")',
                 'Text("THUNDER DEPTH · V6.5")', 'Section réglages')
s = replace_once(s,
'''                        Text("Arcs électriques mouvants, ramifications et étincelles : la voie de maîtrise dominante modifie leur couleur. Mode Épique activé par défaut. Aucun effet sur les XP.")''',
'''                        Text("Foudre d'orage en profondeur : derrière la silhouette, autour du réacteur, puis quelques décharges devant. Détourage automatique sur l'iPhone avec Apple Vision (si détectable), sans transfert de photo. Mode Épique par défaut. Aucun effet sur les XP.")''',
'Explication de profondeur')

out = temp/'BiluxIOS/BiluxScreens.swift'
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(s, 'utf-8')
print('✅ V6.5 : foudre 2 plans + silhouette détourée à la demande par Apple Vision.')
print('✅ Accueil, Ascension et cinématique modifiés ; images, XP, Watch et WidgetKit inchangés.')
