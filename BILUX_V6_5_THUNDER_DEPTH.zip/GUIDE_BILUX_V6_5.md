# ☢️⚡ BILUX V6.5 — THUNDER DEPTH

**Base de départ :** `bilux-v6.4-nuclear-evolution`, **build 24** iPhone + Apple Watch + WidgetKit.  
**Branche créée :** `bilux-v6.5-thunder-depth`.  
**Prochain build TestFlight :** **25**, seulement après validation des deux workflows Codemagic.

## Nouveauté : la foudre passe réellement derrière le personnage

La V6.4 dessinait tous les arcs électriques **par-dessus la photo entière**. La V6.5 remplace cette composition par :

1. **Plan arrière** — grosses décharges d'orage plus rares, longues, ramifiées, partant des bords du décor. Elles bougent indépendamment des décharges avant et présentent un flou de profondeur.
2. **Plan du personnage** — l'iPhone essaie de détourer localement le personnage de l'illustration avec le framework Apple **Vision** (`VNGenerateForegroundInstanceMaskRequest`, à partir d'iOS 17). Le personnage détouré est recomposé **devant** les éclairs du fond, ce qui masque les portions passant derrière ses cheveux, son visage et son corps. Aucun téléchargement d'image ni aucun accès réseau.
3. **Plan avant** — quelques branches fortes passent au-dessus des épaules et du réacteur, avec un cœur lumineux, et disparaissent par impulsions courtes, parfois suivies d'une seconde décharge.
4. **Décharges orbitales brèves** — deux demi-ondes (arrière / avant) parcourent la zone du réacteur sans dessiner un cerceau fixe sur le visage.

Ce rendu est une **profondeur pseudo-3D**, pas un personnage 3D modélisé ni un mouvement réel de caméra. L'image source garde exactement les mêmes dimensions, proportions et cadrage.

**Si Vision ne distingue pas le personnage d'une illustration**, le mode repli réduit les éclairs d'arrière-plan aux bords : il évite de masquer le visage avec de faux contours. Certaines illustrations stylisées peuvent être moins bien détourées que d'autres.

## Ce qui ne change pas

- Aucun changement des XP, niveaux 1–100, rangs, trophées, arbre V6.3 ou données JSON.
- Aucun changement HealthKit, Nuclear Live, zones cardiaques, notifications de la Watch, synchronisation ou WidgetKit.
- Aucun changement des images d'origine, du système de signatures Apple et des bundle identifiers.
- Le réglage **Équilibré / Épique ⚡** existant est conservé, et le mode Épique reste le réglage par défaut.
- Le bouton **Animations nucléaires** et le réglage iOS **Réduire les animations** désactivent les effets.
- Le traitement Vision a lieu dans une file de travail de faible priorité et le détourage est gardé en cache pour les affichages suivants de l'image.

## 0. Sécuriser sa progression

Sur l'iPhone, dans **BILUX → Ascension**, exporte une sauvegarde JSON complète et conserve-la dans **Fichiers / iCloud privé**. **Ne mets jamais cette sauvegarde dans le dépôt GitHub**, elle peut contenir des données de santé.

## 1. Ajouter l'archive sur GitHub

Dans Safari sur ton iPhone :

1. Ouvre `https://github.com/bilelguilal-prog/Bilux-`.
2. Choisis la branche **`bilux-v6.4-nuclear-evolution`** — la V6.4 validée sur le téléphone.
3. **Add file → Upload files**, téléverse **`BILUX_V6_5_THUNDER_DEPTH.zip`** à la racine.
4. **Commit changes** sur **la branche V6.4**.

## 2. Installer dans Codespaces

Depuis le terminal du dépôt (n'ouvre pas le ZIP dans l'éditeur), colle **toute cette ligne** :

```bash
git switch bilux-v6.4-nuclear-evolution && git pull --ff-only origin bilux-v6.4-nuclear-evolution && unzip -o BILUX_V6_5_THUNDER_DEPTH.zip -d /tmp/bilux-v65 && bash /tmp/bilux-v65/INSTALLER_V6_5.sh
```

Le script :
- exige la V6.4 et les trois bundles en build 24 ;
- contrôle la présence de Nuclear Live, de Nuclear Mastery et du correctif signature WidgetKit ;
- prépare le nouveau fichier Swift **dans un dossier temporaire** et vérifie sa syntaxe, si `swiftc` est disponible ;
- crée et pousse la branche **`bilux-v6.5-thunder-depth`** ;
- modifie uniquement **`BiluxIOS/BiluxScreens.swift`**.

Ne réexécute pas l'installateur si la branche V6.5 a déjà été créée. Les fichiers ZIP présents mais non suivis par Git ne bloquent pas le script.

## 3. Vérifier dans Codemagic, avant la publication

Sélectionne la branche **`bilux-v6.5-thunder-depth`** :

1. **BILUX — Vérifier le projet iOS**.
2. **BILUX V4.1 — Vérifier Apple Watch**.

Les deux doivent passer au **vert**. Si l'un échoue, arrête-toi et fournis la **première erreur Xcode** (`error:`) ainsi que ses lignes voisines. Les tests locaux ne peuvent pas remplacer Xcode pour les frameworks iOS / Vision.

## 4. Préparer le build 25

**Uniquement après les deux tests verts**, dans le même Codespace et sur la branche V6.5 :

```bash
bash /tmp/bilux-v65/PREPARER_BUILD_25.sh
```

Si le dossier temporaire a disparu, relance d'abord :

```bash
unzip -o BILUX_V6_5_THUNDER_DEPTH.zip -d /tmp/bilux-v65
```

La commande incrémente le build **24 → 25** dans les trois `Info.plist` et les deux occurrences `CURRENT_PROJECT_VERSION` du widget, puis commit et push.

Publie ensuite **BILUX — Publier sur TestFlight** sur `bilux-v6.5-thunder-depth` et installe la version **1.0 (25)** sur l'iPhone. Conserve la version 24 comme solution de secours jusqu'à la vérification visuelle.

## 5. Test visuel essentiel (iPhone)

1. **Accueil → Portrait** : pendant 10 secondes, observe des éclairs qui apparaissent derrière la tête/les épaules, puis quelques décharges qui passent devant le bas du torse. Les **éclairs arrière doivent être cachés par la silhouette**, pas peints en plein visage.
2. **Ascension → Portrait** : mêmes effets sur la forme débloquée. Les formes verrouillées restent en aperçu statique. Vérifie **Épique ⚡** puis **Équilibré**.
3. **Ascension → REVOIR LA CINÉMATIQUE** : vérifier la même profondeur avec de puissants impacts électriques.
4. **Animations nucléaires = OFF** : le portrait devient statique. Puis tester **iOS → Accessibilité → Animation → Réduire les animations**, qui doit aussi arrêter les effets.
5. **Nuclear Mastery** : les quatre voies, les douze capacités, le rang, le niveau et les XP doivent être identiques à ceux de la V6.4.
6. **Apple Watch / widget** : Nuclear Live et la complication continuent de fonctionner. Aucune configuration Watch supplémentaire n'est nécessaire.

**Premier point à contrôler :** si les arcs restent visiblement au-dessus du visage, la détection Vision n'a probablement pas reconnu correctement le personnage. Une capture du portrait et une courte vidéo aideront à ajuster le masque pour l'illustration concernée.

## 6. Limites et précautions

- Cette V6.5 simule une profondeur via **compositing 2D et détourage**, elle ne génère pas un véritable maillage 3D.
- Le détourage Apple Vision peut être imparfait sur des dessins complexes. Le comportement de repli protège la lisibilité du portrait plutôt que de fabriquer un mauvais masque.
- Plusieurs décharges sont volontairement brèves et lumineuses. Évite le mode Épique si elles provoquent une gêne visuelle et utilise l'option Réduire les animations en cas de sensibilité aux flashs.
- La détection peut utiliser un peu de ressources lors de la première ouverture d'une nouvelle transformation ; le résultat est conservé en cache en mémoire.
- Seule une compilation **Xcode sur Codemagic** peut confirmer le build final. L'archive a été testée localement sur une copie de la V6.4, sans signature Apple ni véritable simulateur iOS.
