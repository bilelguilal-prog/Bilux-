#!/usr/bin/env bash
set -euo pipefail
BASE='bilux-v6.4-nuclear-evolution'
NEW='bilux-v6.5-thunder-depth'
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail(){ echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Exécuter depuis la racine du dépôt BILUX.'
[[ "$(git branch --show-current)" == "$BASE" ]] || fail "Branche de départ attendue : $BASE"
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications locales suivies : sauvegarde-les d’abord.'
git diff --cached --quiet || fail 'Index Git non vide.'
! git show-ref --quiet --verify "refs/heads/$NEW" || fail "La branche $NEW existe déjà."
command -v python3 >/dev/null || fail 'Python 3 introuvable.'
git var GIT_AUTHOR_IDENT >/dev/null 2>&1 || fail 'Identité Git non configurée.'
TEMP="$(mktemp -d)"; trap 'rm -rf "$TEMP"' EXIT
python3 "$HERE/APPLIQUER_V6_5.py" "$(pwd)" "$TEMP" || fail 'Sources incompatibles, aucun changement effectué.'
[[ -s "$TEMP/BiluxIOS/BiluxScreens.swift" ]] || fail 'Code Swift généré manquant.'
if command -v swiftc >/dev/null 2>&1; then
    swiftc -frontend -parse "$TEMP/BiluxIOS/BiluxScreens.swift" BiluxIOS/Models.swift || fail 'Syntaxe Swift invalide, rien modifié.'
    echo '✅ Analyse syntaxique Swift validée. La compilation Apple reste à vérifier sur Codemagic.'
else
    echo 'ℹ️ Pas de Swift local : compilation à confirmer sur Codemagic.'
fi
# Reaching this point means all source-specific checks succeeded.
git switch -c "$NEW"
cp "$TEMP/BiluxIOS/BiluxScreens.swift" BiluxIOS/BiluxScreens.swift
git add -- BiluxIOS/BiluxScreens.swift
git diff --cached --check || fail 'Diff Git invalide.'
git commit -m 'BILUX V6.5 - Thunder Depth foreground occlusion and storm'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
    git push -u origin "$NEW" || fail "Commit local créé : relancer git push -u origin $NEW"
else
    echo '🧪 Test local : push désactivé.'
fi
echo "✅ V6.5 installée sur $NEW. Lancer les deux compilations Codemagic avant de préparer le build 25."
