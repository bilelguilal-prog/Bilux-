#!/usr/bin/env bash
set -euo pipefail

# BILUX V5.1 — installation contrôlée : ne touche qu'à BiluxIOS/BiluxScreens.swift
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH="$HERE/BILUX_V5_1_NUCLEAR_REDESIGN.patch"
TARGET="BiluxIOS/BiluxScreens.swift"
BASE="bilux-v5-sport"
DEST="bilux-v5.1-redesign"

if [[ ! -f "$TARGET" || ! -f "$PATCH" ]]; then
  echo "ERREUR : lance ce script depuis la racine du dépôt Bilux-." >&2
  exit 1
fi
BRANCH="$(git branch --show-current)"
if [[ "$BRANCH" != "$BASE" ]]; then
  echo "ERREUR : branche active '$BRANCH' au lieu de '$BASE'." >&2
  echo "Aucune modification effectuée." >&2
  exit 1
fi
if [[ -n "$(git status --porcelain -- "$TARGET")" ]]; then
  echo "ERREUR : $TARGET comporte déjà des changements. Sauvegarde-les avant de continuer." >&2
  exit 1
fi
if ! git diff --cached --quiet; then
  echo "ERREUR : des modifications sont déjà indexées (staged). Arrêt par précaution." >&2
  exit 1
fi
if git show-ref --verify --quiet "refs/heads/$DEST"; then
  echo "ERREUR : la branche $DEST existe déjà. Aucun écrasement." >&2
  exit 1
fi
if git ls-remote --exit-code --heads origin "$DEST" >/dev/null 2>&1; then
  echo "ERREUR : la branche distante $DEST existe déjà. Aucun écrasement." >&2
  exit 1
fi
if ! git apply --check "$PATCH"; then
  echo "ERREUR : le correctif ne correspond pas à ta version Sport V5. Aucune modification." >&2
  exit 1
fi

git switch -c "$DEST"
git apply "$PATCH"
git diff --check
git add -- "$TARGET"
git commit -m "BILUX V5.1 - Nuclear Ascension redesign iPhone"
git push -u origin "$DEST"

echo ""
echo "BILUX V5.1 : correctif appliqué et envoyé sur la branche $DEST"
echo "Ensuite : Codemagic > Vérifier le projet iOS (sans Apple Developer) > branche $DEST"
echo "NE PAS publier sur TestFlight avant la validation du simulateur et l'incrément du build."
