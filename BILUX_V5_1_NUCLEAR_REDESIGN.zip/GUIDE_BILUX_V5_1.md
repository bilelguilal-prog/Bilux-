# BILUX V5.1 — Nuclear Ascension (refonte iPhone)

## Ce que contient ce correctif

Il modernise l'interface SwiftUI existante **sans remplacer les données ou les moteurs** :

- Accueil : écran cinématique avec illustration existante `BiluxHero`, halo animé, rang, niveau, XP réellement calculés.
- Navigation : tuiles interactives Sport, Nutrition, Santé et Ascension, et barre d'onglets à cinq destinations.
- Statistiques : pas, énergie dépensée, nutrition, sommeil issus des données déjà accessibles dans BILUX.
- Quêtes : trois quêtes alimentées par les séances, repas et bilans réellement enregistrés.
- Sport : nouvelle bannière « La Forge » ; maintien intégral du catalogue d'exercices et de l'édition des séances V5.
- Ascension : jauge circulaire XP et nouvelle mise en page.
- Tous les écrans : fond profond noir/violet, cartes verre sombre, contours dorés, typographie plus lisible.

Le patch modifie **uniquement `BiluxIOS/BiluxScreens.swift`**. Il ne touche pas à `BiluxStore`, `Models`, `HealthKitManager`, `WatchPhoneBridge`, `BiluxWatch`, `Info.plist` ou aux certificats.

## Pré-requis

- Branche `bilux-v5-sport`, après application du correctif Sport V5 et compilation validée.
- Faire une sauvegarde JSON avant d'installer le build sur iPhone.
- Avoir ajouté cette archive ZIP à la **racine du dépôt sur la branche `bilux-v5-sport`**.

## Installation (sur ton iPhone via GitHub Codespaces)

Exécute depuis la racine du dépôt dans le terminal :

```bash
git switch bilux-v5-sport
git pull --ff-only origin bilux-v5-sport
unzip -o BILUX_V5_1_NUCLEAR_REDESIGN.zip -d /tmp/bilux-v51
bash /tmp/bilux-v51/INSTALLER_V5_1.sh
```

Le script vérifie d'abord que le correctif correspond aux fichiers, que la branche est correcte et que les modifications ne risquent pas d'être écrasées. Puis il crée `bilux-v5.1-redesign`, applique le patch, crée un commit et pousse la branche GitHub. En cas d'incohérence, il s'arrête.

## Vérification du build

Codemagic : choisir `bilux-v5.1-redesign` puis le workflow **Vérifier le projet iOS (sans Apple Developer)**. Après validation, préparer le build TestFlight **5** (la version 1.0 build 4 est déjà utilisée). Ne pas relancer le workflow de publication avec le build 4.

## Limites et validation

- Syntaxe analysée avec `swiftc -frontend -parse` sur tous les fichiers Swift de la source de référence.
- `git apply --check` validé localement sur la base V4.1 + patch Sport V5.
- **Compilation Xcode / Codemagic, rendu sur iPhone et compatibilité avec les modifications intervenues après la source de référence non encore vérifiés.** Le script s'arrête si un conflit est détecté.
- L'image de démonstration de la présentation précédente est un concept, pas une capture d'écran de l'application compilée. L'application utilise son illustration `BiluxHero` déjà intégrée aux assets.
- Les transformations et arbres de compétences détaillés seront une phase distincte ; ce correctif modernise leur présentation, il ne simule pas de données.
