#!/usr/bin/env python3
"""Correctif strict V5.9: rattacher le catalogue cosmétique au MainActor.
Écrit exclusivement un fichier en zone temporaire ; l'installation l'applique après validation.
"""
from pathlib import Path
import sys

if len(sys.argv) != 3:
    raise SystemExit('Usage: APPLIQUER_V5_9_1.py DEPOT DESTINATION')
repo = Path(sys.argv[1]).resolve()
target = Path(sys.argv[2]).resolve()
source = repo / 'BiluxIOS/BiluxScreens.swift'
if not source.is_file():
    raise SystemExit('❌ BiluxScreens.swift introuvable. Aucun fichier modifié.')
text = source.read_text(encoding='utf-8')
old = 'private enum BILUXV59Legacy {\n'
new = '@MainActor\nprivate enum BILUXV59Legacy {\n'
if text.count(old) != 1 or new in text:
    raise SystemExit('❌ Marqueur V5.9 absent, en double ou correctif déjà appliqué. Aucun fichier modifié.')
need = [
    'static func titles(_ journal: BiluxStore)',
    'static func auras(_ journal: BiluxStore)',
    'static func crests(_ journal: BiluxStore)',
    'static func activeTitle(_ journal: BiluxStore)',
    'static func activeAura(_ journal: BiluxStore)',
    'static func activeCrest(_ journal: BiluxStore)',
    'MARK: - BILUX V5.9 · NUCLEAR LEGACY',
]
if any(text.count(marker) != 1 for marker in need):
    raise SystemExit('❌ Code V5.9 différent du catalogue attendu. Aucun fichier modifié.')
# Tous les problèmes du journal sont des accès depuis cet enum aux membres @MainActor de BiluxStore.
fixed = text.replace(old, new, 1)
if fixed.count(new) != 1:
    raise SystemExit('❌ Contrôle post-correction échoué. Aucun fichier modifié.')
target.parent.mkdir(parents=True, exist_ok=True)
target.write_text(fixed, encoding='utf-8')
print('✅ Les six fonctions du catalogue V5.9 sont maintenant isolées sur MainActor.')
print('✅ Une seule annotation Swift ajoutée, sans toucher aux modèles ni aux sauvegardes.')
