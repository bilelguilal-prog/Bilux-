#!/usr/bin/env bash
set -euo pipefail
BASE='bilux-v5.9-nuclear-legacy'
DEST='bilux-v5.9.1-main-actor-fix'
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail(){ printf '❌ %s\n' "$*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Lance depuis la racine du dépôt BILUX.'
[[ "$(git branch --show-current)" == "$BASE" ]] || fail "Branche de départ attendue : $BASE."
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications locales détectées : annulation.'
git diff --cached --quiet || fail 'Modifications indexées détectées.'
! git show-ref --quiet --verify "refs/heads/$DEST" || fail "La branche $DEST existe déjà."
command -v python3 >/dev/null || fail 'Python 3 introuvable.'
git var GIT_AUTHOR_IDENT >/dev/null 2>&1 || fail 'Identité Git non configurée.'
[[ -f "$HERE/APPLIQUER_V5_9_1.py" ]] || fail 'Script de correction absent dans le ZIP.'
TEMP="$(mktemp -d)"
trap 'rm -rf "$TEMP"' EXIT
python3 "$HERE/APPLIQUER_V5_9_1.py" "$(pwd)" "$TEMP/BiluxScreens.swift" || fail 'Base incompatible : rien modifié.'
if command -v swiftc >/dev/null 2>&1; then
    swiftc -frontend -parse "$TEMP/BiluxScreens.swift" || fail 'Erreur de syntaxe Swift.'
    echo '✅ Analyse syntaxique Swift réussie (la compilation Xcode reste nécessaire).'
else
    echo 'ℹ️ Swift non installé ici : la vraie compilation sera vérifiée dans Codemagic.'
fi
git switch -c "$DEST"
cp "$TEMP/BiluxScreens.swift" BiluxIOS/BiluxScreens.swift
git add -- BiluxIOS/BiluxScreens.swift
git diff --cached --check || fail 'Diff invalide.'
git commit -m 'BILUX V5.9.1 - fix MainActor isolation for Nuclear Legacy'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
    git push -u origin "$DEST" || fail "Envoi échoué : git push -u origin $DEST"
else
    echo '🧪 Test local : push désactivé.'
fi
echo "✅ BILUX V5.9.1 installée sur $DEST."
echo '➡️ Lance le workflow iPhone de vérification Codemagic, puis la Watch si iPhone au vert.'
echo '➡️ Après double validation, prépare le build 18 avec PREPARER_BUILD_18.sh.'
