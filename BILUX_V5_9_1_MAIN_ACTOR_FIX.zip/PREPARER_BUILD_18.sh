#!/usr/bin/env bash
set -euo pipefail
BRANCH='bilux-v5.9.1-main-actor-fix'
fail(){ printf '❌ %s\n' "$*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Lance depuis la racine du dépôt BILUX.'
[[ "$(git branch --show-current)" == "$BRANCH" ]] || fail "Branche attendue : $BRANCH."
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications locales détectées.'
git diff --cached --quiet || fail 'Modifications indexées détectées.'
grep -q -F '@MainActor' BiluxIOS/BiluxScreens.swift || fail 'Annotation MainActor introuvable.'
python3 - <<'PY'
from pathlib import Path
import plistlib
names = ['BiluxIOS/Info.plist', 'BiluxWatch/Info.plist']
plists = {}
for name in names:
    pl = plistlib.loads(Path(name).read_bytes())
    actual = str(pl.get('CFBundleVersion'))
    if actual != '17':
        raise SystemExit(f'❌ {name} : build 17 requis, trouvé {actual}. Aucun fichier modifié.')
    plists[name] = pl
for name, pl in plists.items():
    pl['CFBundleVersion'] = '18'
    Path(name).write_bytes(plistlib.dumps(pl, fmt=plistlib.FMT_XML, sort_keys=False))
    print(f'✅ {name} : build 17 → 18')
PY
git add -- BiluxIOS/Info.plist BiluxWatch/Info.plist
git diff --cached --check || fail 'Diff invalide.'
git commit -m 'BILUX V5.9.1 - build 18 iPhone and Watch'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
    git push -u origin "$BRANCH" || fail "Push échoué : git push -u origin $BRANCH"
else
    echo '🧪 Test local : push désactivé.'
fi
echo '✅ Build 18 prêt pour TestFlight.'
