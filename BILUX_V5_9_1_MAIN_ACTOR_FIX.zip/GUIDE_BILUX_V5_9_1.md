# BILUX V5.9.1 — MainActor Fix

## Cause confirmée dans le journal Codemagic

Le workflow iPhone de V5.9 échoue avec 13 diagnostics `main actor-isolated property ... can not be referenced from a nonisolated context` dans `BiluxIOS/BiluxScreens.swift` (lignes 2246 à 2306). `BiluxStore` porte déjà `@MainActor`, tandis que les fonctions du catalogue `BILUXV59Legacy` n'étaient pas isolées.

Ce correctif ajoute uniquement `@MainActor` avant `private enum BILUXV59Legacy`. Il conserve les nouveaux titres, auras, emblèmes, données, XP, Watch et animations tels quels. La V5.8.3 reste la branche stable.

## Installation iPhone (GitHub + Codespaces)

1. Dans GitHub, branche **`bilux-v5.9-nuclear-legacy`**, téléverser `BILUX_V5_9_1_MAIN_ACTOR_FIX.zip` puis faire le commit.
2. Ouvrir Codespaces et exécuter :

```bash
git switch bilux-v5.9-nuclear-legacy && git pull --ff-only origin bilux-v5.9-nuclear-legacy && unzip -o BILUX_V5_9_1_MAIN_ACTOR_FIX.zip -d /tmp/bilux-v591 && bash /tmp/bilux-v591/INSTALLER_V5_9_1.sh
```

3. Dans Codemagic, vérifier le workflow iPhone sur **`bilux-v5.9.1-main-actor-fix`**, puis celui de la Watch. Ces étapes sont nécessaires : une vérification `swiftc -frontend -parse` ne garantit pas la compilation Xcode.
4. Si les deux tests sont verts :

```bash
bash /tmp/bilux-v591/PREPARER_BUILD_18.sh
```

5. Codemagic : branche `bilux-v5.9.1-main-actor-fix`, workflow **BILUX — Publier sur TestFlight**, puis App Store Connect **1.0 (18)**.

Ne pas exécuter le script `PREPARER_BUILD_18.sh` de l'ancien ZIP V5.9, qui vérifie une autre branche.

## Contrôles

- Installation refuse les mauvaises branches, les modifications suivies non enregistrées et les sources incompatibles.
- Code source modifié : `BiluxIOS/BiluxScreens.swift`, une seule annotation `@MainActor`.
- Préparation du build vérifie les deux `Info.plist` à 17 avant de passer les deux à 18.
- Aucun fichier de données de l'application n'est modifié par les scripts.
