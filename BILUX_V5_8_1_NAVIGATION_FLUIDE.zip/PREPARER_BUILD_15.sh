#!/usr/bin/env bash
set -euo pipefail
BRANCH='bilux-v5.8.1-codex-navigation'
fail(){ echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Lance le script à la racine du dépôt.'
[[ "$(git branch --show-current)" == "$BRANCH" ]] || fail "Branche $BRANCH attendue."
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications locales détectées.'
git diff --cached --quiet || fail 'Modifications indexées détectées.'
grep -q 'V5.8.1 : aucun ScrollView horizontal' BiluxIOS/BiluxScreens.swift || fail 'Le correctif Codex V5.8.1 est absent.'
python3 - <<'PY'
from pathlib import Path
import plistlib
paths = [Path('BiluxIOS/Info.plist'), Path('BiluxWatch/Info.plist')]
original = {}
for p in paths:
    original[p] = p.read_bytes()
    current = str(plistlib.loads(original[p]).get('CFBundleVersion'))
    if current != '14': raise SystemExit(f'❌ {p}: build 14 requis, reçu {current}. Aucun fichier modifié.')
for p in paths:
    pl = plistlib.loads(original[p]); pl['CFBundleVersion'] = '15'
    p.write_bytes(plistlib.dumps(pl,fmt=plistlib.FMT_XML,sort_keys=False))
    print(f'✅ {p}: build 14 → 15')
PY
git add -- BiluxIOS/Info.plist BiluxWatch/Info.plist
git diff --cached --check || fail 'Contrôle du diff échoué.'
git commit -m 'BILUX V5.8.1 - TestFlight build 15'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != 1 ]]; then
  git push -u origin "$BRANCH" || fail "Push interrompu : relance git push -u origin $BRANCH"
else
  echo '🧪 Test local : push désactivé.'
fi
echo '✅ Build 15 préparé. Utilise le workflow TestFlight de Codemagic.'
