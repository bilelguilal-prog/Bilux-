#!/usr/bin/env python3
"""Safe, strictly-anchored single-file V5.8.1 Codex navigation patch."""
import json
import plistlib
import sys
from pathlib import Path

if len(sys.argv) != 3:
    raise SystemExit('Usage: APPLIQUER_V5_8_1.py <repo_root> <staging_dir>')
root = Path(sys.argv[1]).resolve()
stage = Path(sys.argv[2]).resolve()
payload = json.loads((Path(__file__).with_name('PATCH_NAV_V581.json')).read_text(encoding='utf-8'))
try:
    for file in ('BiluxIOS/Info.plist', 'BiluxWatch/Info.plist'):
        with (root/file).open('rb') as f: plist = plistlib.load(f)
        if str(plist.get('CFBundleVersion')) != '14':
            raise ValueError(f'{file}: build 14 attendu ; reçu {plist.get("CFBundleVersion")!r}')
    source = root/'BiluxIOS/BiluxScreens.swift'
    text = source.read_text(encoding='utf-8')
    if text.count('private struct BILUXV58Codex: View') != 1:
        raise ValueError('Codex V5.8 non reconnu')
    start = text.index('private struct BILUXV58Codex: View')
    prefix, codex = text[:start], text[start:]
    if 'V5.8.1 : aucun ScrollView horizontal' in codex:
        raise ValueError('Le correctif V5.8.1 est déjà présent')
    for key in ('body', 'tabs'):
        before, after = payload['old_'+key], payload['new_'+key]
        occurrences = codex.count(before)
        if occurrences != 1:
            raise ValueError(f'Ancre {key} absente ou ambiguë (trouvée {occurrences} fois). Aucun changement.')
        codex = codex.replace(before, after, 1)
    modified = prefix + codex
    if modified.count('ScrollView(.horizontal, showsIndicators: false)') >= text.count('ScrollView(.horizontal, showsIndicators: false)'):
        raise ValueError('Le défilement horizontal du Codex n’a pas été supprimé')
    if any(x in modified for x in ('<<<<<<< ', '>>>>>>> ')):
        raise ValueError('Marqueurs de conflit détectés')
    output = stage/'BiluxIOS/BiluxScreens.swift'
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(modified, encoding='utf-8')
    print('✅ V5.8 build 14 reconnu, patch V5.8.1 prêt en zone temporaire.')
    print('✅ Navigation à 5 boutons / 2 lignes, épinglée et sans défilement horizontal.')
    print('✅ XP, dossiers, modèles, portraits, HealthKit et Watch inchangés.')
except (OSError, ValueError, KeyError) as error:
    print(f'❌ Installation interrompue avant modification : {error}', file=sys.stderr)
    sys.exit(1)
