#!/usr/bin/env bash
set -euo pipefail
BASE='bilux-v5.8-nuclear-codex'
DEST='bilux-v5.8.1-codex-navigation'
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail(){ echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Lance la commande à la racine du dépôt BILUX.'
[[ "$(git branch --show-current)" == "$BASE" ]] || fail "Branche attendue : $BASE"
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications locales : annulation par sécurité.'
git diff --cached --quiet || fail 'Des modifications sont indexées.'
! git show-ref --verify --quiet "refs/heads/$DEST" || fail "La branche $DEST existe déjà."
[[ -f "$HERE/APPLIQUER_V5_8_1.py" && -f "$HERE/PATCH_NAV_V581.json" ]] || fail 'ZIP incomplet.'
TEMP="$(mktemp -d)"
trap 'rm -rf "$TEMP"' EXIT
python3 "$HERE/APPLIQUER_V5_8_1.py" "$(pwd)" "$TEMP/staged" || fail 'Base incompatible : aucun fichier modifié.'
if command -v swiftc >/dev/null 2>&1; then
  swiftc -frontend -parse "$TEMP/staged/BiluxIOS/BiluxScreens.swift" || fail 'Syntaxe Swift invalide. Aucun fichier modifié.'
  echo '✅ Analyse de syntaxe Swift validée ; compilation iOS à vérifier sur Codemagic.'
else
  echo 'ℹ️ swiftc non disponible : compilation réelle à vérifier dans Codemagic.'
fi
git switch -c "$DEST"
cp "$TEMP/staged/BiluxIOS/BiluxScreens.swift" BiluxIOS/BiluxScreens.swift
git add -- BiluxIOS/BiluxScreens.swift
git diff --cached --check || fail 'Contrôle Git échoué.'
git commit -m 'BILUX V5.8.1 - Codex first-tap navigation fix'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != 1 ]]; then
  git push -u origin "$DEST" || fail "Le push a échoué : lance git push -u origin $DEST"
else
  echo '🧪 Test local : push désactivé.'
fi
echo "✅ BILUX V5.8.1 intégrée sur $DEST"
echo '➡️ Vérifie les deux workflows iPhone/Watch dans Codemagic.'
echo '➡️ Après validation, utilise PREPARER_BUILD_15.sh.'
