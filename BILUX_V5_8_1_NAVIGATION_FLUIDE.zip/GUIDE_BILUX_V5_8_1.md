# BILUX V5.8.1 — Navigation fluide du Codex

Correctif ciblé sur BILUX V5.8 *build 14* ; aucune modification d'XP, de séances, de Santé ou du code Apple Watch.

## Pourquoi ?

Le menu des rubriques du Codex était un `ScrollView` horizontal imbriqué dans un `ScrollView` vertical. Cela peut concurrencer la reconnaissance tactile, surtout lors du défilement.

## Correctif

- Les 5 rubriques (Bestiaire, Trophées, Chroniques, Formes et Secrets) tiennent sur deux rangées de boutons de 48 points minimum.
- Les rubriques restent visibles en haut quand on consulte de longues pages (en-tête épinglé).
- L'app revient automatiquement au début de la rubrique lorsqu'on change de catégorie.
- Les zones tactiles sont agrandies et le bouton actif est visiblement surligné.

## Installation

1. Exporter son journal JSON BILUX et le garder dans Fichiers, hors de GitHub.
2. Sur GitHub, sélectionner `bilux-v5.8-nuclear-codex` puis envoyer le ZIP `BILUX_V5_8_1_NAVIGATION_FLUIDE.zip` dans la racine du dépôt (Add file > Upload files > Commit).
3. Dans Codespaces, exécuter :

```bash
git switch bilux-v5.8-nuclear-codex && git pull --ff-only origin bilux-v5.8-nuclear-codex && unzip -o BILUX_V5_8_1_NAVIGATION_FLUIDE.zip -d /tmp/bilux-v581 && bash /tmp/bilux-v581/INSTALLER_V5_8_1.sh
```

4. Dans Codemagic, vérifier les compilations simulateur iOS et Apple Watch sur `bilux-v5.8.1-codex-navigation`.
5. Uniquement si les deux sont au vert, exécuter dans Codespaces :

```bash
bash /tmp/bilux-v581/PREPARER_BUILD_15.sh
```

6. Publier via le workflow TestFlight sur cette branche. Vérifier **1.0 (15)** dans App Store Connect.
7. Sur l'iPhone : ouvrir Codex, cliquer une fois sur chaque rubrique et essayer le changement depuis le bas de Chroniques/Trophées ; vérifier que le menu reste visible, que l'onglet actif change et que l'affichage revient au début.

## Sécurité

L'installateur vérifie la branche, le build et deux portions exactes du code avant toute modification. Si la base diffère, il s'arrête sans écrire de fichiers. La V5.8 reste intacte comme version de secours. La syntaxe Swift est vérifiée si `swiftc` est installé. La compilation et le comportement tactile doivent être validés sur Codemagic et iPhone.
