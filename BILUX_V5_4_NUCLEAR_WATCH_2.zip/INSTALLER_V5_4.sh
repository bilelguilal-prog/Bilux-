#!/usr/bin/env bash
set -euo pipefail
SOURCE_BRANCH="bilux-v5.3.2-slow-aura"
NEW_BRANCH="bilux-v5.4-watch-2"
BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH="$BASE_DIR/BILUX_V5_4_WATCH_2.patch"

if [[ "$(git rev-parse --show-toplevel 2>/dev/null)" != "$(pwd -P)" ]]; then
  echo "Erreur : execute ce script depuis la racine du depot BILUX."
  exit 1
fi
if [[ "$(git branch --show-current)" != "$SOURCE_BRANCH" ]]; then
  echo "Erreur : passe sur la branche $SOURCE_BRANCH avant l'installation."
  exit 1
fi
if ! git diff --quiet || ! git diff --cached --quiet; then
  echo "Erreur : des modifications suivies non enregistrees sont presentes ; garde-les en securite avant de continuer."
  exit 1
fi
if git show-ref --verify --quiet "refs/heads/$NEW_BRANCH"; then
  echo "Erreur : la branche locale $NEW_BRANCH existe deja ; installation stoppee."
  exit 1
fi
if ! git apply --check "$PATCH"; then
  echo "Erreur : le patch ne correspond pas exactement a cette base. Aucun fichier ne sera modifie."
  exit 1
fi

git switch -c "$NEW_BRANCH"
git apply --index "$PATCH"
git diff --cached --check
git commit -m "BILUX V5.4 - Nuclear Watch 2.0"
git push -u origin "$NEW_BRANCH"
echo ""
echo "✅ BILUX V5.4 poussee sur GitHub : $NEW_BRANCH"
echo "🧪 Codemagic : compiler le simulateur iOS PUIS le simulateur Apple Watch."
echo "⚠️ Ne pas preparer le build 10 avant que les deux compilations soient vertes."
