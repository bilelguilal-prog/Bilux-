# BILUX V5.4 — NUCLEAR WATCH 2.0

## Ce que cette version ajoute

- Une page d'accueil avec jauge circulaire XP/niveau/rang synchronisee depuis l'iPhone.
- Un tableau Santé (pas, calories actives, dernière mesure cardiaque, sommeil), avec permission de lecture et bouton pour rafraîchir.
- Une page Missions affichant les quêtes de l'iPhone et leur état d'avancement ; aucun XP n'est créé sur la montre.
- Une page Forge avec 4 types d'entraînement à choisir avant le départ (Musculation, Marche, Cardio, Mobilité), chronomètre persistant sur la montre, annulation confirmée, et envoi au journal iPhone.
- Aucun changement des modèles de données, des sauvegardes JSON, des règles de niveau ou du calcul d'XP.

La synchronisation existante `WatchConnectivity` est conservée. Aucun entraînement n'est écrit dans Apple Santé : il s'agit de séances BILUX manuelles. La catégorie de séance est vérifiée côté iPhone et les identifiants UUID évitent les doublons dans le journal.

## Installation sur iPhone + Codespaces

1. Sur GitHub, ouvrir `bilelguilal-prog/Bilux-`, sélectionner `bilux-v5.3.2-slow-aura`.
2. Charger **le ZIP** de ce correctif avec `Add file > Upload files`, puis valider le commit.
3. Dans Codespaces, depuis `/workspaces/Bilux-`, coller :

```bash
git switch bilux-v5.3.2-slow-aura && git pull --ff-only origin bilux-v5.3.2-slow-aura && unzip -o BILUX_V5_4_NUCLEAR_WATCH_2.zip -d /tmp/bilux-v54 && bash /tmp/bilux-v54/INSTALLER_V5_4.sh
```

Le script vérifie la branche, refuse les modifications suivies non enregistrées, teste le patch, crée `bilux-v5.4-watch-2`, commit et push les changements. Ne pas fusionner dans main à cette étape.

## Vérification avant TestFlight

Dans Codemagic, brancher **bilux-v5.4-watch-2** :

1. Workflow `BILUX - Verifier le projet iOS (sans Apple Developer)`.
2. Workflow `BILUX V4.1 - Verifier Apple Watch (sans signature)` — indispensable car cette version modifie principalement watchOS.

Si les deux workflows sont verts, revenir dans Codespaces, sur la branche `bilux-v5.4-watch-2`, puis lancer :

```bash
bash /tmp/bilux-v54/PREPARER_BUILD_10.sh
```

Le script vérifie que les fichiers `Info.plist` iOS ET Watch sont au build 9, puis les passe au build 10, commite et pousse. Ensuite utiliser `BILUX - Publier sur TestFlight (compte Apple payant requis)` sur la branche `bilux-v5.4-watch-2`.

## Tests sur appareils

- Vérifier que le build 1.0 (10) est traité dans App Store Connect et distribué au groupe de test interne.
- Mettre à jour BILUX iPhone et vérifier l'installation de BILUX Watch sur la montre.
- Ouvrir BILUX sur l'iPhone une fois pour synchroniser. Confirmer rang, niveau, XP et date de synchronisation sur la montre.
- Autoriser Santé facultativement puis comparer pas et calories à Apple Santé. La fréquence cardiaque n'est PAS continue.
- Démarrer `Marche` ; attendre au moins 60 secondes ; terminer. Vérifier qu'une seule séance intitulée Marche apparaît dans l'historique iPhone et que les XP suivent les mêmes règles que d'habitude.
- Vérifier que quitter/revenir sur la page Forge ne remet pas le chrono à zéro, et que `Abandonner` ne crée pas de séance.
- Importer sa sauvegarde JSON **seulement en cas de besoin**, après avoir vérifié son contenu.

## Sécurité et limites

Le patch ne touche ni à l'historique, ni aux sauvegardes JSON, ni aux autres modules iPhone. La compilation SwiftUI doit être validée sur les machines macOS de Codemagic ; le contrôle local ne vérifie que la syntaxe et l'application du patch. Les séances Apple Watch sont du chronométrage manuel, **pas** une séance HKWorkout native avec mesure cardio en direct.
