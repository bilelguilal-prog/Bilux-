#!/usr/bin/env bash
set -euo pipefail
BRANCH="bilux-v5.4-watch-2"

if [[ "$(git rev-parse --show-toplevel 2>/dev/null)" != "$(pwd -P)" ]]; then
  echo "Erreur : execute ce script depuis la racine du depot BILUX."
  exit 1
fi
if [[ "$(git branch --show-current)" != "$BRANCH" ]]; then
  echo "Erreur : la branche attendue est $BRANCH."
  exit 1
fi
if ! git diff --quiet || ! git diff --cached --quiet; then
  echo "Erreur : des modifications suivies non enregistrees sont presentes."
  exit 1
fi
python3 - <<'PY'
from pathlib import Path
import plistlib
paths = [Path('BiluxIOS/Info.plist'), Path('BiluxWatch/Info.plist')]
values = []
for path in paths:
    value = plistlib.loads(path.read_bytes())
    old = str(value.get('CFBundleVersion'))
    if old != '9':
        raise SystemExit(f'ARRET : {path} possede le build {old} au lieu de 9. Aucune modification.')
    values.append(value)
for path, value in zip(paths, values):
    value['CFBundleVersion'] = '10'
    with path.open('wb') as out:
        plistlib.dump(value, out, sort_keys=False)
    print(f'✅ {path}: build 9 -> 10')
PY
git add BiluxIOS/Info.plist BiluxWatch/Info.plist
git diff --cached --check
git commit -m "BILUX V5.4 - Build 10 iPhone et Apple Watch"
git push origin "$BRANCH"
echo "✅ Build 10 envoye sur GitHub. Publier seulement apres les tests simulateur iOS et watchOS."
