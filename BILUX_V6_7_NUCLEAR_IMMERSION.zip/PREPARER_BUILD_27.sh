#!/usr/bin/env bash
set -euo pipefail
BRANCH='bilux-v6.7-nuclear-immersion'
fail() { echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Se placer à la racine du dépôt.'
[[ "$(git branch --show-current)" == "$BRANCH" ]] || fail "Branche attendue : $BRANCH"
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications Git suivies non enregistrées.'
git diff --cached --quiet || fail 'Index Git non vide.'
grep -q 'private struct BILUXV67Contemplation: View' BiluxIOS/BiluxScreens.swift || fail 'Moteur V6.6 absent.'
grep -q 'private struct V65DepthCompositing: View' BiluxIOS/BiluxScreens.swift || fail 'Profondeur V6.5 absente.'
grep -q 'private struct V63NuclearMasteryView: View' BiluxIOS/BiluxScreens.swift || fail 'Maîtrise RPG V6.3 absente.'
[[ -f scripts/assign_widget_signing.py ]] || fail 'Script de signature WidgetKit absent.'
TEMP="$(mktemp -d)"; trap 'rm -rf "$TEMP"' EXIT
python3 - "$TEMP" <<'PY'
from pathlib import Path
import plistlib, sys
repo = Path.cwd(); temp = Path(sys.argv[1]); old = '26'; new = '27'
paths = ('BiluxIOS/Info.plist', 'BiluxWatch/Info.plist',
         'BiluxWatchWidget/Info.plist')
for relative in paths:
    try: data = plistlib.loads((repo/relative).read_bytes())
    except Exception as exc: raise SystemExit(f'❌ {relative} invalide : {exc}')
    if str(data.get('CFBundleVersion')) != old:
        raise SystemExit(f'❌ Build {old} attendu dans {relative}; aucun fichier modifié.')
    data['CFBundleVersion'] = new
    p = temp/relative; p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(plistlib.dumps(data, sort_keys=False))
project = repo/'BiluxIOS.xcodeproj/project.pbxproj'
s = project.read_text(encoding='utf-8')
if s.count('CURRENT_PROJECT_VERSION = 26;') != 2 or 'BiluxWatchWidget' not in s:
    raise SystemExit('❌ Version du projet inattendue. Aucun fichier modifié.')
p = temp/'BiluxIOS.xcodeproj/project.pbxproj';p.parent.mkdir(parents=True, exist_ok=True)
p.write_text(s.replace('CURRENT_PROJECT_VERSION = 26;', 'CURRENT_PROJECT_VERSION = 27;'), encoding='utf-8')
print('✅ Build 27 prêt : iPhone, Apple Watch et WidgetKit synchronisés.')
PY
FILES=(BiluxIOS/Info.plist BiluxWatch/Info.plist BiluxWatchWidget/Info.plist BiluxIOS.xcodeproj/project.pbxproj)
for relative in "${FILES[@]}"; do cp "$TEMP/$relative" "$relative"; done
git add -- "${FILES[@]}"
git diff --cached --check || fail 'Diff Git invalide.'
git commit -m 'BILUX V6.7 - Build 27 iPhone Watch WidgetKit'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
    git push origin "$BRANCH" || fail 'Commit local enregistré. Réessayer git push.'
else
    echo '🧪 Test local : push désactivé.'
fi
echo '✅ Build 27 préparé. TestFlight après validation Codemagic.'
