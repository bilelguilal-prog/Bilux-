# ☢️ BILUX V6.7 — NUCLEAR IMMERSION

**Base testée :** branche `bilux-v6.6-cinematic-storm`, **build 26**.

**Nouvelle branche :** `bilux-v6.7-nuclear-immersion`.

**Build TestFlight :** **27**, uniquement après les deux compilations Codemagic sans signature au vert.

## 1 — Ce que tu obtiens

- **Mode contemplation** : portrait plein écran et foudre Thunder Depth/Cinematic Storm V6.6, disponible depuis **Accueil → CONTEMPLER MON PERSONNAGE** ou **Ascension → MODE CONTEMPLATION · PLEIN ÉCRAN**. Dans Ascension, le bouton est désactivé si tu consultes une forme verrouillée.
- **Réacteur interactif** : touche le réacteur au niveau du torse, ou le bouton **DÉCHARGE**, pour obtenir une pulsation lumineuse et un retour haptique. Le moteur de foudre V6.6 est réutilisé, pas remplacé.
- **Interface masquable** : bouton **MASQUER L'INTERFACE** pour profiter du portrait. **FERMER** demeure toujours visible.
- **Cinématique d'éveil en 3 phases** : activation du noyau → compression énergétique → transformation révélée. L'éveil se déclenche lors d'un palier de transformation comme avant. Tu peux aussi rejouer la cinématique d'une forme déjà débloquée, sans jamais gagner d'XP à nouveau.
- **Ambiance sonore facultative**, générée localement sans média ni réseau. Dans **Ascension → Effets visuels**, active **Ambiance sonore cinématique**. **Désactivée par défaut.** Respecte le mode Silence du téléphone et ne joue aucun son en arrière-plan. La contemplation possède son propre bouton haut-parleur, qui reflète le même réglage.
- **Accessibilité** : « Réduire les animations » et « Animations nucléaires » désactivent les animations. Éviter de solliciter le téléphone lors d'une séance sportive en cours.
- **Conservation** : aucun changement au modèle JSON, niveaux/XP, quêtes, arbre de maîtrise, Apple Santé, Nuclear Live, code Watch ni widget. Aucun fichier de données personnelles n'est empaqueté.

**Limite :** rendu pseudo-3D fondé sur l'occlusion Apple Vision déjà présente depuis V6.5. Il ne s'agit pas d'un modèle 3D. Le détourage peut varier selon l'illustration.

## 2 — Sauvegarde privée

Dans BILUX, exporte la sauvegarde JSON dans Fichiers/iCloud privé. Ne la dépose pas dans GitHub (elle peut contenir des informations de santé).

## 3 — Depuis ton iPhone, déposer le ZIP sur GitHub

1. Ouvre https://github.com/bilelguilal-prog/Bilux-
2. Sélectionne **`bilux-v6.6-cinematic-storm`** (build 26).
3. **Add file → Upload files** → dépose **`BILUX_V6_7_NUCLEAR_IMMERSION.zip`** à la racine du dépôt.
4. Valide le commit.

## 4 — Installation dans Codespaces

Dans un terminal situé à la racine de BILUX, colle **une seule commande** :

```bash
git switch bilux-v6.6-cinematic-storm && git pull --ff-only origin bilux-v6.6-cinematic-storm && unzip -o BILUX_V6_7_NUCLEAR_IMMERSION.zip -d /tmp/bilux-v67 && bash /tmp/bilux-v67/INSTALLER_V6_7.sh
```

L'installateur contrôle le build 26, les trois cibles, la présence du widget, les moteurs V6.5/V6.6/V6.3 et la structure du code. Il écrit dans un dossier temporaire, valide la **syntaxe** Swift si `swiftc` est disponible, crée la branche **`bilux-v6.7-nuclear-immersion`**, et ne modifie que `BiluxIOS/BiluxScreens.swift` avant le commit/push. Si un contrôle échoue, ne force pas l'étape et partage son message.

## 5 — Tests de compilation Codemagic

Sur la branche `bilux-v6.7-nuclear-immersion`, lance les workflows **sans signature** habituels :

1. **BILUX — Vérifier le projet iOS** ;
2. **BILUX V4.1 — Vérifier Apple Watch**.

**N'utilise pas TestFlight si l'un des deux est rouge.** Le contrôle de syntaxe dans Codespaces ne remplace pas un build Xcode. Si l'étape iOS échoue, ouvre la **première** erreur Swift du log.

## 6 — Build 27 et TestFlight

Quand **les deux compilations sont vertes**, dans Codespaces lance :

```bash
bash /tmp/bilux-v67/PREPARER_BUILD_27.sh
```

Le script met à jour les `CFBundleVersion` iPhone, Watch et WidgetKit **26 → 27**, puis les deux occurrences de `CURRENT_PROJECT_VERSION` **26 → 27** dans le projet Xcode. Il crée/pousse un commit sur la branche V6.7.

Dans Codemagic, sélectionne **BILUX — Publier sur TestFlight** et la branche `bilux-v6.7-nuclear-immersion`. Après traitement Apple, installe **1.0 (27)** depuis TestFlight.

## 7 — Test de la V6.7 sur iPhone

1. **Accueil** : touche **CONTEMPLER MON PERSONNAGE**. Le portrait doit s'afficher en plein écran et la foudre garder le rythme maîtrisé de V6.6.
2. Touche le **réacteur** dans la zone du torse : une pulsation lumineuse doit partir du centre. Tu peux aussi appuyer sur **DÉCHARGE**.
3. Touche **MASQUER L'INTERFACE**, puis **AFFICHER L'INTERFACE**. Le bouton **FERMER** doit toujours fonctionner.
4. Dans **Ascension → Effets visuels**, active **Ambiance sonore cinématique**. Quitte le mode Silence de l'iPhone pour entendre les sons, puis réessaie un déclenchement. Désactive le son : il doit cesser.
5. Dans **Ascension**, sélectionne une **transformation acquise**, touche **REVOIR LA CINÉMATIQUE**. Observe les trois phases, puis teste **PASSER** et **CONTINUER L'ASCENSION**.
6. Active **Réduire les animations** dans Réglages iOS et vérifie que l'interface reste utilisable sans les effets.
7. Ferme et rouvre BILUX. Vérifie l'XP, le niveau, les compétences, le journal, Nuclear Live et le widget Apple Watch.

**Note :** le réacteur animé est un effet esthétique, non une mesure biométrique. L'animation ne dépend pas du rythme cardiaque.

## 8 — Précautions et secours

Garde le **build 26 V6.6** disponible sur TestFlight. Le nouveau code ne supprime ni ne migre le journal, mais une sauvegarde avant mise à jour reste recommandée. Pas de création de fichiers audio externes, de permissions Santé supplémentaires, ni de modification du widget.

**Tests locaux réalisés** : application du patch sur une reconstruction source V6.6, parsing Swift, création de branche, préparation du build 27 et vérification des trois numéros de version. **Non réalisé localement** : compilation Xcode/iOS et essai réel sur iPhone (à effectuer avec Codemagic et TestFlight).
