#!/usr/bin/env python3
"""V6.6 build26 -> V6.7 Nuclear Immersion, safe staging, UI-only modifications."""
from pathlib import Path
import plistlib
import sys

if len(sys.argv) != 3:
    raise SystemExit('Usage: APPLIQUER_V6_7.py REPO TEMP')
repo, temp = [Path(x).resolve() for x in sys.argv[1:]]
here = Path(__file__).resolve().parent

def fail(message):
    raise SystemExit('❌ ' + message + ' — aucun fichier du projet modifié')

def once(s, old, new, label):
    count = s.count(old)
    if count != 1:
        fail(f'{label}: une occurrence attendue, {count} trouvées')
    return s.replace(old, new, 1)

for rel in ('BiluxIOS/Info.plist', 'BiluxWatch/Info.plist', 'BiluxWatchWidget/Info.plist'):
    try: value = plistlib.loads((repo / rel).read_bytes())['CFBundleVersion']
    except Exception as exc: fail(f'{rel} introuvable ou malformé : {exc}')
    if str(value) != '26': fail(f'{rel} : build 26 attendu, trouvé {value}')

if not (repo/'scripts/assign_widget_signing.py').is_file(): fail('Signature widget non présente')
if not (repo/'BiluxWatchWidget/NuclearLiveWidget.swift').is_file(): fail('Widget non présent')
src = repo/'BiluxIOS/BiluxScreens.swift'
model = repo/'BiluxIOS/Models.swift'
if not src.is_file() or not model.is_file(): fail('Sources iPhone absentes')
s = src.read_text(encoding='utf-8')
if 'struct BILUXV67Contemplation: View' in s: fail('V6.7 déjà installée')
for marker in ('private static func cinematicEnvelope(age: Double',
               'private struct V65DepthCompositing: View',
               'private struct V63NuclearMasteryView: View',
               'private struct BILUXV57RankCinema: View',
               'Text("CINEMATIC STORM · V6.6")'):
    if s.count(marker) != 1: fail(f'Moteur de base inattendu : {marker}')
if 'struct NuclearLiveReport:' not in model.read_text(encoding='utf-8'):
    fail('Rapports Nuclear Live absents')

s = once(s, 'import CoreImage\n', 'import CoreImage\nimport AVFoundation\n', 'Import AVFoundation')
cinema_start = s.index('private struct BILUXV57RankCinema: View')
cinema_end = s.index('\nprivate struct BILUXV57BossPortrait: View', cinema_start)
replacement = (here/'IMMERSION_ENGINE_V67.swift.txt').read_text('utf-8').rstrip('\n')
s = s[:cinema_start] + replacement + s[cinema_end:]

# Home: one optional, discoverable entrance and a fullscreen cover.
s = once(s, '    @State private var showLegacy = false\n    @State private var cinematicStage: NuclearStage? = nil\n',
         '    @State private var showLegacy = false\n    @State private var cinematicStage: NuclearStage? = nil\n    @State private var showImmersion = false\n',
         'Home state')
s = once(s, '                    heroPanel\n                    Button { showLegacy = true } label: {',
         '''                    heroPanel
                    Button { showImmersion = true } label: {
                        Label("CONTEMPLER MON PERSONNAGE", systemImage: "viewfinder")
                            .font(.subheadline.bold())
                            .frame(maxWidth: .infinity, minHeight: 45)
                    }
                    .buttonStyle(.bordered)
                    .tint(Nuclear.paleGold)
                    .accessibilityIdentifier("bilux.v67.openImmersion.home")
                    Button { showLegacy = true } label: {''',
         'Home immersion entry')
home_start = s.index('struct HomeScreen: View')
home_end = s.index('\nprivate func count(', home_start)
home = s[home_start:home_end]
needle = '''            .fullScreenCover(item: $cinematicStage) { stage in
                BILUXV57RankCinema(stage: stage, effectsEnabled: effectsEnabled) {'''
if home.count(needle) != 1: fail('Home cinéma introuvable')
home = home.replace(needle, '''            .fullScreenCover(isPresented: $showImmersion) {
                BILUXV67Contemplation(stage: homeStage, level: journal.heroLevel,
                    masteryCount: V63MasterySnapshot.evaluate(journal.data).unlockedTotal,
                    dominantPath: V64StormMastery.dominantPath(journal.data),
                    effectsEnabled: effectsEnabled) { showImmersion = false }
            }
            .fullScreenCover(item: $cinematicStage) { stage in
                BILUXV57RankCinema(stage: stage, effectsEnabled: effectsEnabled) {''', 1)
s = s[:home_start] + home + s[home_end:]

# Ascension: entrance for acquired forms, sound setting, fullscreen presentation.
asc_start = s.index('struct AscensionScreen: View')
asc_end = s.index('\n// MARK: - BILUX V5.5', asc_start)
a = s[asc_start:asc_end]
a = once(a, '    @State private var cinematicStage: NuclearStage? = nil\n    var body: some View {',
         '''    @State private var cinematicStage: NuclearStage? = nil
    @State private var showImmersion = false
    @AppStorage("bilux.v67.soundEnabled") private var immersionSound = false
    var body: some View {''', 'Ascension state')
a = once(a, '                    SectionCaption(title: "Ton ascension")',
         '''                    Button { showImmersion = true } label: {
                        Label("MODE CONTEMPLATION · PLEIN ÉCRAN", systemImage: "viewfinder")
                            .font(.subheadline.bold())
                            .frame(maxWidth: .infinity, minHeight: 46)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(Nuclear.gold)
                    .disabled(selectedStage > journal.unlockedStageIndex)
                    .accessibilityIdentifier("bilux.v67.openImmersion.ascension")
                    SectionCaption(title: "Ton ascension")''',
         'Ascension immersion button')
a = once(a, '                        Toggle("Animations nucléaires", isOn: $effectsEnabled).tint(Nuclear.gold)',
         '''                        Toggle("Animations nucléaires", isOn: $effectsEnabled).tint(Nuclear.gold)
                        Toggle("Ambiance sonore cinématique", isOn: $immersionSound)
                            .tint(Nuclear.gold)
                        Text("Sons nucléaires originaux, optionnels et désactivés par défaut. Le mode Silence de l’iPhone est respecté. Aucun son en arrière-plan.")
                            .font(.caption2).foregroundStyle(Nuclear.muted)''',
         'Ascension audio settings')
a = once(a, 'Text("CINEMATIC STORM · V6.6")', 'Text("NUCLEAR IMMERSION · V6.7")', 'Version label')
a = once(a, '''            .fullScreenCover(item: $cinematicStage) { stage in
                BILUXV57RankCinema(stage: stage, effectsEnabled: effectsEnabled) {''',
         '''            .fullScreenCover(isPresented: $showImmersion) {
                BILUXV67Contemplation(stage: NuclearStage.all[selectedStage],
                    level: journal.heroLevel,
                    masteryCount: V63MasterySnapshot.evaluate(journal.data).unlockedTotal,
                    dominantPath: V64StormMastery.dominantPath(journal.data),
                    effectsEnabled: effectsEnabled) { showImmersion = false }
            }
            .fullScreenCover(item: $cinematicStage) { stage in
                BILUXV57RankCinema(stage: stage, effectsEnabled: effectsEnabled) {''',
         'Ascension fullscreen cover')
s = s[:asc_start] + a + s[asc_end:]

out = temp/'BiluxIOS/BiluxScreens.swift'
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(s, encoding='utf-8')
print('✅ BILUX V6.7 : contemplation, réacteur interactif, cinéma en trois phases, son optionnel.')
print('✅ Journal, XP, Santé, Nuclear Live, Watch et WidgetKit inchangés.')
