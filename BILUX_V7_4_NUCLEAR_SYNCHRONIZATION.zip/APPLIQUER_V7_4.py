#!/usr/bin/env python3
"""BILUX V7.4: single after-save report, no model, ledger or XP rewrites."""
from pathlib import Path
import plistlib
import sys

if len(sys.argv) != 3:
    raise SystemExit('Usage: APPLIQUER_V7_4.py <repo> <staging>')
root, stage = (Path(path).resolve() for path in sys.argv[1:])
here = Path(__file__).resolve().parent

def fail(msg):
    raise SystemExit('❌ ' + msg + ' — aucune source modifiée.')

def once(src, needle, label):
    c = src.count(needle)
    if c != 1:
        fail(f'{label}: une occurrence attendue, {c} trouvée(s)')
    return needle

# La base stable est la V7.3 (build 33) validée par l'utilisateur.
for rel in ('BiluxIOS/Info.plist', 'BiluxWatch/Info.plist', 'BiluxWatchWidget/Info.plist'):
    try:
        build = str(plistlib.loads((root/rel).read_bytes())['CFBundleVersion'])
    except Exception as e:
        fail(f'{rel} absent ou invalide: {e}')
    if build != '33':
        fail(f'{rel}: build 33 attendu, reçu {build}')

for rel, tokens in {
    'BiluxIOS/Models.swift': ['struct WorkoutSession:', 'struct BiluxData:', 'enum BILUXV55Progression'],
    'BiluxIOS/BiluxStore.swift': ['func add(_ session: WorkoutSession)', 'var totalXP:'],
    'BiluxWatch/WatchRootView.swift': ['V69WatchQuestsPage', 'V61LiveWorkoutView().tag(5)'],
    'BiluxWatchWidget/NuclearLiveWidget.swift': ['BILUXWatchWidgetPack: WidgetBundle'],
}.items():
    try: contents = (root/rel).read_text(encoding='utf8')
    except Exception as e: fail(f'Fichier requis manquant {rel}: {e}')
    for token in tokens:
        if token not in contents: fail(f'Élément requis absent {token} dans {rel}')
if not (root/'scripts/assign_widget_signing.py').is_file():
    fail('Script de signature WidgetKit non retrouvé')

source = root/'BiluxIOS/BiluxScreens.swift'
s = source.read_text(encoding='utf8')
for marker in ('private struct V70NuclearForge: View', 'private struct V70NuclearAnalytics: View',
               'private struct V71ExercisePerformance: View', 'private struct V71RecordCelebration: View',
               'private struct V73EternalForgeHub: View', 'private enum V73CampaignEngine',
               'private enum BILUXV56Boss:', 'private struct V72AwakeningChamber: View'):
    once(s, marker, marker)
if 'private struct V74UnifiedDebrief: View' in s: fail('La V7.4 est déjà présente')

start = s.index('private struct V70NuclearForge: View')
end = s.index('private struct V70NuclearAnalytics: View', start)
forge = s[start:end]

# Les records restent calculés par la Forge ; on fusionne leur célébration dans le débrief unique.
old = '    @State private var showRecordCelebration = false\n'
once(forge, old, 'Ancienne présentation des records')
forge = forge.replace(old,
    '    @State private var v74LatestReport: V74SessionReport?\n'
    '    @State private var showV74Report = false\n', 1)

old = '''        .sheet(isPresented: $showRecordCelebration) {
            V71RecordCelebration(records: achievedRecords)
        }
'''
once(forge, old, 'Sheet V7.1 records')
forge = forge.replace(old, '''        .sheet(isPresented: $showV74Report) {
            if let v74LatestReport {
                V74UnifiedDebrief(report: v74LatestReport)
            }
        }
''', 1)

old = '''                        Button("RETOUR AU JOURNAL") { dismiss() }
'''
once(forge, old, 'Retour au journal Forge')
forge = forge.replace(old, '''                        if v74LatestReport != nil {
                            Button {
                                showV74Report = true
                            } label: {
                                Label("REVOIR LE DÉBRIEF COMPLET", systemImage: "doc.text.magnifyingglass")
                            }
                            .buttonStyle(.bordered).tint(Nuclear.purple)
                        }
''' + old, 1)

# Capture avant mutation pour mesurer les VRAIS écarts d’XP, boss et campagne.
old = '''        let previous = knownRecords
        var newRecords: [String] = []
'''
once(forge, old, 'Capture des records avant sauvegarde')
forge = forge.replace(old, '''        let xpBefore = journal.totalXP
        let guardiansBefore = Dictionary(uniqueKeysWithValues: BILUXV56Boss.allCases.map {
            ($0.id, $0.countedDays(in: journal.data))
        })
        let ledgerBefore = try? V73LedgerStore.load()
        let campaignBefore: Int? = {
            guard let launch,
                  let ledger = ledgerBefore,
                  let plan = ledger.plans.first(where: { $0.id == launch.planID }) else { return nil }
            return V73CampaignEngine.progress(plan: plan, ledger: ledger,
                                              workouts: journal.data.workouts).counted
        }()
        let previous = knownRecords
        var newRecords: [String] = []
''', 1)

# Conserver l’unique appel journal.add(), le lien programme et les messages existants.
old = '''        achievedRecords = Array(Set(newRecords)).sorted()
        saved = true
        showRecordCelebration = !achievedRecords.isEmpty
'''
once(forge, old, 'Fin de sauvegarde V7.1 / V7.3')
forge = forge.replace(old, '''        achievedRecords = Array(Set(newRecords)).sorted()
        let guardianImpacts = BILUXV56Boss.allCases.map { boss in
            V74GuardianImpact(id: boss.id, title: boss.title,
                              before: guardiansBefore[boss.id] ?? 0,
                              after: boss.countedDays(in: journal.data),
                              target: boss.target)
        }
        var campaignImpact: V74CampaignImpact?
        if let launch, let before = campaignBefore,
           programLinkWarning == nil,
           let ledgerAfter = try? V73LedgerStore.load(),
           let plan = ledgerAfter.plans.first(where: { $0.id == launch.planID }) {
            let after = V73CampaignEngine.progress(plan: plan, ledger: ledgerAfter,
                                                    workouts: journal.data.workouts).counted
            campaignImpact = V74CampaignImpact(title: launch.planName, before: before, after: after)
        }
        v74LatestReport = V74SessionReport(workout: savedWorkout,
                                            records: achievedRecords,
                                            xpBefore: xpBefore,
                                            xpAfter: journal.totalXP,
                                            guardians: guardianImpacts,
                                            campaign: campaignImpact,
                                            campaignNote: programLinkWarning)
        saved = true
        showV74Report = true
''', 1)

once(forge, '        journal.add(savedWorkout)\n', 'Un seul enregistrement Forge')
if 'showRecordCelebration' in forge: fail('Ancien sheet V7.1 encore présent : risque de double présentation')
s = s[:start] + forge + s[end:]
module = (here/'V74_UNIFIED_DEBRIEF.swift.txt').read_text(encoding='utf8')
for marker in ('private struct V74SessionReport', 'private struct V74UnifiedDebrief',
               'private struct V74GuardianImpact', 'private struct V74CampaignImpact'):
    once(module, marker, marker)
s = s.rstrip() + '\n' + module.rstrip() + '\n'
output = stage/'BiluxIOS/BiluxScreens.swift'
output.parent.mkdir(parents=True, exist_ok=True)
output.write_text(s, encoding='utf8')
print('✅ BILUX V7.4 : une seule fenêtre de débrief après sauvegarde Forge.')
print('✅ XP avant/après, Gardiens, dégâts Eternal Forge et records dérivés du journal réel.')
print('✅ Aucune modification aux données, XP, HealthKit, Watch, WidgetKit ou signatures.')
