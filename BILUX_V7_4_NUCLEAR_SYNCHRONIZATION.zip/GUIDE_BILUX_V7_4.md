# ☢️ BILUX V7.4 — NUCLEAR SYNCHRONIZATION

**Version source validée :** `bilux-v7.3-eternal-forge` — build **33**.  
**Nouvelle branche :** `bilux-v7.4-nuclear-synchronization`.  
**Prochain TestFlight :** build **34** (iPhone + Watch + widget).

## Ce que change la V7.4

Après l'enregistrement d'une vraie séance dans **La Forge** (manuelle ou démarrée depuis un programme Eternal Forge), **un seul débriefing s'ouvre** :

- Récapitulatif d'exercices, séries, volume de musculation et durée.
- Nouvelles meilleures charges et célébration **RECORD BRISÉ ⚡**, intégrée dans la même fenêtre (remplace la fenêtre de record séparée V7.1).
- **XP avant/après la sauvegarde**, mesurés depuis le total XP réel du moteur existant, et différence affichée. Aucun XP supplémentaire n'est accordé.
- **Gardiens historiques** : variation réelle du nombre de journées comptées pour le Gardien du Réacteur et le Souverain du Néant (ces boss n'utilisent pas des PV numériques dans leur moteur).
- **Réacteur du Néant V7.3** : si la séance est liée avec succès à un programme, progression de campagne avant/après et dégâts réels (`100 PV` par nouvelle journée éligible). Si elle n'est pas éligible ou pas liée, le débrief ne prétend pas infliger des dégâts.
- Bouton **REVOIR LE DÉBRIEF COMPLET** tant que l'écran de la Forge enregistrée reste ouvert.

**Important :** le débriefing est un instantané à l'enregistrement : il ne crée pas de seconde séance ni de fichier de sauvegarde. Les anciennes séances restent dans le journal et les vues de statistiques ; cette version ne reconstitue pas de faux XP historiques. Les programmes V7.3 sont conservés dans leur stockage existant et **ne sont toujours pas dans le JSON principal**.

## 0. Deux sauvegardes avant installation

1. Dans BILUX, exporte le **journal JSON principal** et conserve-le dans Fichiers/iCloud privé.
2. Si tu as créé des programmes V7.3 : **Eternal Forge → Sauvegarde des programmes** → exporte aussi `BILUX-V7.3-programmes-sauvegarde.json`.

Ne place jamais ces sauvegardes contenant des données personnelles dans GitHub.

## 1. Mettre le ZIP dans GitHub

1. Depuis iPhone : `https://github.com/bilelguilal-prog/Bilux-`.
2. Sélectionne **`bilux-v7.3-eternal-forge`**.
3. **Add file → Upload files** : ajoute `BILUX_V7_4_NUCLEAR_SYNCHRONIZATION.zip` à la **racine** du dépôt.
4. **Commit changes**.

## 2. Codespaces — installation et build 34 en une commande

Dans un terminal ouvert à la racine du dépôt :

```bash
git switch bilux-v7.3-eternal-forge && git pull --ff-only origin bilux-v7.3-eternal-forge && unzip -o BILUX_V7_4_NUCLEAR_SYNCHRONIZATION.zip -d /tmp/bilux-v74 && bash /tmp/bilux-v74/INSTALLER_V7_4.sh && bash /tmp/bilux-v74/PREPARER_BUILD_34.sh
```

L'installateur :

- vérifie **le build 33** dans les trois applications et les composants indispensables V7.3 ;
- prépare la modification du fichier `BiluxIOS/BiluxScreens.swift` **sans modifier les fichiers du dépôt avant les validations** ;
- vérifie la syntaxe Swift si `swiftc` est installé ;
- crée et pousse `bilux-v7.4-nuclear-synchronization` ;
- prépare puis pousse le **build 34** pour iPhone, Watch et WidgetKit.

Les ZIP ajoutés restent dans la branche précédente ; le script ne s'appuie pas sur l'existence du ZIP dans la branche créée une fois les scripts décompressés dans `/tmp`.

**Si `/tmp` a disparu après installation mais avant préparation du build 34** : reprends le ZIP depuis GitHub en le téléchargeant sur Codespaces ou réextrais-le depuis la branche de base, puis lance uniquement `PREPARER_BUILD_34.sh` sur `bilux-v7.4-nuclear-synchronization`. **Ne réexécute pas l'installateur.**

**Ne lance pas deux fois la préparation du build 34** : elle vérifie qu'il est encore au build 33.

## 3. Codemagic — un seul build

- **Branche** : `bilux-v7.4-nuclear-synchronization`
- **Workflow** : `BILUX — Publier sur TestFlight`
- **Build** : **34**

Comme convenu, **aucune compilation supplémentaire pour simulateur avant TestFlight**. Une analyse syntaxique Swift et une simulation de préparation du build ont été exécutées localement, mais le typage SwiftUI et la compilation Apple réels nécessitent Xcode/Codemagic. Si le build échoue, récupérer le journal de la première étape rouge avant de relancer.

## 4. Validation après installation

1. Ouvre **BILUX → Sport → Forge** (ou **Eternal Forge → DÉMARRER DANS LA FORGE**).
2. Enregistre une **véritable** séance, avec ses vrais exercices et charges. Ne crée pas de séance factice pour tester : cela fausserait l'XP et les records.
3. Le débrief unique doit apparaître immédiatement avec durée, exercices, séries, volume et **XP avant/après**.
4. S'il y a un vrai nouveau record, **RECORD BRISÉ** apparaît **dans le même débrief** (pas une seconde fenêtre par-dessus).
5. Si tu as utilisé un programme, vérifie la rubrique **Eternal Forge** : `−100 PV` uniquement si la journée est éligible ; sinon `0 dégât` et pas d'XP ajouté par le débrief.
6. Ferme le débrief, puis touche **REVOIR LE DÉBRIEF COMPLET** sur l'écran de la Forge pour le revoir.
7. Vérifie que la séance apparaît **une seule fois** dans l'historique, que les XP/compétences n'ont pas été dupliqués, et que Nuclear Live, Watch 4.1 et les complications fonctionnent toujours.

## 5. Protection des acquis

Seul **`BiluxIOS/BiluxScreens.swift`** est modifié par l'installation, et les quatre fichiers de version Apple par le préparateur de build. Ni les structures `BiluxData`, ni le moteur XP, ni HealthKit, ni le stockage Eternal Forge, ni la Watch, ni WidgetKit, ni la signature Codemagic ne sont modifiés.

**La V7.3 / build 33 reste la version de secours jusqu'à validation sur les appareils.**
