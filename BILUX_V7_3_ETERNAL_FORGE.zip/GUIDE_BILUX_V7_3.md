# ☢️ BILUX V7.3 — ETERNAL FORGE

**Base validée :** `bilux-v7.2-nuclear-awakening` (build 32).  
**Branche cible :** `bilux-v7.3-eternal-forge`.  
**Prochain build TestFlight :** **33**, iPhone + Watch + WidgetKit.

## Les nouveautés

**Programmes personnalisés** : compose jusqu'à sept journées par programme, avec groupe musculaire, durée indicative, exercices, séries, répétitions et charges cibles. Les journées sont flexibles ; aucun calendrier rigide et aucune pénalité de repos.

**Forge connectée** : chaque journée propose le bouton **DÉMARRER DANS LA FORGE**, qui préremplit la Forge V7.0 existante. L'entraînement n'est comptabilisé **que si tu enregistres réellement une séance**. Il s'ajoute une seule fois au journal BILUX, comme avant, et utilise les mêmes règles d'XP. Un clic sur un bouton de programme ne crée ni séance ni XP.

**Campagne Le Réacteur du Néant** : boss à quatre phases avec 1 200 PV, progression jusqu'à douze journées éligibles (−100 PV/jour). Une journée compte si la séance vient de ce programme, dure au moins dix minutes, contient les exercices de la journée, et si elle respecte une seule journée comptée par jour / au plus cinq par semaine. La campagne possède des récompenses **strictement cosmétiques** aux paliers 4, 8, 12 ; une cinématique de victoire est disponible au douzième palier. Les cosmétiques obtenus restent conservés dans le registre local. Les deux Gardiens historiques gardent leurs règles d'origine.

**Sauvegarde séparée des programmes** : les nouveaux programmes et liens vers les séances sont conservés dans le stockage local de l'application. Le format historique `BiluxData` ne change pas. **Important : les programmes V7.3 ne figurent pas dans l'export JSON principal de BILUX**. Dans *Eternal Forge → Sauvegarde des programmes*, exporte aussi le fichier `BILUX-V7.3-programmes-sauvegarde.json` si tu veux pouvoir les récupérer après une réinstallation. Un import fusionne les programmes sans écraser les autres.

## 0. Sauvegarde avant installation

Dans l'application actuelle BILUX, exporte le JSON principal dans l'app Fichiers / iCloud privé. Ne publie **aucune sauvegarde de données personnelles sur GitHub**.

## 1. GitHub sur iPhone

1. Ouvre ton dépôt `https://github.com/bilelguilal-prog/Bilux-`.
2. Sélectionne la branche **`bilux-v7.2-nuclear-awakening`**.
3. `Add file` → `Upload files` → ajoute **`BILUX_V7_3_ETERNAL_FORGE.zip`** à la racine.
4. Valide le commit.

## 2. Codespaces — une seule commande

Ouvre le terminal à la racine du dépôt. Colle le bloc :

```bash
git switch bilux-v7.2-nuclear-awakening && git pull --ff-only origin bilux-v7.2-nuclear-awakening && unzip -o BILUX_V7_3_ETERNAL_FORGE.zip -d /tmp/bilux-v73 && bash /tmp/bilux-v73/INSTALLER_V7_3.sh && bash /tmp/bilux-v73/PREPARER_BUILD_33.sh
```

Ce processus :
- vérifie que les trois plists sont au **build 32**, ainsi que les composants de la Forge, du Journal, des animations et de la Watch 4.1 ;
- construit le correctif dans un dossier temporaire, sans modifier la branche source en cas de contrôle négatif ;
- vérifie la syntaxe avec `swiftc` si disponible dans Codespaces (ne remplace pas la compilation Xcode) ;
- crée et publie `bilux-v7.3-eternal-forge` ;
- prépare et publie le **build 33** sur les cibles iPhone, Apple Watch et widget.

**Si le dossier `/tmp` a disparu** avant préparation du build 33, utilise :

```bash
unzip -o BILUX_V7_3_ETERNAL_FORGE.zip -d /tmp/bilux-v73 && bash /tmp/bilux-v73/PREPARER_BUILD_33.sh
```

Cette dernière commande ne fonctionne que sur la branche V7.3 avant que le build 33 ait déjà été préparé.

## 3. Codemagic — un seul build

- **Branche** : `bilux-v7.3-eternal-forge`
- **Workflow** : **BILUX — Publier sur TestFlight**
- **Build** : **33**

Comme convenu, pas de doubles builds simulateur préalables. La syntaxe Swift et les fonctions de calcul ont été vérifiées localement ; **le typage SwiftUI et la signature iOS seront validés par Xcode dans Codemagic**. Si le build échoue, transmets les premières lignes d'erreur de l'étape rouge ; ne relance pas sans analyse.

## 4. Tests sur ton iPhone

1. **Accueil → ETERNAL FORGE** : vérifie que l'écran des programmes s'ouvre.
2. **Créer un programme** : par exemple trois journées « Poussée », « Tirage » et « Jambes », avec une ou deux lignes d'exercice chacune.
3. **Ouvrir une journée dans la Forge** : les noms d'exercice et séries prévues doivent apparaître préremplis.
4. **Avant un véritable entraînement** : vérifier que ni XP ni progression de boss n'ont changé au simple lancement.
5. **Après un véritable entraînement consigné** : vérifier que la séance apparaît **une fois** dans l'historique, et que la campagne avance d'une journée si elle est éligible.
6. **Sauvegarde programmes** : produire et partager le JSON des programmes dans Fichiers/iCloud privé.
7. Vérifier le QG, la progression V7.1, la Chambre d'Éveil V7.2, Nuclear Live, la Watch 4.1 et la complication ⚡.

**N'invente pas de séances pour tester l'arène** : cela créerait de faux XP et fausserait ton journal. Le boss progresse avec tes vraies séances, progressivement.

## 5. Ce qui reste intact

- Données médicales, repas, ancien journal et export JSON historique.
- Calcul d'XP, rangs, titres, maîtrise, règles historiques des Gardiens.
- Forge de musculation existante, statistiques, records, animations et Chambre d'Éveil.
- HealthKit, Nuclear Live, application watchOS, WidgetKit, signatures Apple et Codemagic.

Seul `BiluxIOS/BiluxScreens.swift` est enrichi par l'installateur ; le script de build change ensuite les numéros des trois cibles. Le **build 32** reste la version de secours jusqu'à validation sur appareils.
