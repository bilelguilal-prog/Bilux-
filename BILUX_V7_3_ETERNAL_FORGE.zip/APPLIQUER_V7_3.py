#!/usr/bin/env python3
"""V7.3: additive SwiftUI patch over build 32; validates before modifying checkout."""
import plistlib
import sys
from pathlib import Path

if len(sys.argv) != 3:
    raise SystemExit('Usage: APPLIQUER_V7_3.py <repo> <dossier_staging>')
root, staging = [Path(p).resolve() for p in sys.argv[1:]]
here = Path(__file__).resolve().parent

def fail(message):
    raise SystemExit('❌ ' + message + ' — aucune source BILUX modifiée.')

def require_once(source, needle, label):
    n = source.count(needle)
    if n != 1:
        fail(f'{label}: une occurrence attendue, {n} trouvée(s)')
    return needle

for rel in ('BiluxIOS/Info.plist', 'BiluxWatch/Info.plist', 'BiluxWatchWidget/Info.plist'):
    try:
        v = str(plistlib.loads((root/rel).read_bytes())['CFBundleVersion'])
    except Exception as e:
        fail(f'Plist invalide {rel}: {e}')
    if v != '32': fail(f'{rel}: build 32 attendu, trouvé {v}')

prerequisites = {
    'BiluxIOS/Models.swift': ['struct WorkoutSet:', 'struct WorkoutExercise:', 'struct WorkoutSession:', 'struct BiluxData:', 'enum BILUXV55Progression'],
    'BiluxIOS/BiluxStore.swift': ['func add(_ session: WorkoutSession)', 'var totalXP:', 'var heroLevel:'],
    'BiluxWatch/WatchRootView.swift': ['V69WatchQuestsPage', 'V61LiveWorkoutView().tag(5)'],
    'BiluxWatchWidget/NuclearLiveWidget.swift': ['BILUXWatchWidgetPack: WidgetBundle'],
}
for rel, symbols in prerequisites.items():
    try: body = (root/rel).read_text(encoding='utf-8')
    except Exception as e: fail(f'Fichier manquant {rel}: {e}')
    for symbol in symbols:
        if symbol not in body: fail(f'{symbol} introuvable dans {rel}')
if not (root/'scripts/assign_widget_signing.py').is_file():
    fail('Script de signature du widget absent')

screen = root/'BiluxIOS/BiluxScreens.swift'
if not screen.is_file(): fail('BiluxScreens.swift introuvable')
s = screen.read_text(encoding='utf-8')
for symbol in (
    'struct HomeScreen: View', 'struct SportScreen: View', 'struct AscensionScreen: View',
    'private struct V70RebirthCommandDeck: View', 'private struct V70ForgeSportEntry: View',
    'private struct V70NuclearForge: View', 'private struct V70NuclearAnalytics: View',
    'private struct V71ExercisePerformance: View', 'private struct V71AscensionChronicleView: View',
    'private struct V72AwakeningEntry: View', 'private struct V72AwakeningChamber: View',
    'private struct V72CoreSeal: View', 'private enum BILUXV56Boss:',
):
    if s.count(symbol) != 1: fail('Base V7.2 incompatible : ' + symbol)
if 'private struct V73EternalForgeHub: View' in s: fail('La V7.3 est déjà installée')
if 'import UniformTypeIdentifiers' not in s: fail('Import des types JSON attendu')

# QG V7.2, entrée avant Chambre d'Éveil ; n'efface aucun lien.
start = s.index('private struct V70RebirthCommandDeck: View')
end = s.index('private struct V70ForgeSportEntry: View', start)
part = s[start:end]
anchor = '            V72AwakeningEntry().environmentObject(journal)\n'
require_once(part, anchor, 'Raccourci Chambre d’Éveil / QG')
part = part.replace(anchor, '            V73EternalForgeEntry().environmentObject(journal)\n' + anchor, 1)
s = s[:start] + part + s[end:]

# Sport : lien adjacent à Progression, pas de changement des formulaires existants.
start = s.index('private struct V70ForgeSportEntry: View')
end = s.index('private struct V70DraftSet:', start)
part = s[start:end]
anchor = '            NavigationLink {\n                V71ExercisePerformance().environmentObject(journal)\n'
require_once(part, anchor, 'Entrée Progression par exercice / Sport')
part = part.replace(anchor, '            V73EternalForgeEntry().environmentObject(journal)\n' + anchor, 1)
s = s[:start] + part + s[end:]

# Ascension : entrée facilement trouvable sous les reliques existantes.
start = s.index('struct AscensionScreen: View')
end = s.index('private struct V70RebirthCommandDeck: View', start)
part = s[start:end]
anchor = '                    V72AwakeningEntry().environmentObject(journal)\n'
require_once(part, anchor, 'Chambre d’Éveil / Ascension')
part = part.replace(anchor, anchor + '                    V73EternalForgeEntry().environmentObject(journal)\n', 1)
s = s[:start] + part + s[end:]

# Forge : optional preset; remains fully compatible with V70NuclearForge().
start = s.index('private struct V70NuclearForge: View')
end = s.index('private struct V70NuclearAnalytics: View', start)
forge = s[start:end]
anchor = '    @Environment(\\.dismiss) private var dismiss\n'
require_once(forge, anchor, 'Environnement Forge')
forge = forge.replace(anchor, anchor + '    var launch: V73ForgeLaunch? = nil\n', 1)
anchor = '    @State private var achievedRecords: [String] = []\n'
require_once(forge, anchor, 'État de record Forge')
forge = forge.replace(anchor, anchor + '    @State private var programLinkWarning: String?\n', 1)
anchor = '                        Label("SÉANCE ENREGISTRÉE", systemImage: "checkmark.seal.fill")\n                            .font(.headline).foregroundStyle(Nuclear.gold)\n'
require_once(forge, anchor, 'Bloc de succès de la Forge')
forge = forge.replace(anchor, anchor + '''                        if let programLinkWarning {
                            Text(programLinkWarning)
                                .font(.caption).foregroundStyle(Nuclear.purple)
                        }
''', 1)
anchor = '        .modifier(PageBackground())\n'
require_once(forge, anchor, 'Fond de la Forge')
forge = forge.replace(anchor, anchor + '        .onAppear(perform: prefillFromProgram)\n', 1)
anchor = '    private func makeCurrentExercise() -> WorkoutExercise? {\n'
require_once(forge, anchor, 'Sauvegarde Forge')
prefill = '''    private func prefillFromProgram() {
        guard let launch, !saved, prepared.isEmpty,
              exerciseName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        prepared = launch.day.exercises.map { target in
            let sets = (0..<target.sets).map { _ in
                WorkoutSet(reps: target.reps, weight: target.weight)
            }
            return WorkoutExercise(name: target.name, sets: sets)
        }
        duration = String(launch.day.durationMinutes)
        notes = "Programme : \\(launch.planName) · \\(launch.day.title)"
    }

'''
forge = forge.replace(anchor, prefill + anchor, 1)
anchor = '''        journal.add(WorkoutSession(date: sessionDate, activity: "Musculation",
                                   durationMinutes: minutes, notes: notes, rpe: rpe,
                                   exercises: exercises))
'''
require_once(forge, anchor, 'Création de la séance unique')
replace = '''        let savedWorkout = WorkoutSession(date: sessionDate, activity: "Musculation",
                                           durationMinutes: minutes, notes: notes, rpe: rpe,
                                           exercises: exercises)
        journal.add(savedWorkout)
        if let launch {
            do {
                try V73LedgerStore.link(launch, to: savedWorkout)
            } catch {
                programLinkWarning = "Séance enregistrée mais non reliée à la campagne : \\(error.localizedDescription)"
            }
        }
'''
forge = forge.replace(anchor, replace, 1)
s = s[:start] + forge + s[end:]

module = (here/'V73_ETERNAL_FORGE.swift.txt').read_text(encoding='utf-8')
for marker in ('private struct V73EternalForgeHub: View',
               'private struct V73ProgramEditor: View',
               'private struct V73VictoryCinema: View',
               'private enum V73CampaignEngine',
               'private enum V73LedgerStore'):
    require_once(module, marker, 'Module Eternal Forge incomplet : ' + marker)
s = s.rstrip() + '\n' + module.rstrip() + '\n'

out = staging/'BiluxIOS/BiluxScreens.swift'
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(s, encoding='utf-8')
print('✅ V7.3 : programmes, Forge préremplie et campagne cosmétique intégrés.')
print('✅ Une seule source SwiftUI modifiée ; aucun modèle ou moteur d’XP modifié.')
print('✅ Watch, WidgetKit, HealthKit et signature iOS inchangés.')
