#!/usr/bin/env bash
set -euo pipefail
BASE='bilux-v7.2-nuclear-awakening'
TARGET='bilux-v7.3-eternal-forge'
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail(){ echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Se placer à la racine du dépôt BILUX.'
[[ "$(git branch --show-current)" == "$BASE" ]] || fail "Branche attendue : $BASE"
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Commiter ou stasher les modifications suivies avant installation.'
git diff --cached --quiet || fail 'Index Git non vide.'
! git show-ref --verify --quiet "refs/heads/$TARGET" || fail "La branche $TARGET existe déjà."
command -v python3 >/dev/null || fail 'Python 3 nécessaire.'
git var GIT_AUTHOR_IDENT >/dev/null 2>&1 || fail 'Identité Git manquante.'
TEMP="$(mktemp -d)"; trap 'rm -rf "$TEMP"' EXIT
python3 "$HERE/APPLIQUER_V7_3.py" "$(pwd)" "$TEMP" || fail 'Base V7.2 incompatible ; aucun changement effectué.'
[[ -s "$TEMP/BiluxIOS/BiluxScreens.swift" ]] || fail 'Nouvelle source Swift introuvable.'
if command -v swiftc >/dev/null 2>&1; then
  swiftc -frontend -parse "$TEMP/BiluxIOS/BiluxScreens.swift" BiluxIOS/Models.swift || fail 'Erreur syntaxe Swift ; dépôt inchangé.'
  echo '✅ Analyse syntaxique Swift réussie (typage Xcode reste à valider).'
else
  echo 'ℹ️ Swift non installé dans Codespaces : vérification complète par Xcode.'
fi
git switch -c "$TARGET"
cp "$TEMP/BiluxIOS/BiluxScreens.swift" BiluxIOS/BiluxScreens.swift
git add -- BiluxIOS/BiluxScreens.swift
git diff --cached --check || fail 'Diff Git invalide.'
git commit -m 'BILUX V7.3 - Eternal Forge programs and cosmetic campaign'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
  git push -u origin "$TARGET" || fail 'Commit local créé : réessayer le push sur la nouvelle branche.'
else
  echo '🧪 Mode test sans push.'
fi
echo "✅ V7.3 installée sur $TARGET. Préparer le build 33."
