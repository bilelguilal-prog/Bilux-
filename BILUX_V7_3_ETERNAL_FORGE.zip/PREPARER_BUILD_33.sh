#!/usr/bin/env bash
set -euo pipefail
BRANCH='bilux-v7.3-eternal-forge'
fail(){ echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Se placer à la racine du dépôt.'
[[ "$(git branch --show-current)" == "$BRANCH" ]] || fail "Branche attendue : $BRANCH"
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications locales non commitées.'
git diff --cached --quiet || fail 'Index Git non vide.'
for marker in 'private struct V73EternalForgeHub: View' 'private struct V73ProgramEditor: View' 'private struct V73VictoryCinema: View' 'private struct V72AwakeningChamber: View'; do
  grep -qF "$marker" BiluxIOS/BiluxScreens.swift || fail "Composant absent : $marker"
done
grep -qF 'V61LiveWorkoutView().tag(5)' BiluxWatch/WatchRootView.swift || fail 'Nuclear Live manquant.'
grep -qF 'V69WatchQuestsPage' BiluxWatch/WatchRootView.swift || fail 'Watch 4.1 manquante.'
grep -qF 'BILUXWatchWidgetPack' BiluxWatchWidget/NuclearLiveWidget.swift || fail 'WidgetKit manquant.'
[[ -f scripts/assign_widget_signing.py ]] || fail 'Signature WidgetKit introuvable.'
TEMP="$(mktemp -d)"; trap 'rm -rf "$TEMP"' EXIT
python3 - "$TEMP" <<'PY'
from pathlib import Path
import plistlib, sys
root = Path.cwd(); target = Path(sys.argv[1]); files = []
for rel in ('BiluxIOS/Info.plist','BiluxWatch/Info.plist','BiluxWatchWidget/Info.plist'):
    try: payload = plistlib.loads((root/rel).read_bytes())
    except Exception as e: raise SystemExit(f'❌ Plist absent/invalide {rel}: {e}')
    build = str(payload.get('CFBundleVersion'))
    if build == '33': raise SystemExit('ℹ️ Build 33 déjà préparé ; ne pas relancer ce script.')
    if build != '32': raise SystemExit(f'❌ Build 32 attendu dans {rel}, reçu {build}.')
    payload['CFBundleVersion'] = '33'
    dest = target/rel; dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(plistlib.dumps(payload,sort_keys=False))
    files.append(rel)
rel = 'BiluxIOS.xcodeproj/project.pbxproj'
src = (root/rel).read_text(encoding='utf-8')
if src.count('CURRENT_PROJECT_VERSION = 32;') != 2:
    raise SystemExit('❌ Xcode : deux références CURRENT_PROJECT_VERSION=32 attendues.')
if 'BiluxWatchWidget' not in src:
    raise SystemExit('❌ WidgetKit non référencé dans Xcode.')
dest = target/rel; dest.parent.mkdir(parents=True, exist_ok=True)
dest.write_text(src.replace('CURRENT_PROJECT_VERSION = 32;', 'CURRENT_PROJECT_VERSION = 33;'), encoding='utf-8')
print('✅ Build 33 préparé : iPhone, Watch et WidgetKit.')
PY
FILES=(BiluxIOS/Info.plist BiluxWatch/Info.plist BiluxWatchWidget/Info.plist BiluxIOS.xcodeproj/project.pbxproj)
for rel in "${FILES[@]}"; do cp "$TEMP/$rel" "$rel"; done
git add -- "${FILES[@]}"
git diff --cached --check || fail 'Diff Git invalide.'
git commit -m 'BILUX V7.3 - Build 33 iPhone Watch WidgetKit'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != '1' ]]; then
  git push origin "$BRANCH" || fail 'Commit local créé : réessayer le push.'
else
  echo '🧪 Mode test sans push.'
fi
echo '✅ Build 33 prêt. Lancer uniquement BILUX — Publier sur TestFlight.'
