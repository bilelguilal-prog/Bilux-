# BILUX V5 — Sport : catalogue d’exercices et édition des séances

## Ce que fait ce correctif

- Menu des exercices habituels : contient automatiquement les exercices des séances déjà enregistrées.
- Ajout d’un nouvel exercice au catalogue dès l’appui sur « Ajouter aux exercices habituels » ou sur « Terminé » du clavier ; l’enregistrement de la séance l’ajoute aussi.
- Noms de la bibliothèque conservés pour réutilisation, même si une ancienne séance est modifiée ou supprimée.
- Bouton « Modifier » dans l’historique : date, activité, durée, notes, RPE, exercices, séries, répétitions et poids deviennent éditables.
- L’identifiant de séance est conservé, donc le nombre de séances et les XP ne doublent pas.
- Le fichier de sauvegarde `bilux-v4.json` et les sauvegardes JSON antérieures restent compatibles : `exerciseLibrary` est facultatif.
- Le projet Apple Watch, les profils de signature et `codemagic.yaml` ne sont pas modifiés.

## Installation depuis GitHub Codespaces (sur une branche de travail)

1. Téléverser `BILUX_V5_SPORT_PATCH.zip` à la racine de ton dépôt GitHub (ne pas l’extraire localement dans iOS ; GitHub n’extrait pas les ZIP automatiquement).
2. Ouvrir Codespaces sur la branche `bilux-v4.1-watch` (ou créer une branche dédiée) et synchroniser :

```bash
git status --short
git pull --ff-only
unzip -o BILUX_V5_SPORT_PATCH.zip -d /tmp/bilux-v5-patch
```

3. Vérifier le patch **avant** modification :

```bash
git apply --check /tmp/bilux-v5-patch/BILUX_V5_SPORT.patch
```

4. Seulement si cette commande ne signale aucune erreur :

```bash
git apply /tmp/bilux-v5-patch/BILUX_V5_SPORT.patch
git diff --check
git status --short
```

5. Enregistrer les quatre fichiers modifiés :

```bash
git add BiluxIOS/Models.swift BiluxIOS/BiluxStore.swift BiluxIOS/EntryForms.swift BiluxIOS/BiluxScreens.swift
git commit -m "BILUX V5 Sport: exercise catalogue and edit workouts"
git push
```

6. Vérifier avec Codemagic avant toute distribution. Un build de simulateur réussi ne remplace pas un test utilisateur réel.

**Important :** si `git apply --check` échoue, ne force pas le patch, ne lance pas `unzip -o` sur des fichiers source. Récupère le message d’erreur pour adapter le correctif à la version courante.

## Plan V5 complet (les autres axes ne sont pas encore codés dans ce correctif)

1. **Interface nucléaire** : composants adaptatifs, animations, avatar cinématique, accessibilité.
2. **Apple Watch** : installation/synchronisation robustes, état de connexion, compteur de séance, données HealthKit consenties.
3. **Sport** : ce correctif (catalogue + édition) ; puis modèles de séances, progression et records.
4. **Nutrition** : objectifs de macros, graphiques et source Apple Santé sans double comptage.
5. **RPG** : XP et quêtes plus riches, transformations, succès, progression indépendante des résultats médicaux.

## Vérifications effectuées

- Validation syntaxique Swift des quatre fichiers modifiés (`swiftc -frontend -parse`).
- Vérification de la compatibilité de décodage JSON d’un ancien journal V4 (`Models.swift`).
- Le patch s’applique proprement à l’archive V4.1 transmise, mais **n’a pas encore été compilé sur Xcode/Codemagic ni testé sur appareil**.
