#!/usr/bin/env bash
set -euo pipefail

# BILUX V5.2 - installs only the SwiftUI presentation layer.
# Does NOT alter data models, JSON backups, HealthKit, watchOS or signing.
BASE='bilux-v5.1-redesign'
DEST='bilux-v5.2-awakening'
TARGET='BiluxIOS/BiluxScreens.swift'
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH="$HERE/BILUX_V5_2_NUCLEAR_AWAKENING.patch"

abort() { echo "❌ BILUX V5.2 : $*" >&2; exit 1; }
[[ -d .git && -f "$TARGET" && -f "$PATCH" ]] || abort "Lance ce script depuis la racine du depot GitHub BILUX."
[[ "$(git branch --show-current)" == "$BASE" ]] || abort "Branche actuelle incorrecte. Selectionne '$BASE'."
[[ -z "$(git status --porcelain -- "$TARGET")" ]] || abort "$TARGET contient deja des modifications. Rien n'a ete ecrase."
git diff --cached --quiet || abort "Il existe des modifications staged : arret par securite."
! git show-ref --verify --quiet "refs/heads/$DEST" || abort "La branche locale '$DEST' existe deja."
if git ls-remote --exit-code --heads origin "$DEST" >/dev/null 2>&1; then
    abort "La branche distante '$DEST' existe deja."
fi
git apply --check "$PATCH" || abort "Le patch ne correspond pas au code V5.1 de cette branche. Ne force rien."

git switch -c "$DEST"
git apply "$PATCH"
git diff --check || abort "Probleme de formatage detecte. Aucun commit automatique."
if command -v swiftc >/dev/null 2>&1; then
    swiftc -frontend -parse BiluxIOS/*.swift BiluxWatch/*.swift BiluxShared/*.swift || abort "Erreur syntaxique Swift : arret avant commit."
fi

git add -- "$TARGET"
git commit -m 'BILUX V5.2 - Nuclear Awakening RPG, records et transformations'
git push -u origin "$DEST"
echo ''
echo '✅ BILUX V5.2 disponible sur GitHub : bilux-v5.2-awakening'
echo '➡️ Codemagic > BILUX - Verifier le projet iOS (sans Apple Developer)'
echo '⚠️ Pour TestFlight il faudra ensuite passer au build 6 (script fourni).'
