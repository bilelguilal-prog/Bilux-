# BILUX V5.2 — Nuclear Awakening

## Démarrage sécurisé depuis l'iPhone

### 1. Ajouter l'archive sur GitHub

Dans le dépôt `bilelguilal-prog/Bilux-`, sélectionne **`bilux-v5.1-redesign`** (ta V5.1 fonctionnelle). `Add file` → `Upload files` → `BILUX_V5_2_NUCLEAR_AWAKENING.zip` → `Commit changes`.

### 2. Appliquer le correctif dans Codespaces

Depuis le terminal à la **racine du dépôt** :

```bash
git switch bilux-v5.1-redesign
git pull --ff-only origin bilux-v5.1-redesign
unzip -o BILUX_V5_2_NUCLEAR_AWAKENING.zip -d /tmp/bilux-v52
bash /tmp/bilux-v52/INSTALLER_V5_2.sh
```

Le script vérifie que la branche est correcte, que le fichier cible est propre, que le patch correspond au code actuel, qu'aucune branche V5.2 ne préexiste et qu'il n'y a pas de changement déjà indexé. Puis il crée **`bilux-v5.2-awakening`**, applique le patch, effectue les vérifications possibles et pousse la branche sur GitHub. Il laisse la branche V5.1 intacte. **Ne force pas `git apply`** si le script s'arrête.

### 3. Compiler avant TestFlight

Codemagic → branche **`bilux-v5.2-awakening`** → workflow **`BILUX - Verifier le projet iOS (sans Apple Developer)`**.

L'exécution de `swiftc -frontend -parse` sur Linux valide seulement la **syntaxe** ; elle ne vaut pas compilation Xcode/SwiftUI. Le simulateur Codemagic doit être vert avant publication.

### 4. Après un build simulateur vert, passer au build 6

Le dernier build TestFlight est `1.0 (5)`. Dans Codespaces :

```bash
bash /tmp/bilux-v52/PREPARER_BUILD_6.sh
```

Ce script exige des numéros de build **5** dans `BiluxIOS/Info.plist` et `BiluxWatch/Info.plist`, puis les monte ensemble à **6**. Il s'arrête sans rien modifier si une valeur est inattendue. Ensuite sur Codemagic → branche `bilux-v5.2-awakening` → workflow **Publier sur TestFlight**. Après traitement Apple, ajouter le build au groupe de test et installer depuis TestFlight.

**Avant l'installation**, conserver le JSON exporté de BILUX. Ne pas réimporter ce JSON tant que l'historique est présent : les imports sont conçus pour un transfert et non pour une sauvegarde automatique de retour arrière.

## Nouveautés V5.2

- **Cinq transformations** débloquées automatiquement selon le niveau existant : Survivant (1), Éveil (3), Réacteur (6), Nucléaire (10), Ascension (15). Avatar d'origine conservé, nouvelles teintes, halos et emblèmes par rang.
- **Révélation de niveau** lors d'un nouveau passage de niveau, sans déclenchement artificiel à la première ouverture après installation.
- **Arbre de maîtrise**, calculé uniquement depuis le journal : nombre de séances, séries, exercices et jours ayant des saisies.
- **Six trophées**, déverrouillés par les vraies données et recalculés en cas de modification/suppression. Aucun XP supplémentaire n'est créé par un trophée.
- **Records sportifs** : charge la plus élevée sur une série enregistrée, maximum de répétitions sur une série, meilleur volume d'une séance.
- **Graphique** des volumes de séances, sur les six semaines civiles allant jusqu'à aujourd'hui. Ne présente aucun record fictif lorsque la saisie ne comprend pas de charge.
- **Réglage Animations nucléaires** indépendant du JSON, sauvegardé dans les préférences iOS. Compatibilité avec « Réduire les animations » d'Accessibilité.

## Invariants et limites

- Le patch modifie **seulement `BiluxIOS/BiluxScreens.swift`** : pas de modification des modèles, de `BiluxStore`, du calcul des XP, de la santé, de la synchronisation Watch, du bundle ID, de la signature ni du numéro de build avant l'étape dédiée.
- Les « transformations » V5.2 sont des **variations visuelles autour de l'illustration BiluxHero existante**, pas encore cinq portraits différents.
- Aucun objectif ne sert à orienter les traitements, les résultats médicaux ou la récupération. Les jours de repos ne sont pas pénalisés.
- Le calcul des records de force est un **maximum saisi** (pas une estimation de 1RM). Le « volume » est la somme charge × répétitions, pas une mesure absolue de dépense.
- Le projet a été vérifié via `git apply --check`, `swiftc -frontend -parse` et un contrôle des fichiers modifiés. **La compilation Xcode et les tests iPhone réels restent à faire**.

## Scénario de test sur iPhone

1. Au premier lancement V5.2, vérifier le même niveau et le même total de XP qu'avant ; aucun faux écran de montée de niveau.
2. Ouvrir Ascension ; vérifier la transformation **Éveil** si ton niveau est toujours 3, les autres paliers verrouillés, les trophées et l'arbre de maîtrise.
3. Sport : vérifier les records et le graphique, puis créer et modifier une séance-test. Vérifier que le menu d'exercices habituel et l'édition restent fonctionnels.
4. Vérifier qu'une séance modifiée ne double pas les XP ; vérifier les valeurs de l'historique.
5. Dans Ascension, désactiver les animations ; vérifier que l'avatar reste affiché sans effet animé.
6. Vérifier que BILUX Watch est toujours présent et que la synchronisation continue.

Si Codemagic montre une erreur, envoyer la première ligne `error:` du journal. Ne pas lancer un build signé avant d'avoir un simulateur vert.
