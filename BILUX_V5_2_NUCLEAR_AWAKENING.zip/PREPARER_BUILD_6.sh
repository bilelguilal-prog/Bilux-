#!/usr/bin/env bash
set -euo pipefail
[[ "$(git branch --show-current)" == 'bilux-v5.2-awakening' ]] || { echo 'Mauvaise branche : bilux-v5.2-awakening requise.' >&2; exit 1; }
python3 - <<'PY'
from pathlib import Path
import plistlib
import re

files = [Path('BiluxIOS/Info.plist'), Path('BiluxWatch/Info.plist')]
old = re.compile(r'(<key>CFBundleVersion</key>\s*<string>)5(</string>)')
replacements = []
for path in files:
    text = path.read_text()
    data = plistlib.loads(path.read_bytes())
    if str(data.get('CFBundleVersion')) != '5':
        raise SystemExit(f'{path}: build 5 attendu, valeur actuelle {data.get("CFBundleVersion")!r}. Aucune modification.')
    updated, count = old.subn(r'\g<1>6\g<2>', text)
    if count != 1 or str(plistlib.loads(updated.encode())['CFBundleVersion']) != '6':
        raise SystemExit(f'{path}: structure Info.plist inattendue, aucune modification.')
    replacements.append((path, updated))
for path, updated in replacements:
    path.write_text(updated)
    print(f'✅ {path}: build 5 → 6')
PY
git diff --check
git add -- BiluxIOS/Info.plist BiluxWatch/Info.plist
git commit -m 'BILUX V5.2 - Build 6 iPhone et Watch'
git push origin bilux-v5.2-awakening
