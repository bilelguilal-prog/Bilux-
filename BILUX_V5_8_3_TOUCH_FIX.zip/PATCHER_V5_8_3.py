#!/usr/bin/env python3
"""BILUX V5.8.3 — Remove invisible image hit regions that intercept boss links."""
from pathlib import Path
import plistlib
import sys

if len(sys.argv) != 3:
    raise SystemExit("Usage: PATCHER_V5_8_3.py <repo_root> <staging_dir>")
repo, staging = [Path(x).resolve() for x in sys.argv[1:3]]

def stop(message):
    raise SystemExit(f"❌ {message} — aucun fichier du projet modifié.")

for filename in ("BiluxIOS/Info.plist", "BiluxWatch/Info.plist"):
    try:
        bundle = plistlib.loads((repo / filename).read_bytes())
    except Exception as exc:
        stop(f"Lecture impossible de {filename}: {exc}")
    if str(bundle.get("CFBundleVersion")) != "16":
        stop(f"Build 16 requis : {filename} est au build {bundle.get('CFBundleVersion')}")

source = repo / "BiluxIOS/BiluxScreens.swift"
try:
    text = source.read_text(encoding="utf-8")
except Exception as exc:
    stop(f"Lecture impossible de {source}: {exc}")

marker = "private struct BILUXV58Codex: View {"
if text.count(marker) != 1:
    stop("Codex absent ou ambigu")
head, codex = text.split(marker, 1)
if "V5.8.2 : navigation directe par NavigationLink" not in codex:
    stop("Correctif V5.8.2 introuvable")
if codex.count("NavigationLink(value: boss)") != 1:
    stop("Navigation native attendue introuvable")
if "V5.8.3 : portraits hors hit testing" in codex:
    stop("Correctif V5.8.3 déjà appliqué")

before = '''                    }
                    .frame(height: 188)
                    .clipShape(RoundedRectangle(cornerRadius: 13))
                    Text(boss.subtitle.uppercased())'''
after = '''                    }
                    .frame(height: 188)
                    .clipShape(RoundedRectangle(cornerRadius: 13))
                    // V5.8.3 : portraits hors hit testing. Une image recadrée peut
                    // bloquer la touche du dossier précédent avec sa zone invisible.
                    .allowsHitTesting(false)
                    Text(boss.subtitle.uppercased())'''
if codex.count(before) != 1:
    stop(f"Portraits du Codex attendus une fois, trouvés {codex.count(before)}")

modified = head + marker + codex.replace(before, after, 1)
if modified.count("V5.8.3 : portraits hors hit testing") != 1:
    stop("Marqueur de sécurité absent")
if "<<<<<<<" in modified or ">>>>>>>" in modified:
    stop("Marqueurs de conflit détectés")

out = staging / "BiluxIOS/BiluxScreens.swift"
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(modified, encoding="utf-8")
print("✅ Source V5.8.2 build 16 reconnue.")
print("✅ Les illustrations du bestiaire n'interceptent plus les gestes tactiles.")
print("✅ Aucune modification du moteur d'XP, des séances, de Santé ou de la Watch.")
