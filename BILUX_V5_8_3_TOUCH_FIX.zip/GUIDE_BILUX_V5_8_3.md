# BILUX V5.8.3 — Correction tactile du Codex (build 17)

**Cause probable étayée par le code SwiftUI :** les portraits des deux boss sont présentés via `GeometryReader`, `scaledToFill()` et `clipShape`, mais `clipShape` ne réduit pas toujours les régions utilisées par la détection des touches. Le portrait du Souverain, situé sous le Gardien, peut donc intercepter les touches du bouton du Gardien même dans une zone où il n'est pas visible. La correction applique `.allowsHitTesting(false)` aux deux portraits **décoratifs uniquement**, pour laisser passer les taps vers les boutons ; aucune modification du moteur de progression ou de la navigation native V5.8.2.

## 1. Sauvegarde

Depuis BILUX, conserve ton export JSON dans Fichiers, en privé (ne le publie pas sur GitHub).

## 2. GitHub

Sélectionne la branche `bilux-v5.8.2-dossiers-combat`, puis `Add file → Upload files` pour ajouter `BILUX_V5_8_3_TOUCH_FIX.zip` à la racine ; valide `Commit changes`.

## 3. Codespaces

```bash
git switch bilux-v5.8.2-dossiers-combat && git pull --ff-only origin bilux-v5.8.2-dossiers-combat && unzip -o BILUX_V5_8_3_TOUCH_FIX.zip -d /tmp/bilux-v583 && bash /tmp/bilux-v583/INSTALLER_V5_8_3.sh
```

Le script créera `bilux-v5.8.3-codex-touch-fix`. Il refuse d'écrire si les fichiers ou les numéros de build (16) ne correspondent pas.

## 4. Codemagic

Exécute les deux vérifications **iOS** et **Apple Watch** sur `bilux-v5.8.3-codex-touch-fix`. Si les deux passent au vert :

```bash
bash /tmp/bilux-v583/PREPARER_BUILD_17.sh
```

Publie ensuite via le workflow TestFlight sur la même branche. Attends le traitement d'Apple pour installer **1.0 (17)**.

## 5. Test décisif sur iPhone

Dans `Ascension → Codex → Bestiaire`, appuie **une seule fois** sur `VOIR LE DOSSIER DE COMBAT` du Gardien, reviens, puis ouvre celui du Souverain. Vérifie aussi la navigation entre Bestiaire / Trophées / Chroniques et les données de séances.

**Limite :** le script vérifie la syntaxe Swift, le changement ciblé et la préparation du build. La compilation réelle et la réception des touches doivent être validées sur iPhone via Codemagic et TestFlight.
