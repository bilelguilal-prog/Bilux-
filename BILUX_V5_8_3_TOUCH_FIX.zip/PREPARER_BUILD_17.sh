#!/usr/bin/env bash
set -euo pipefail
BRANCH='bilux-v5.8.3-codex-touch-fix'
fail(){ echo "❌ $*" >&2; exit 1; }
[[ "$(git rev-parse --show-toplevel 2>/dev/null)" == "$(pwd -P)" ]] || fail 'Lance depuis la racine du dépôt BILUX.'
[[ "$(git branch --show-current)" == "$BRANCH" ]] || fail "Branche $BRANCH attendue."
[[ -z "$(git status --porcelain --untracked-files=no)" ]] || fail 'Modifications locales détectées.'
git diff --cached --quiet || fail 'Modifications indexées détectées.'
grep -q 'V5.8.3 : portraits hors hit testing' BiluxIOS/BiluxScreens.swift || fail 'Patch V5.8.3 absent.'
python3 - <<'PY'
from pathlib import Path
import plistlib
names = ('BiluxIOS/Info.plist', 'BiluxWatch/Info.plist')
plists = {}
for name in names:
    pl = plistlib.loads(Path(name).read_bytes())
    if str(pl.get('CFBundleVersion')) != '16':
        raise SystemExit(f'❌ {name} : build 16 requis, trouvé {pl.get("CFBundleVersion")!r}. Aucun fichier modifié.')
    plists[name] = pl
for name, pl in plists.items():
    pl['CFBundleVersion'] = '17'
    Path(name).write_bytes(plistlib.dumps(pl, fmt=plistlib.FMT_XML, sort_keys=False))
    print(f'✅ {name} : build 16 → 17')
PY
git add -- BiluxIOS/Info.plist BiluxWatch/Info.plist
git diff --cached --check || fail 'Diff invalide.'
git commit -m 'BILUX V5.8.3 - TestFlight build 17'
if [[ "${BILUX_TEST_NO_PUSH:-0}" != 1 ]]; then
  git push -u origin "$BRANCH" || fail "Push échoué : git push -u origin $BRANCH"
else
  echo '🧪 Test local : push désactivé.'
fi
echo '✅ Build 17 prêt pour le workflow TestFlight.'
